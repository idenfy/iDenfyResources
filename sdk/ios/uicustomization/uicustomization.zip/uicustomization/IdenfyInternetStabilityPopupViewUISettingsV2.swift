//
//  IdenfyInternetStabilityPopupViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-03-01.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyInternetStabilityPopupViewUISettingsV2: NSObject {
    // IdenfyInternetConnectionPopupView Colors

    @MainActor @objc public static var idenfyInternetStabilityPopupViewBackgroundColor = IdenfyCommonColors.idenfyWarningLightYellowV2
    @MainActor @objc public static var idenfyInternetStabilityPopupViewTextViewColor = IdenfyCommonColors.idenfyBlack
    @MainActor @objc public static var idenfyInternetStabilityPopupViewImageViewTintColor = IdenfyCommonColors.idenfyWarningYellowV2

    // IdenfyInternetConnectionPopupView Fonts

    @MainActor @objc public static var idenfyInternetStabilityPopupViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
}
