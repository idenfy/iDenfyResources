//
//  IdenfyBankVerificationViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-03-01.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyBankVerificationViewUISettingsV2: NSObject {
    
    // Idenfy Bank Verification View Colors
    @MainActor @objc public static var idenfyBankVerificationViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankVerificationViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewCancelIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewArrowIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewUISwitchTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankVerificationViewUISwitchDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewBankNotListedUISwitchInformationIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewResultStatusTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewResultSuccessStatusCardBorderColor = IdenfyCommonColors.idenfyBorderGreenV2
    @MainActor @objc public static var idenfyBankVerificationViewResultSuccessStatusCardBackgroundColor = IdenfyCommonColors.idenfyBackgroundGreenV2
    @MainActor @objc public static var idenfyBankVerificationViewResultFailedStatusCardBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyBankVerificationViewResultFailedStatusCardBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyBankVerificationViewResultSuccessStatusDescriptionIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankVerificationViewResultFailedStatusDescriptionIconTintColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyBankVerificationViewResultFailedStatusDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyBankVerificationViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyBankVerificationViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationViewBankSelectionLoadingSpinnerTintColor = IdenfyCommonColors.idenfyMainColorV2
    
    // Idenfy BankVerification View Fonts
    @MainActor @objc public static var idenfyBankVerificationViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyBankVerificationViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyBankVerificationViewUISwitchDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    @MainActor @objc public static var idenfyBankVerificationViewResultStatusTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    @MainActor @objc public static var idenfyBankVerificationViewResultFailedStatusDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    
    // Idenfy Bank Verification View Styles
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyBankVerificationViewItemSelectionInputViewBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyBankVerificationViewResultStatusCardCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyBankVerificationViewResultStatusCardBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyBankVerificationViewCountryFlagBorderWidth = CGFloat(1)
    
    // Idenfy Bank Selection Alert Colors
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellHighlightedTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellHighlightedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarSearchIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    
    // Idenfy Bank Selection Alert Fonts
    @MainActor @objc public static var idenfyBankVerificationAlertSearchBarHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankVerificationAlertSearchBarFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    
    // Idenfy Bank Selection Alert Styles
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyBankVerificationAlertItemSearchBarCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyBankVerificationAlertItemTableViewCellHeight = CGFloat(50)
}
