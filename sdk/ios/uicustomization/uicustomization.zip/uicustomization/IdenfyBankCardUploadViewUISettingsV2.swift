//
//  IdenfyBankCardUploadViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardUploadViewUISettingsV2: NSObject {

    @MainActor @objc public static var idenfyBankCardUploadViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardUploadViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardUploadViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardUploadViewUploadIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardUploadViewClickToUploadTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardUploadViewFileHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyBankCardUploadViewContainerBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyBankCardUploadViewContainerBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardUploadViewButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyBankCardUploadViewButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyBankCardUploadViewButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardUploadViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    @MainActor @objc public static var idenfyBankCardUploadViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyBankCardUploadViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankCardUploadViewClickToUploadFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
    @MainActor @objc public static var idenfyBankCardUploadViewFileHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)

    @MainActor @objc public static var idenfyBankCardUploadViewContainerBorderWidth: CGFloat = 1
    @MainActor @objc public static var idenfyBankCardUploadViewContainerCornerRadius: CGFloat = 8
}
