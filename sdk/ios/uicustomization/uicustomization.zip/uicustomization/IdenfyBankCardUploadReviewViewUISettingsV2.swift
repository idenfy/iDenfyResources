//
//  IdenfyBankCardUploadReviewViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardUploadReviewViewUISettingsV2: NSObject {

    @MainActor @objc public static var idenfyBankCardUploadReviewViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewNextButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardUploadReviewViewRetakeButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewRetakeButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewRetakeButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardUploadReviewViewQuestionCardBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankCardUploadReviewViewQuestionCardBackgroundColor = IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewQuestionCardTitleColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewQuestionCardIconColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardUploadReviewViewConfirmButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    @MainActor @objc public static var idenfyBankCardUploadReviewViewPdfPreviewCornerRadius = CGFloat(8)
    @MainActor @objc public static var idenfyBankCardUploadReviewViewQuestionCardCornerRadius = CGFloat(4)

    @MainActor @objc public static var idenfyBankCardUploadReviewViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyBankCardUploadReviewViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankCardUploadReviewViewQuestionCardFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
}
