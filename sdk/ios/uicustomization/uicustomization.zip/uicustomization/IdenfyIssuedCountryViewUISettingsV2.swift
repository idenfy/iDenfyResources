//
//  IdenfyIssuedCountryViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-03-09.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyIssuedCountryViewUISettingsV2: NSObject {
    // Idenfy Issued Country View Colors

    @MainActor @objc public static var idenfyIssuedCountryViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyIssuedCountryViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIssuedCountryViewCountryViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyIssuedCountryViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIssuedCountryViewCountryLabelTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIssuedCountryViewCountryViewBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyIssuedCountryViewBeginIdentificationButtonTextColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Issued Country View Fonts

    @MainActor @objc public static var idenfyIssuedCountryViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyIssuedCountryViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyIssuedCountryViewCountryLabelFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)

    // Idenfy Issued Country View Style

    @MainActor @objc public static var idenfyIssuedCountryViewCountryViewBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyIssuedCountryViewCountryViewCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyIssuedCountryViewCountryFlagBorderWidth = CGFloat(1)
}
