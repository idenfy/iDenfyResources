//
//  IdenfyFailedAfterManualReviewingViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-07-21.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyManualReviewingStatusFailedViewUISettingsV2: NSObject {
    // ManualReviewingStatusFailedViewV2 Colors

    @MainActor @objc public static var idenfyManualReviewingStatusFailedViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusFailedCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusFailedCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyManualReviewingStatusFailedCommonInformationDescriptionEmailTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusFailedContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // ManualReviewingStatusFailedViewV2 Fonts

    @MainActor @objc public static var idenfyManualReviewingStatusFailedCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyManualReviewingStatusFailedCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyManualReviewingStatusFailedCommonInformationDescriptionEmailFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
}
