//
//  ConstsIdenfyUI.swift
//  iDenfySDK
//
//  Created by Viktor Vostrikov on 2020-01-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit

@objc open class ConstsIdenfyUI: NSObject {
    @MainActor @objc public static var idenfyCameraTopDrawerHeight = CGFloat(160)
    @MainActor @objc public static var idenfyCameraBottomControlsHeightMultiplier = CGFloat(0.15)
}
