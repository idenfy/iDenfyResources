//
//  ConstsIdenfyColors.swift
//  iDenfySDK
//
//  Created by Viktas Juskys on 2020-01-27.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyCommonColors: NSObject {
    @objc public static var idenfyWhite = UIColor.white
    @objc public static var idenfyBlack = UIColor.black
    @objc public static var idenfyDrawerBackgroundColor = UIColor.black.withAlphaComponent(0.6)
    @objc public static var idenfyBackgroundColorV2 = UIColor(hexString: "#FBFBFB")
    @objc public static var idenfyMainColorV2 = UIColor(hexString: "#536DFE")
    @objc public static var idenfyMainDarkerColorV2 = UIColor(hexString: "#5D7CE4")
    @objc public static var idenfySecondColorV2 = UIColor(hexString: "#353B4E")
    @objc public static var idenfyStepSuccessColorV2 = IdenfyCommonColors.idenfyMainDarkerColorV2
    @objc public static var idenfyStepErrorColorV2 = UIColor(hexString: "#D32F2F")
    @objc public static var idenfyTakePhotoButtonBackgroundFocused = IdenfyCommonColors.idenfyMainDarkerColorV2
    @objc public static var idenfyTakePhotoButtonIconUnFocused = IdenfyCommonColors.idenfyMainDarkerColorV2
    @objc public static var idenfyGradientColor1V2 = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyGradientColor2V2 = UIColor(hexString: "#8D6CFB")
    @objc public static var idenfyPhotoResultDetailsCardBackgroundColorV2 = UIColor(hexString: "#D9DFFC")
    @objc public static var idenfyFaceDetectedColor = UIColor(hexString: "9CEE13")
    @objc public static var idenfyFaceNotDetectedColor = UIColor(hexString: "CFD8DC")
    @objc public static var idenfyDarkRedErrorColorV2 = UIColor(hexString: "#C1170B")
    @objc public static var idenfyRedColorV2 = UIColor(hexString: "#F44336")
    @objc public static var idenfyErrorLightRedColorV2 = UIColor(hexString: "#FFEBEE")
}
