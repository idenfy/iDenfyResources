//
//  ConstsIdenfyColors.swift
//  iDenfySDK
//
//  Created by Viktas Juskys on 2020-01-27.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyCommonColors: NSObject {
    @MainActor @objc public static var idenfyWhite = UIColor.white
    @MainActor @objc public static var idenfyBlack = UIColor.black
    @MainActor @objc public static var idenfyBlackV2 = UIColor(hexString: "#19181D")
    @MainActor @objc public static var idenfyDrawerBackgroundColor = UIColor.black.withAlphaComponent(0.6)
    @MainActor @objc public static var idenfyBackgroundColorV2 = UIColor(hexString: "#FBFBFB")
    @MainActor @objc public static var idenfyMainColorV2 = UIColor(hexString: "#536DFE")
    @MainActor @objc public static var idenfyMainDarkerColorV2 = UIColor(hexString: "#5D7CE4")
    @MainActor @objc public static var idenfySecondColorV2 = UIColor(hexString: "#353B4E")
    @MainActor @objc public static var idenfyStepSuccessColorV2 = IdenfyCommonColors.idenfyMainDarkerColorV2
    @MainActor @objc public static var idenfyStepErrorColorV2 = UIColor(hexString: "#D32F2F")
    @MainActor @objc public static var idenfyTakePhotoButtonBackgroundFocused = IdenfyCommonColors.idenfyMainDarkerColorV2
    @MainActor @objc public static var idenfyTakePhotoButtonIconUnFocused = IdenfyCommonColors.idenfyMainDarkerColorV2
    @MainActor @objc public static var idenfyGradientColor1V2 = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyGradientColor2V2 = UIColor(hexString: "#8D6CFB")
    @MainActor @objc public static var idenfyPhotoResultDetailsCardBackgroundColorV2 = UIColor(hexString: "#D9DFFC")
    @MainActor @objc public static var idenfyFaceDetectedColor = UIColor(hexString: "9CEE13")
    @MainActor @objc public static var idenfyFaceNotDetectedColor = UIColor(hexString: "CFD8DC")
    @MainActor @objc public static var idenfyDarkRedErrorColorV2 = UIColor(hexString: "#C1170B")
    @MainActor @objc public static var idenfyRedColorV2 = UIColor(hexString: "#F44336")
    @MainActor @objc public static var idenfyErrorLightRedColorV2 = UIColor(hexString: "#FFEBEE")
    @MainActor @objc public static var idenfyWarningLightYellowV2 = UIColor(hexString: "#FFF3E0")
    @MainActor @objc public static var idenfyWarningYellowV2 = UIColor(hexString: "#FF9800")
    @MainActor @objc public static var idenfyBackgroundGreenV2 = UIColor(hexString: "#E8f5E9")
    @MainActor @objc public static var idenfyBorderGreenV2 = UIColor(hexString: "#00C853")
    @MainActor @objc public static var idenfyPurpleV2 = UIColor(hexString: "#734BFB")
    @MainActor @objc public static var idenfyPurpleTextV2 = UIColor(hexString: "#452D97")
    @MainActor @objc public static var idenfyBackgroundPurpleV2 = UIColor(hexString: "#EFEBFF")
    @MainActor @objc public static var idenfyLightBlueColor = UIColor(hexString: "#E9F2FF")
    @MainActor @objc public static var idenfyBlueColor = UIColor(hexString: "#1E7AFD")
    @MainActor @objc public static var idenfyLightGrayColor = UIColor(hexString: "#F2F4F8")
}
