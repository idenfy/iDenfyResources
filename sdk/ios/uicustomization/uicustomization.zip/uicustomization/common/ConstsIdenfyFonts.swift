//
//  ConstsIdenfyFonts.swift
//  iDenfySDK
//
//  Created by Viktor Vostrikov on 2020-01-23.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

// swiftlint:disable all

@MainActor @objc open class ConstsIdenfyFonts: NSObject {
    // Custom font file names - set these to use your own fonts from main bundle
    // Example: ConstsIdenfyFonts.customFontBoldFileName = "Poppins-Bold.ttf"
    @objc public static var customFontBoldFileName: String?
    @objc public static var customFontSemiBoldFileName: String?
    @objc public static var customFontRegularFileName: String?

    // Runtime font names (updated dynamically based on loaded fonts)
    @objc public static var idenfyFontBoldV2 = "HKGrotesk-Bold"
    @objc public static var idenfyFontSemiBoldV2 = "HKGrotesk-SemiBold"
    @objc public static var idenfyFontRegularV2 = "HKGrotesk-Regular"

    public static let defaultBoldFileName = "hkgrotesk_bold.ttf"
    public static let defaultRegularFileName = "hkgrotesk_regular.ttf"
    public static let defaultSemiBoldFileName = "hkgrotesk_semibold.ttf"

    public static func updateFontName(fontType: String, postScriptName: String) {
        switch fontType {
        case "bold":
            idenfyFontBoldV2 = postScriptName
        case "semibold":
            idenfyFontSemiBoldV2 = postScriptName
        case "regular":
            idenfyFontRegularV2 = postScriptName
        default:
            break
        }
    }
}
