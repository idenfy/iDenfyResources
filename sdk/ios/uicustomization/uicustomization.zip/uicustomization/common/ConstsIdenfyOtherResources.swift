//
//  ConstsIdenfyOtherResources.swift
//  idenfyviews
//
//  Created by Viktor Vostrikov on 2020-06-08.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation

// swiftlint:disable all

@objc open class ConstsIdenfyOtherResources: NSObject {
    public static let idenfy_custom_animation_splash_screen_loading_indicator = "idenfy_custom_animation_splash_screen_loading_indicator"
    public static let idenfy_custom_animation_nfc_screen_loading_indicator = "idenfy_custom_animation_nfc_screen_loading_indicator"
    public static let idenfy_custom_animation_nfc_reading_progress = "idenfy_custom_animation_nfc_reading_progress"
    public static let idenfy_custom_animation_nfc_reading_tutorial = "idenfy_custom_animation_nfc_reading_tutorial"
    public static let idenfy_custom_animation_photo_result_loading_indicator = "idenfy_custom_animation_photo_result_loading_indicator"
    public static let idenfy_custom_country_loader = "idenfy_custom_country_loader"
    public static let idenfy_custom_file_loader = "idenfy_custom_file_loader"
    public static let idenfy_custom_animation_manual_review_loading_spinner = "idenfy_custom_animation_manual_review_loading_spinner"
    public static let idenfy_custom_animation_loading_hud = "idenfy_custom_animation_loading_hud"
}
