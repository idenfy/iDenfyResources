//
//  ConstsIdenfyImages.swift
//  iDenfySDK
//
//  Created by Viktor Vostrikov on 08/10/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

// swiftlint:disable all

@objc open class ConstsIdenfyImages: NSObject {
    static let idenfy_ic_documents_type_selection_forward_step = "idenfy_ic_documents_type_selection_forward_step"
    static let idenfy_ic_initial_agreement_and_documents_selection_navigation_back = "idenfy_ic_initial_agreement_and_documents_selection_navigation_back"
    static let idenfy_custom_drawable_face_camera_preview_session_shoulders_overlay = "idenfy_custom_drawable_face_camera_preview_session_shoulders_overlay"

    static let
        idenfy_ic_initial_agreement_countries_selection_button_spinner_arrow = "idenfy_ic_initial_agreement_countries_selection_button_spinner_arrow"

    static let idenfy_ic_navigation_back = "idenfy_ic_navigation_back"

    static let idenfy_custom_drawable_camera_preview_session_take_picture_background = "idenfy_custom_drawable_camera_preview_session_take_picture_background"

    static let idenfy_custom_drawable_camera_preview_session_take_picture = "idenfy_custom_drawable_camera_preview_session_take_picture"
    
    static let idenfy_ic_password = "idenfy_ic_password"
    static let idenfy_ic_username = "idenfy_ic_username"
    static let idenfy_ic_external_phone = "idenfy_ic_external_phone"

    // Splash
    static let idenfy_ic_splash_screen_logo = "idenfy_ic_splash_screen_logo"
    static let idenfy_ic_powered_by_idenfy_v2 = "idenfy_ic_powered_by_idenfy_v2"

    // Confirmation
    static let idenfy_ic_confirmation_document_circle = "idenfy_ic_confirmation_document_circle"
    static let idenfy_ic_documents_type_selection_id_card_v2 = "idenfy_ic_documents_type_selection_id_card_v2"
    static let idenfy_ic_confirmation_item_step_circle = "idenfy_ic_confirmation_item_step_circle"
    static let idenfy_ic_confirmation_upload_photo = "idenfy_ic_confirmation_upload_photo"
    
    //Additional support
    static let idenfy_ic_session_expired = "idenfy_ic_session_expired"

    // Country selection
    static let idenfy_ic_country_selection_search = "idenfy_ic_country_selection_search"

    // Identification results
    static let idenfy_ic_identification_results_mismatch_descriptions_circle = "idenfy_ic_identification_results_mismatch_descriptions_circle"
    
    // Success view
    static let idenfy_ic_results_view_step_spinner_status_success_v2 = "idenfy_ic_results_view_step_spinner_status_success_v2"
    
    // Identification suspected view
    static let idenfy_ic_identification_suspected = "idenfy_ic_identification_suspected"

    // Manual reviewing view
    static let idenfy_ic_manual_reviewing_status_waiting_v2 = "idenfy_ic_manual_reviewing_status_waiting_v2"

    static let idenfy_ic_manual_reviewing_status_approved_v2 = "idenfy_ic_manual_reviewing_status_approved_v2"

    static let idenfy_ic_manual_reviewing_status_failed_v2 = "idenfy_ic_manual_reviewing_status_failed_v2"

    static let idenfy_ic_identification_manual_results_waiting_view_completed_step_tick = "idenfy_ic_identification_manual_results_waiting_view_completed_step_tick"
    
    static let idenfy_ic_manual_reviewing_timer_v2 = "idenfy_ic_manual_reviewing_timer_v2"

    
    // Common
    static let idenfy_ic_idenfy_logo_vector_v2 = "idenfy_ic_idenfy_logo_vector_v2"
    static let idenfy_ic_logo_free_v2 = "idenfy_ic_logo_free_v2"
    static let idenfy_ic_navigation_back_v2 = "idenfy_ic_navigation_back_v2"
    static let idenfy_ic_language_selection_close_button = "idenfy_ic_language_selection_close_button"
    static let idenfy_ic_radio_checked = "idenfy_ic_radio_checked"
    static let idenfy_ic_radio_unchecked = "idenfy_ic_radio_unchecked"
    static let idenfy_ic_calendar = "idenfy_ic_calendar"
    static let idenfy_ic_arrow_down = "idenfy_ic_arrow_down"

    // Language selection
    static let idenfy_ic_language_selection_button = "idenfy_ic_language_selection_button"

    static let idenfy_ic_language_selection_language_selected_tick = "idenfy_ic_language_selection_language_selected_tick"

    // Camera session
    static let idenfy_custom_drawable_camera_preview_session_upload_photo_icon_v2 = "idenfy_custom_drawable_camera_preview_session_upload_photo_icon_v2"

    static let idenfy_custom_drawable_camera_preview_session_take_photo_icon_v2 = "idenfy_custom_drawable_camera_preview_session_take_photo_icon_v2"

    static let idenfy_ic_camera_preview_switch_lens = "idenfy_ic_camera_preview_switch_lens"

    static let idenfy_ic_photo_result_view_details_card_questionmark = "idenfy_ic_photo_result_view_details_card_questionmark"
    
    static let idenfy_ic_privacy_lock = "idenfy_ic_privacy_lock"
    static let idenfy_ic_privacy_security = "idenfy_ic_privacy_security"
    static let idenfy_ic_privacy_access = "idenfy_ic_privacy_access"
    static let idenfy_ic_privacy_block_share = "idenfy_ic_privacy_block_share"
    
    static let idenfy_ic_privacy_photo_identity_step = "idenfy_ic_privacy_photo_identity_step"
    static let idenfy_ic_privacy_selfie_check_step = "idenfy_ic_privacy_selfie_check_step"
    static let idenfy_ic_privacy_automated_verification_step = "idenfy_ic_privacy_automated_verification_step"
    
    static let idenfy_ic_flash_off = "idenfy_ic_flash_off"
    static let idenfy_ic_flash_on = "idenfy_ic_flash_on"
    static let idenfy_ic_open_instructions_dialog = "idenfy_ic_open_instructions_dialog"
    static let idenfy_ic_camera_onboarding_other_document_image = "idenfy_ic_camera_onboarding_other_document_image"
    
    static let idenfy_ic_camera_rectangle_v2 = "idenfy_ic_camera_rectangle_v2"
    static let idenfy_ic_camera_powered_by_idenfy_v2 = "idenfy_ic_camera_powered_by_idenfy_v2"
    
    static let idenfy_ic_document_angle_detection_model_bottom_left = "idenfy_ic_document_angle_detection_model_bottom_left"
    static let idenfy_ic_document_angle_detection_model_bottom_right = "idenfy_ic_document_angle_detection_model_bottom_right"
    static let idenfy_ic_document_angle_detection_model_top_right = "idenfy_ic_document_angle_detection_model_top_right"
    static let idenfy_ic_document_angle_detection_model_top_left = "idenfy_ic_document_angle_detection_model_top_left"
    static let idenfy_ic_document_angle_detection_model_center = "idenfy_ic_document_angle_detection_model_center"
    
    static let idenfy_ic_validation_face_not_found = "idenfy_ic_validation_face_not_found"
    static let idenfy_ic_validation_too_many_faces = "idenfy_ic_validation_too_many_faces"
    static let idenfy_ic_validation_face_angle_too_large = "idenfy_ic_validation_face_angle_too_large"
    static let idenfy_ic_validation_face_too_small = "idenfy_ic_validation_face_too_small"
    static let idenfy_ic_validation_face_close_to_border = "idenfy_ic_validation_face_close_to_border"
    static let idenfy_ic_validation_face_too_close = "idenfy_ic_validation_face_too_close"
    static let idenfy_ic_validation_face_cropped = "idenfy_ic_validation_face_cropped"
    static let idenfy_ic_validation_face_is_occluded = "idenfy_ic_validation_face_is_occluded"
    static let idenfy_ic_validation_eyes_closed = "idenfy_ic_validation_eyes_closed"
    static let idenfy_ic_validation_document_not_detected = "idenfy_ic_validation_document_not_detected"
    static let idenfy_ic_validation_document_photo_not_found = "idenfy_ic_validation_document_photo_not_found"
    static let idenfy_ic_validation_relative_document_size_lower_than_10_percent = "idenfy_ic_validation_relative_document_size_lower_than_10_percent"
    static let idenfy_ic_validation_document_borders_outside_of_frame = "idenfy_ic_validation_document_borders_outside_of_frame"
    static let idenfy_ic_validation_multiple_documents_in_frame = "idenfy_ic_validation_multiple_documents_in_frame"
    static let idenfy_ic_validation_digital_document_shown = "idenfy_ic_validation_digital_document_shown"
    static let idenfy_ic_validation_document_warning = "idenfy_ic_validation_document_warning"
    static let idenfy_ic_validation_next_step = "idenfy_ic_validation_next_step"
    static let idenfy_ic_validation_document_too_close_to_border = "idenfy_ic_validation_document_too_close_to_border"
    static let idenfy_ic_validation_document_blur = "idenfy_ic_validation_document_blur"
    static let idenfy_ic_validation_document_glare = "idenfy_ic_validation_document_glare"
    static let idenfy_ic_validation_document_blur_glare = "idenfy_ic_validation_document_blur_glare"
    static let idenfy_ic_validation_document_poor_exposure = "idenfy_ic_validation_document_poor_exposure"
    static let idenfy_ic_validation_document_too_compressed = "idenfy_ic_validation_document_too_compressed"


    // Camera permissions
    static let idenfy_ic_camera_permissions_v2 = "idenfy_ic_camera_permissions_v2"

    
    static let idenfy_ic_info_alert = "idenfy_ic_info_alert"
    static let idenfy_ic_face_detected = "idenfy_ic_face_detected"
    static let idenfy_ic_face_authentication = "idenfy_ic_face_authentication"
    static let idenfy_ic_warning_alert = "idenfy_ic_warning_alert"
    
    //NFC
    static let idenfy_ic_nfc_reading_failure = "idenfy_ic_nfc_reading_failure"
    static let idenfy_ic_nfc_reading_success = "idenfy_ic_nfc_reading_success"
    
    // Bank verification
    static let idenfy_ic_success_checkmark = "idenfy_ic_success_checkmark"
    static let idenfy_ic_information_icon = "idenfy_ic_information_icon"
    static let idenfy_ic_failed_checkmark = "idenfy_ic_failed_checkmark"
    
    // Email verification
    static let idenfy_ic_email_verification = "idenfy_ic_email_verification"
    
    // SMS verification
    static let idenfy_ic_sms_verification = "idenfy_ic_sms_verification"
}
