//
//  IdenfyIdentificationResultsViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyIdentificationResultsViewUISettingsV2: NSObject {
    // Idenfy Identification Results View Colors

    @MainActor @objc public static var idenfyIdentificationResultsViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyIdentificationResultsViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIdentificationResultsViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepLoadingSpinnerAccentColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyIdentificationResultsViewRetakeButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyIdentificationResultsViewContentMaskForegroundColor = IdenfyCommonColors.idenfyBackgroundColorV2.withAlphaComponent(0.6)
    @MainActor @objc public static var idenfyIdentificationResultsViewSuccessStepTextColor = IdenfyCommonColors.idenfyStepSuccessColorV2
    @MainActor @objc public static var idenfyIdentificationResultsViewErrorStepTextColorV2 = IdenfyCommonColors.idenfyStepErrorColorV2

    // Idenfy Identification Results View Fonts

    @MainActor @objc public static var idenfyIdentificationResultsViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyIdentificationResultsViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepHighlightedTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)

    // Idenfy Identification Results Style

    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepLoadingSpinnerAnimationDuration = Double(4)
    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepLoadingSpinnerRadius = CGFloat(30)
    @MainActor @objc public static var idenfyIdentificationResultsViewDocumentStepLoadingSpinnerNumberOfPulses = Int(6)

    // Idenfy Identification Results Dividers colors
    @MainActor @objc public static var idenfyIdentificationResultsDividerIconStatusLoadingTintColor: UIColor? = IdenfyCommonColors.idenfyMainColorV2.withAlphaComponent(0.3)
    @MainActor @objc public static var idenfyIdentificationResultsDividerIconStatusErrorTintColor: UIColor? = IdenfyCommonColors.idenfyStepErrorColorV2
    @MainActor @objc public static var idenfyIdentificationResultsDividerIconStatusSuccessTintColor: UIColor? = IdenfyCommonColors.idenfyStepSuccessColorV2
}
