//
//  IdenfyFaceAuthenticationCommonUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2023-06-26.
//  Copyright © 2023 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyFaceAuthenticationCommonUISettingsV2: NSObject {

    // Face Authentication Retry Alert Colors
    @MainActor @objc public static var idenfyFaceAuthenticationRetryAlertViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationRetryCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationRetryCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationRetryAlertRetryButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyFaceAuthenticationRetryAlertRetryButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationRetryAlertRetryButtonButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    
    // Face Authentication Retry Alert Fonts
    @MainActor @objc public static var idenfyGlareAndBlurAlertCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 24)
    @MainActor @objc public static var idenfyGlareAndBlurAlertCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
}
