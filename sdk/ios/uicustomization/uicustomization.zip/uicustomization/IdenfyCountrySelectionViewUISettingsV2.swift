//
//  IdenfyCountrySelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyCountrySelectionViewUISettingsV2: NSObject {
    // Idenfy Country Selection View Colors

    @MainActor @objc public static var idenfyCountrySelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellHighlightedTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellHighlightedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarSearchIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountrySelectionViewCountryLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Country Selection View Fonts

    @MainActor @objc public static var idenfyCountrySelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyCountrySelectionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyCountrySelectionViewSearchBarHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyCountrySelectionViewSearchBarFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewHighlightedCellFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)

    // Idenfy Country Selection View Style

    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyCountrySelectionViewCountrySearchBarCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryFlagBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyCountrySelectionViewCountryTableViewCellHeight = CGFloat(50)
}
