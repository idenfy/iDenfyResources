//
//  IdenfyQuestionnaireViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2022-09-19.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyQuestionnaireViewUISettingsV2: NSObject {
    // Idenfy Questionnaire View Colors

    @objc public static var idenfyQuestionnaireViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyQuestionnaireViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyQuestionnaireViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyQuestionnaireViewSectionTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyQuestionnaireViewSectionDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyQuestionnaireViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @objc public static var idenfyQuestionnaireViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @objc public static var idenfyQuestionnaireViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    
    // Question Cells
    @objc public static var idenfyTextQuestionCellViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyTextQuestionCellViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyTextQuestionCellViewTextFieldTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyTextQuestionCellViewTextFieldPlaceholderTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @objc public static var idenfyTextQuestionCellViewTextFieldBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyTextQuestionCellViewTextFieldBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @objc public static var idenfyTextQuestionCellViewTextFieldHighlightedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyTextQuestionCellViewTextFieldErrorBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @objc public static var idenfyPasswordQuestionCellViewPasswordVisibilityIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCheckBoxQuestionCellViewUISwitchTintColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyCheckBoxQuestionCellViewUISwitchDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyFileQuestionCellViewContainerBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyFileQuestionCellViewContainerBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06).cgColor
    @objc public static var idenfyFileQuestionCellViewUploadIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyFileQuestionCellViewCancelIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyFileQuestionCellViewFileDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyRadioQuestionCellViewRadioButtonTintColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyRadioQuestionCellViewRadioButtonDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyDateQuestionCellViewCancelButtonTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyDateQuestionCellViewCalendarIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyDateQuestionCellViewTimerIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCountryQuestionCellViewCountryLabelTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCountryQuestionCellViewCountryPlaceholderTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @objc public static var idenfyCountryQuestionCellViewCancelIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCountryQuestionCellViewArrowIconTintColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyInputFieldErrorMessageTextColor = IdenfyCommonColors.idenfyRedColorV2
    @objc public static var idenfyColorQuestionColorPickerOkButtonColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyColorQuestionColorPickerCloseButtonColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyColorQuestionColorPickerDescriptionColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyColorQuestionColorPickerBorderColor = IdenfyCommonColors.idenfySecondColorV2

    // Idenfy Questionnaire View Fonts

    @objc public static var idenfyQuestionnaireViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyQuestionnaireViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyQuestionnaireViewSectionTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyQuestionnaireViewSectionDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyColorQuestionColorPickerDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyColorQuestionColorPickerOkButtonFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    
    // Question Cells
    @objc public static var idenfyTextQuestionCellViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyTextQuestionCellViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyTextQuestionCellTextFieldFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyCheckBoxQuestionCellViewUISwitchDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyFileQuestionCellViewFileDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyRadioQuestionCellViewRadioButtonDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyCountryQuestionCellViewCountryLabelFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyInputFieldErrorMessageFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)

    // Idenfy Questionnaire View Styles
    
    // Question Cells
    @objc public static var idenfyTextQuestionCellViewTextFieldCornerRadius = CGFloat(3)
    @objc public static var idenfyTextQuestionCellViewTextFieldBorderWidth = CGFloat(1)
    @objc public static var idenfyFileQuestionCellViewContainerBorderWidth = CGFloat(1)
    @objc public static var idenfyFileQuestionCellViewContainerCornerRadius = CGFloat(3)
    @objc public static var idenfyColorQuestionColorPickerBorderCornerRadius = CGFloat(3)
    @objc public static var idenfyColorQuestionColorPickerBorderWidth = CGFloat(1)
}
