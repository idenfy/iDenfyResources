//
//  IdenfyDrawerUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyDrawerUISettingsV2: NSObject {
    
    // Idenfy Drawer Colors
    @objc public static var idenfyDrawerTitleTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDrawerDescriptionTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDrawerBackButtonTintColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Drawer Fonts
    @objc public static var idenfyDrawerTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyDrawerDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
}
