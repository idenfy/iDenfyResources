//
//  IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-07-02.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2: NSObject {

    // BankCardVerificationPrivacyPolicyViewV2 Colors
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCardItemTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCardItemIconColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCardBackgroundColor = IdenfyCommonColors.idenfyLightGrayColor
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyAgreeButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyHighlightedPolicyTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyAgreeButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    // BankCardVerificationPrivacyPolicyViewV2 Fonts
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCardItemFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyHighlightedPolicyFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)

    // BankCardVerificationPrivacyPolicyViewV2 Styles
    @MainActor @objc public static var idenfyBankCardVerificationPrivacyPolicyCardBorderRadius: CGFloat = 4
}
