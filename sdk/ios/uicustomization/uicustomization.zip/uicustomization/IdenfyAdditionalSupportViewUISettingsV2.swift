//
//  IdenfyAdditionalSupportViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-02-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyAdditionalSupportViewUISettingsV2: NSObject {
    // AdditionalSupportViewV2 Colors

    @MainActor @objc public static var idenfyAdditionalSupportViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyAdditionalSupportViewCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyAdditionalSupportViewCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyAdditionalSupportViewCommonInformationDescriptionEmailTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyAdditionalSupportViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // AdditionalSupportViewV2 Fonts

    @MainActor @objc public static var idenfyAdditionalSupportViewCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyAdditionalSupportViewCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyAdditionalSupportViewCommonInformationDescriptionEmailFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
}
