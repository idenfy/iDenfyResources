//
//  IdenfyDocumentCameraSessionUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyDocumentCameraSessionUISettingsV2: NSObject {
    // Idenfy Document Camera Preview Session Colors

    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionBackgroundColor = IdenfyCommonColors.idenfyBlack
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionBottomActionButtonsViewBackgroundColor = IdenfyCommonColors.idenfyDrawerBackgroundColor
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = IdenfyCommonColors.idenfyTakePhotoButtonIconUnFocused
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionTakePhotoButtonFocusedTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionTakePhotoButtonFocusedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = IdenfyCommonColors.idenfyWhite.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionToggleFlashButtonTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionSwitchLensButtonTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessioninstructionDialogButtonTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyDocumentCameraAlertCardBackgroundColor = IdenfyCommonColors.idenfyWarningLightYellowV2.withAlphaComponent(0.7)
    @MainActor @objc public static var idenfyDocumentCameraAlertCardImageTintColor = IdenfyCommonColors.idenfyWarningYellowV2.withAlphaComponent(0.7)
    @MainActor @objc public static var idenfyDocumentCameraAlertCardTitleColor = IdenfyCommonColors.idenfyBlack.withAlphaComponent(0.7)
    
    // Idenfy Document Camera Preview Session Fonts
    @MainActor @objc public static var idenfyDocumentCameraAlertCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
}
