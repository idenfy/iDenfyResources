//
//  EIDSessionUploadViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 20/05/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class EIDSessionUploadViewUISettingsV2: NSObject {

    // Idenfy EID Session Upload View Colors

    @MainActor @objc public static var idenfyEIDSessionUploadViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadAreaBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadAreaBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewClickToUploadTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadLabelTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionUploadViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionUploadViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionUploadViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionUploadViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionUploadViewErrorCardBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewErrorCardBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewErrorCardIconTintColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionUploadViewErrorCardTextColor = IdenfyCommonColors.idenfySecondColorV2

    // Idenfy EID Session Upload View Fonts

    @MainActor @objc public static var idenfyEIDSessionUploadViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEIDSessionUploadViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadLabelFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyEIDSessionUploadViewClickToUploadFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
    @MainActor @objc public static var idenfyEIDSessionUploadViewErrorCardTextFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)

    // Idenfy EID Session Upload View Styles

    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadAreaCornerRadius = CGFloat(4)
    @MainActor @objc public static var idenfyEIDSessionUploadViewUploadAreaBorderWidth = CGFloat(1)
}
