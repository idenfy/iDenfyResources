//
//  IdenfyPdfResultViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-06-16.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyPdfResultViewUISettingsV2: NSObject {
    // Idenfy PDF Results View Colors

    @MainActor @objc public static var idenfyPdfResultViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyPdfResultViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPdfResultViewRetakePdfButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyPdfResultViewRetakePdfButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPdfResultViewRetakePdfButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPdfResultViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyPdfResultViewDetailsCardBackgroundColor = IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2
    @MainActor @objc public static var idenfyPdfResultViewDetailsCardTitleColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPdfResultViewTitleColor = IdenfyCommonColors.idenfySecondColorV2

    // Idenfy PDF Results View Fonts

    @MainActor @objc public static var idenfyPdfResultViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 20)
    @MainActor @objc public static var idenfyPdfResultViewDetailsCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)

    // Idenfy PDF Results View Style

    @MainActor @objc public static var idenfyPdfResultViewDetailsCardCornerRadius = CGFloat(4)
}
