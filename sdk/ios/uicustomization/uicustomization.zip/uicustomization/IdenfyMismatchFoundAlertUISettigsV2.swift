//
//  IdenfyMismatchFoundAlertUISettigsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 30/01/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyMismatchFoundAlertUISettigsV2: NSObject {
    // Mismatch Found Alert Colors
    @MainActor @objc public static var idenfyMismatchFoundAlertViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyMismatchFoundAlertCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMismatchFoundAlertCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMismatchFoundAlertContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyMismatchFoundAlertContinueDisabledButtonTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyMismatchFoundAlertContinueDisabledButtonBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyMismatchFoundAlertMismatchDescriptionsCircleTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMismatchFoundAlertMismatchDescriptionsListTextColor = IdenfyCommonColors.idenfySecondColorV2
    
    // Mismatch Found Alert Fonts
    @MainActor @objc public static var idenfyMismatchFoundAlertCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyMismatchFoundAlertCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyMismatchFoundAlertMismatchDescriptionsListFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
}
