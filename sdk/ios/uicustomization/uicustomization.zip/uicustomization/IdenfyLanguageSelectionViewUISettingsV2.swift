//
//  IdenfyLanguageSelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-03-24.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyLanguageSelectionViewUISettingsV2: NSObject {
    // Idenfy Language Selection View Colors

    @MainActor @objc public static var idenfyLanguageSelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyLanguageSelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellHighlightedTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellHighlightedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2

    // Idenfy Language Selection View Fonts

    @MainActor @objc public static var idenfyLanguageSelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewHighlightedCellFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)

    // Idenfy Language Selection View Style

    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyLanguageSelectionViewLanguageTableViewCellHeight = CGFloat(50)
}
