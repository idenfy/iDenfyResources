//
//  IdenfyMFAGeneralViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-04-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyMFAGeneralViewUISettingsV2: NSObject {
    // Idenfy MFA General View Colors

    @MainActor @objc public static var idenfyMFAGeneralViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewDescriptionHighlightedTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewHintTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewInputViewHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyMFAGeneralViewInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyMFAGeneralViewInputFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFAGeneralViewInputViewBackgroundColor = UIColor.white
    @MainActor @objc public static var idenfyMFAGeneralViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyMFAGeneralViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    
    // Idenfy MFA General View Fonts

    @MainActor @objc public static var idenfyMFAGeneralViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyMFAGeneralViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyMFAGeneralViewHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor  @objc public static var idenfyMFAGeneralViewInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)
    @MainActor @objc public static var idenfyMFAGeneralViewDescriptionHighlightedTextFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)

    // Idenfy MFA General View Style

    @MainActor @objc public static var idenfyMFAGeneralViewInputViewCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyMFAGeneralViewInputViewBorderWidth = CGFloat(1)
}
