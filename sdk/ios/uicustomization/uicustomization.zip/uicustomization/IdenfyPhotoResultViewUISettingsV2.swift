//
//  IdenfyPhotoResultViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyPhotoResultViewUISettingsV2: NSObject {
    // Idenfy Photo Results View Colors

    @objc public static var idenfyPhotoResultViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyPhotoResultViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyPhotoResultViewDescriptionTextColor =
        IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyPhotoResultViewRetakePhotoButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyPhotoResultViewRetakePhotoButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyPhotoResultViewRetakePhotoButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyPhotoResultViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyPhotoResultViewPhotoBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyPhotoResultViewDetailsCardBackgroundColor = IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2
    @objc public static var idenfyPhotoResultViewDetailsCardTitleColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyPhotoResultViewTitleColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyPhotoResultViewPoweredByIdenfyTitleColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.6)
    @objc public static var idenfyPhotoResultViewAutoCaptureFailureCardImageColor = IdenfyCommonColors.idenfyRedColorV2
    @objc public static var idenfyPhotoResultViewAutoCaptureFailureCardTitleColor = IdenfyCommonColors.idenfyRedColorV2
    @objc public static var idenfyPhotoResultViewAutoCaptureFailureCardBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2

    // Idenfy Photo Results View Fonts

    @objc public static var idenfyPhotoResultViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 20)
    @objc public static var idenfyPhotoResultViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyPhotoResultViewDetailsCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
    @objc public static var idenfyPhotoResultViewPoweredByIdenfyTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)

    // Idenfy Photo Results View Style

    @objc public static var idenfyPhotoResultViewPhotoBorderWidth = CGFloat(2)
    @objc public static var idenfyPhotoResultViewPhotoCornerRadius = CGFloat(4)
    @objc public static var idenfyPhotoResultViewDetailsCardCornerRadius = CGFloat(4)
}
