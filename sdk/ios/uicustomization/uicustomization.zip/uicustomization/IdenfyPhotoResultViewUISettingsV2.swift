//
//  IdenfyPhotoResultViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyPhotoResultViewUISettingsV2: NSObject {
    // Idenfy Photo Results View Colors

    @MainActor @objc public static var idenfyPhotoResultViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyPhotoResultViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPhotoResultViewDescriptionTextColor =
        IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPhotoResultViewRetakePhotoButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyPhotoResultViewRetakePhotoButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPhotoResultViewRetakePhotoButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPhotoResultViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyPhotoResultViewPhotoBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPhotoResultViewDetailsCardBackgroundColor = IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2
    @MainActor @objc public static var idenfyPhotoResultViewDetailsCardTitleColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPhotoResultViewTitleColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPhotoResultViewPoweredByIdenfyTitleColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.6)
    @MainActor @objc public static var idenfyPhotoResultViewAutoCaptureFailureCardImageColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyPhotoResultViewAutoCaptureFailureCardTitleColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyPhotoResultViewAutoCaptureFailureCardBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyPhotoResultViewPhotoBlurGlareCardImageColor = IdenfyCommonColors.idenfyWarningYellowV2
    @MainActor @objc public static var idenfyPhotoResultViewPhotoBlurGlareCardTitleColor = IdenfyCommonColors.idenfyWarningYellowV2
    @MainActor @objc public static var idenfyPhotoResultViewPhotoBlurGlareCardBackgroundColor = IdenfyCommonColors.idenfyWarningLightYellowV2

    // Idenfy Photo Results View Fonts

    @MainActor @objc public static var idenfyPhotoResultViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 20)
    @MainActor @objc public static var idenfyPhotoResultViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyPhotoResultViewDetailsCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
    @MainActor @objc public static var idenfyPhotoResultViewPoweredByIdenfyTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)

    // Idenfy Photo Results View Style

    @MainActor @objc public static var idenfyPhotoResultViewPhotoBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyPhotoResultViewPhotoCornerRadius = CGFloat(4)
    @MainActor @objc public static var idenfyPhotoResultViewDetailsCardCornerRadius = CGFloat(4)
}
