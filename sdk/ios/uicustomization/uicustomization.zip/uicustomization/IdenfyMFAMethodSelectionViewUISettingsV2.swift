//
//  IdenfyMFAMethodSelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-04-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyMFAMethodSelectionViewUISettingsV2: NSObject {
    // Idenfy MFA Method Selection View Colors

    @objc public static var idenfyMFAMethodSelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyMFAMethodSelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyMFAMethodSelectionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyMFAMethodSelectionViewHintTextColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyMFAMethodSelectionViewInputViewHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @objc public static var idenfyMFAMethodSelectionViewInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyMFAMethodSelectionViewInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @objc public static var idenfyMFAMethodSelectionViewInputFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyMFAMethodSelectionViewInputViewBackgroundColor = UIColor.white
    @objc public static var idenfyMFAMethodSelectionViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    
    // Idenfy MFA Method Selection View Fonts

    @objc public static var idenfyMFAMethodSelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyMFAMethodSelectionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyMFAMethodSelectionViewHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @objc public static var idenfyMFAMethodSelectionViewInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)

    // Idenfy MFA Method Selection View Style

    @objc public static var idenfyMFAMethodSelectionViewInputViewCorderRadius = CGFloat(3)
    @objc public static var idenfyMFAMethodSelectionViewInputViewBorderWidth = CGFloat(1)
}
