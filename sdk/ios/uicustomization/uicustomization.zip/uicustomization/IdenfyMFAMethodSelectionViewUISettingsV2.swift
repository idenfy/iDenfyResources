//
//  IdenfyMFAMethodSelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-04-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyMFAMethodSelectionViewUISettingsV2: NSObject {
    // Idenfy MFA Method Selection View Colors

    @MainActor @objc public static var idenfyMFAMethodSelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyMFAMethodSelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFAMethodSelectionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFAMethodSelectionViewHintTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputViewHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputViewBackgroundColor = UIColor.white
    @MainActor @objc public static var idenfyMFAMethodSelectionViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyMFAMethodSelectionViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    
    // Idenfy MFA Method Selection View Fonts

    @MainActor @objc public static var idenfyMFAMethodSelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyMFAMethodSelectionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyMFAMethodSelectionViewHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)

    // Idenfy MFA Method Selection View Style

    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputViewCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyMFAMethodSelectionViewInputViewBorderWidth = CGFloat(1)
}
