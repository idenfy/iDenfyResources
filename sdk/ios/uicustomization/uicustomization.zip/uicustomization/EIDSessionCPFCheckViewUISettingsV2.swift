//
//  EIDSessionCPFCheckViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 02/10/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class EIDSessionCPFCheckViewUISettingsV2: NSObject {

    // Idenfy EID Session CPF Check View Colors

    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewErrorCardBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewErrorCardBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewErrorCardIconTintColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewErrorCardTextColor = IdenfyCommonColors.idenfySecondColorV2

    // CPF Input specific colors
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewCpfInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewCpfInputErrorBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewCpfInputTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewCpfInputPlaceholderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewCpfErrorTextColor = IdenfyCommonColors.idenfyRedColorV2

    // Date of birth input colors
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewDateOfBirthInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewDateOfBirthInputTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewDateOfBirthInputPlaceholderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)

    // Idenfy EID Session CPF Check View Fonts

    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewErrorCardTextFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewCpfInputFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewDateOfBirthInputFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)

    // Idenfy EID Session CPF Check View Styles

    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewInputCornerRadius = CGFloat(4)
    @MainActor @objc public static var idenfyEIDSessionCPFCheckViewInputBorderWidth = CGFloat(1)
}
