//
//  IdenfyBankCardVerificationResultsViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-07-02.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardVerificationResultsViewUISettingsV2: NSObject {

    @MainActor @objc public static var idenfyBankCardVerificationResultsViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardVerificationResultsViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardVerificationResultsViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardVerificationResultsViewSuccessIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardVerificationResultsViewFailedIconTintColor = UIColor.systemRed
    @MainActor @objc public static var idenfyBankCardVerificationResultsViewButtonTextColor = IdenfyCommonColors.idenfyWhite
}
