//
//  IdenfyApprovedAfterManualReviewingViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-07-21.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyManualReviewingStatusApprovedViewUISettingsV2: NSObject {
    // ManualReviewingStatusApprovedViewV2 Colors

    @MainActor @objc public static var idenfyManualReviewingStatusApprovedViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusApprovedCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusApprovedCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusApprovedContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // ManualReviewingStatusApprovedViewV2 Fonts

    @MainActor @objc public static var idenfyManualReviewingStatusApprovedCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyManualReviewingStatusApprovedCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
}
