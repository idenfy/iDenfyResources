//
//  IdenfyProviderLoginViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-05-05.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyProviderLoginViewUISettingsV2: NSObject {
    // Idenfy Provider Login View Colors

    @MainActor @objc public static var idenfyProviderLoginViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyProviderLoginViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyProviderLoginViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyProviderLoginViewUsernameHintTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputViewHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputViewHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordHintTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputViewBackgroundColor = UIColor.white
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputViewBackgroundColor = UIColor.white
    @MainActor @objc public static var idenfyProviderLoginViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyProviderLoginViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    
    // Idenfy Provider Login View Fonts

    @MainActor @objc public static var idenfyProviderLoginViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyProviderLoginViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyProviderLoginViewUsernameHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)

    // Idenfy Provider Login View Style

    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputViewCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputViewCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyProviderLoginViewUsernameInputBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyProviderLoginViewPasswordInputBorderWidth = CGFloat(1)
}
