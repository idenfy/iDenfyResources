//
//  IdenfyDocumentSelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyDocumentSelectionViewUISettingsV2: NSObject {
    // Idenfy Document Selection View Colors

    @objc public static var idenfyDocumentSelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyDocumentSelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyDocumentSelectionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellHighlightedTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellHighlightedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyDocumentSelectionViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @objc public static var idenfyDocumentSelectionViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @objc public static var idenfyDocumentSelectionViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Document Selection View Fonts

    @objc public static var idenfyDocumentSelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyDocumentSelectionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyDocumentSelectionViewDocumentTypeFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyDocumentSelectionViewDocumentTypeHighlightedFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 13)

    // Idenfy Document Selection View Style

    @objc public static var idenfyDocumentSelectionViewDocumentTableViewBorderWidth = CGFloat(2)
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCornerRadius = CGFloat(3)
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellBorderWidth = CGFloat(2)
    @objc public static var idenfyDocumentSelectionViewDocumentTableViewCellHeight = CGFloat(56)
}
