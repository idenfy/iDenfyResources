//
//  IdenfyNFCRequiredViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-04-06.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyNFCRequiredViewUISettingsV2: NSObject {
    // NFCRequiredViewV2 Colors
    
    @MainActor @objc public static var idenfyNFCRequiredViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyNFCRequiredCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyNFCRequiredCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyNFCRequiredContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyNFCRequiredCommonInformationDescriptionSupportEmailColor = IdenfyCommonColors.idenfyMainColorV2
    
    // NFCRequiredViewV2 Fonts
    
    @MainActor @objc public static var idenfyNFCRequiredCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyNFCRequiredCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyNFCRequiredCommonInformationDescriptionEmailFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
}
