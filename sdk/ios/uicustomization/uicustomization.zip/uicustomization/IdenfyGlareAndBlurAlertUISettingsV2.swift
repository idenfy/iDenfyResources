//
//  IdenfyGlareAndBlurAlertUICustomisation.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-04-26.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyGlareAndBlurAlertUISettigsV2: NSObject {
    // Glare And Blur Alert Colors
    @objc public static var idenfyGlareAndBlurAlertViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyGlareAndBlurAlertCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    
    // Glare And Blur Alert Fonts
    @objc public static var idenfyGlareAndBlurAlertCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 24)
}
