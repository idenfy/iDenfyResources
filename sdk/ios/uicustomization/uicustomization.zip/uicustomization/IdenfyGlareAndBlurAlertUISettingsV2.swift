//
//  IdenfyGlareAndBlurAlertUICustomisation.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-04-26.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyGlareAndBlurAlertUISettigsV2: NSObject {
    // Glare And Blur Alert Colors
    @MainActor @objc public static var idenfyGlareAndBlurAlertViewBackgroundColor = IdenfyCustomAlertDialogUISettings.idenfyCustomAlertDialogBackgroundColor
    @MainActor @objc public static var idenfyGlareAndBlurAlertCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyGlareAndBlurAlertCommonInformationSummaryTextColor = IdenfyCommonColors.idenfySecondColorV2
    
    // Glare And Blur Alert Fonts
    @MainActor @objc public static var idenfyGlareAndBlurAlertCommonInformationSummaryFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 20)
    @MainActor @objc public static var idenfyGlareAndBlurAlertCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
}
