//
//  IdenfyInstructionsAlertUISettigsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-05-27.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyInstructionAlertUISettigsV2: NSObject {
    // Instruction Alert Colors
    @MainActor @objc public static var idenfyInstructionAlertViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyInstructionAlertCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyInstructionAlertProgressBarFillColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyInstructionAlertContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyInstructionAlertDetailsCardBackgroundColor = IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2
    @MainActor @objc public static var idenfyInstructionAlertDetailsCardTitleColor = IdenfyCommonColors.idenfyMainColorV2
    
    // Instruction Alert Fonts
    @MainActor @objc public static var idenfyInstructionAlertCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyInstructionAlertDetailsCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
    
    // Instruction Alert Style
    @MainActor @objc public static var idenfyInstructionAlertDetailsCardCornerRadius = CGFloat(4)
}
