//
//  EIDSessionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 17/06/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class EIDSessionViewUISettingsV2: NSObject {
    
    // Idenfy EID Session View Colors
    
    @MainActor @objc public static var idenfyEIDSessionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEIDSessionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // Idenfy EID Session Fonts

    @MainActor @objc public static var idenfyEIDSessionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEIDSessionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
}
