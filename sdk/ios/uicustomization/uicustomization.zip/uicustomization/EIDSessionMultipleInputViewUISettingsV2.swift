//
//  EIDSessionMultipleInputViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 20/05/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class EIDSessionMultipleInputViewUISettingsV2: NSObject {

    // Idenfy EID Session Multiple Input View Colors

    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldPlaceHolderTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    // Idenfy EID Session Multiple Input View Fonts

    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)

    // Idenfy EID Session Multiple Input View Styles

    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyEIDSessionMultipleInputViewInputTextFieldBorderWidth = CGFloat(1)
}
