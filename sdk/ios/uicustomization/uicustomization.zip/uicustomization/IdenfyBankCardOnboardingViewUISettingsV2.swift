//
//  IdenfyBankCardOnboardingViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardOnboardingViewUISettingsV2: NSObject {

    @MainActor @objc public static var idenfyBankCardOnboardingViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardSelectedBorderColor = IdenfyCommonColors.idenfyPurpleV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardSelectedBackgroundColor = IdenfyCommonColors.idenfyBackgroundPurpleV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardSelectedTextColor = IdenfyCommonColors.idenfyPurpleTextV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardOnboardingViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyBankCardOnboardingViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyBankCardOnboardingViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardOnboardingViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardOnboardingViewPrivacyNoteTextColor = IdenfyCommonColors.idenfySecondColorV2

    @MainActor @objc public static var idenfyBankCardOnboardingViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyBankCardOnboardingViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankCardOnboardingViewPrivacyNoteFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)

    @MainActor @objc public static var idenfyBankCardOnboardingViewCardBorderWidth: CGFloat = 1
    @MainActor @objc public static var idenfyBankCardOnboardingViewCardCornerRadius: CGFloat = 8
}
