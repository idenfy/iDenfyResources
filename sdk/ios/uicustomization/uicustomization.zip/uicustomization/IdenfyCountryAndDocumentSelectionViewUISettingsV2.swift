//
//  IdenfyCountryAndDocumentSelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyCountryAndDocumentSelectionViewUISettingsV2: NSObject {
    
    // Idenfy Country And Document Selection View Colors
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewDocumentSelectionTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.1)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedBackgroundColor = IdenfyCommonColors.idenfyBackgroundPurpleV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedTextColor = IdenfyCommonColors.idenfyPurpleTextV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedBorderColor = IdenfyCommonColors.idenfyPurpleV2
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewCountryLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Country And Document Selection View Fonts
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewDocumentSelectionTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 13)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontSemiBoldV2, size: 14)

    // Idenfy Country And Document Selection View Style
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionCornerRadius = CGFloat(4)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewCountryFlagBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewItemSelectionBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyCountryAndDocumentSelectionViewCountryTableViewCellHeight = CGFloat(50)
}
