//
//  IdenfyPrivacyPolicyViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2022-10-25.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyPrivacyPolicyViewUISettingsV2: NSObject {
    
    // PrivacyPolicyViewV2 Colors
    @objc public static var idenfyPrivacyPolicyViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyPrivacyPolicyCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyPrivacyPolicyAgreeButtonTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyPrivacyPolicyDisagreeButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyPrivacyPolicyDisagreeButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyPrivacyPolicyDisagreeButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    
    // PrivacyPolicyViewV2 Disagree Dialog Colors
    
    @objc public static var idenfyPrivacyPolicyDisagreeDialogViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @objc public static var idenfyPrivacyPolicyDisagreeDialogAgreeButtonTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCancelButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCancelButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCancelButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2

    // PrivacyPolicyViewV2 Fonts
    @objc public static var idenfyPrivacyPolicyCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    
    // PrivacyPolicyViewV2 Styles
    @objc public static var idenfyPrivacyPolicyViewDisagreeButtonBorderWidth = CGFloat(2)
    
    // PrivacyPolicyViewV2 Disagree Dialog Fonts
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyPrivacyPolicyDisagreeDialogCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    
    // PrivacyPolicyViewV2 Disagree Dialog Styles
    @objc public static var idenfyPrivacyPolicyViewCancelButtonBorderWidth = CGFloat(2)
}
