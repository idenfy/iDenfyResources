//
//  IdenfyPrivacyPolicyViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2022-10-25.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyPrivacyPolicyViewUISettingsV2: NSObject {
    
    // PrivacyPolicyViewV2 Colors
    @MainActor @objc public static var idenfyPrivacyPolicyViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyCardTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyCardItemTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyCardItemIconColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyCardBackgroundColor = IdenfyCommonColors.idenfyLightGrayColor
    @MainActor @objc public static var idenfyPrivacyPolicyAgreeButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyPrivacyPolicyHighlightedPolicyTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyPrivacyPolicyAgreeButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    
    // PrivacyPolicyViewV2 Partner Dialog Colors
    @MainActor @objc public static var idenfyPartnerPrivacyPolicyDialogViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2

    // PrivacyPolicyViewV2 Fonts
    @MainActor @objc public static var idenfyPrivacyPolicyCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyPrivacyPolicyCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyPrivacyPolicyCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
    @MainActor @objc public static var idenfyPrivacyPolicyCardItemFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyPrivacyPolicyHighlightedPolicyFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
    
    // PrivacyPolicyViewV2 Styles
    @MainActor @objc public static var idenfyPrivacyPolicyCardBorderRadius: CGFloat = 4
}
