//
//  IdenfyManualReviewingViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-07-02.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyManualReviewingStatusWaitingViewUISettingsV2: NSObject {
    // ManualReviewingStatusWaitingViewV2 Colors

    @MainActor @objc public static var idenfyManualReviewingStatusWaitingViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationTopDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingTimerTitleTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStopWaitingButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepTitleColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCompletedStepTitleColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepViewHolderBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepViewHolderCompletedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepViewHolderShadowColor = IdenfyCommonColors.idenfyBlack
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepViewHolderShadowOpacity: Float = 0.5
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepViewHolderShadowRadius: CGFloat = 1

    // ManualReviewingStatusWaitingViewV2 Fonts

    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationTimerFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 13)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingStepFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCompletedStepFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyManualReviewingStatusWaitingCommonInformationTopDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
}
