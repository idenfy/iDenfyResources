//
//  IdenfyInternetConnectionPopupViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-03-01.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyInternetConnectionPopupViewUISettingsV2: NSObject {
    // IdenfyInternetConnectionPopupView Colors

    @MainActor @objc public static var IdenfyInternetConnectionPopupViewBackgroundColor = IdenfyCommonColors.idenfyDarkRedErrorColorV2
    @MainActor @objc public static var IdenfyInternetConnectionPopupViewTextViewColor = IdenfyCommonColors.idenfyWhite

    // IdenfyInternetConnectionPopupView Fonts

    @MainActor @objc public static var IdenfyInternetConnectionPopupViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
}
