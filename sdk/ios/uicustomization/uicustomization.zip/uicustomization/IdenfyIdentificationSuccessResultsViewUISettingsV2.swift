//
//  IdenfyIdentificationSuccessResultsViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyIdentificationSuccessResultsViewUISettingsV2: NSObject {
    // Idenfy Identification Success Results View Colors

    @MainActor @objc public static var idenfyIdentificationSuccessResultsViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyIdentificationSuccessResultsViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIdentificationSuccessResultsViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyIdentificationSuccessResultsViewIdentifiedTitleTextColor = IdenfyCommonColors.idenfyStepSuccessColorV2

    // Idenfy Identification Success Results Fonts

    @MainActor @objc public static var idenfyIdentificationSuccessResultsViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyIdentificationSuccessResultsViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyIdentificaionSuccessResultsViewIdentifiedTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
}
