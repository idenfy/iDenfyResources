//
//  IdenfyToolbarUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyToolbarUISettingsV2: NSObject {
    // Idenfy Default Toolbar Colors
    @objc public static var idenfyDefaultToolbarBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDefaultToolbarShadowColor = IdenfyCommonColors.idenfyBlack
    
    // Idenfy Toolbar Styles
    @objc public static var idenfyDefaultToolbarShadowOpacity = Float(0.1)
    @objc public static var idenfyDefaultToolbarShadowRadius = CGFloat(1)
    @objc public static var idenfyLogoHeight: Double = 26
    @objc public static var idenfyLogoWidth: Double = 70.5
    @objc public static var idenfyToolbarHeight: Double = 60
    @objc public static var idenfyToolbarHidden: Bool = false

    @objc public static var idenfyDefaultToolbarBackIconTintColor: UIColor? = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyDefaultToolbarLogoIconTintColor: UIColor? = IdenfyCommonColors.idenfyMainColorV2
    
    // Idenfy Questionnaire Toolbar Colors
    @objc public static var idenfyQuestionnaireToolbarSectionNumbersTextColor = IdenfyCommonColors.idenfySecondColorV2
    
    // Idenfy Questionnaire Toolbar Fonts
    @objc public static var idenfyQuestionnaireToolbarSectionNumbersFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 13)

    // Idenfy Camera Preview Session View Toolbar Colors
    @objc public static var idenfyCameraPreviewSessionToolbarBackgroundColor = UIColor.clear
    @objc public static var idenfyCameraPreviewSessionToolbarBackIconTintColor: UIColor? = IdenfyCommonColors.idenfyMainColorV2

    // Idenfy Language Selection View Toolbar Colors
    @objc public static var idenfyLanguageSelectionToolbarLanguageSelectionIconTintColor: UIColor? = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyLanguageSelectionToolbarCloseIconTintColor: UIColor? = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyFaceAuthToolbarLanguageSelectionIconTintColor: UIColor? = IdenfyCommonColors.idenfyWhite
}
