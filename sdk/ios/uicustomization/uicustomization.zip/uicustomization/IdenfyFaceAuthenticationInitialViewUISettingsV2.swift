//
//  FaceAuthenticationInitialViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-10-29.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyFaceAuthenticationInitialViewUISettingsV2: NSObject {
    // FaceAuthenticationInitialView Colors

    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewAuthenticationAttemptCountColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // FaceAuthenticationInitialView Fonts

    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyFaceAuthenticationInitialViewLivenessAttemptCountFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 23)
}
