//
//  EIDSessionCNHUploadViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 15/06/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class EIDSessionCNHUploadViewUISettingsV2: NSObject {

    // Idenfy EID Session CNH Upload View Colors

    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadAreaBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadAreaBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadIconTintColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewClickToUploadTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadLabelTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewErrorCardBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewErrorCardBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewErrorCardIconTintColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewErrorCardTextColor = IdenfyCommonColors.idenfySecondColorV2

    // CPF Input specific colors
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewCpfInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewCpfInputErrorBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewCpfInputTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewCpfInputPlaceholderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewCpfErrorTextColor = IdenfyCommonColors.idenfyRedColorV2

    // Idenfy EID Session CNH Upload View Fonts

    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadLabelFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewClickToUploadFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewErrorCardTextFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewCpfInputFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)

    // Idenfy EID Session CNH Upload View Styles

    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadAreaCornerRadius = CGFloat(4)
    @MainActor @objc public static var idenfyEIDSessionCNHUploadViewUploadAreaBorderWidth = CGFloat(1)
}
