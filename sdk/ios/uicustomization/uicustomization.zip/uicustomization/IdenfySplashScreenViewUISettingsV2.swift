//
//  IdenfySplashScreenViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfySplashScreenViewUISettingsV2: NSObject {
    // Idenfy Splash Screen View Colors
    @MainActor @objc public static var idenfySplashScreenViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfySplashScreenViewTitleTextColor = IdenfyCommonColors.idenfyBlackV2
    @MainActor @objc public static var idenfySplashScreenViewDescriptionTextColor = IdenfyCommonColors.idenfyBlackV2
    @MainActor @objc public static var idenfySplashScreenViewSpinnerTintColor = IdenfyCommonColors.idenfyBlackV2

    // Idenfy Splash Screen View Fonts

    @MainActor @objc public static var idenfySplashScreenViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfySplashScreenViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontSemiBoldV2, size: 12)
    @MainActor @objc public static var idenfySplashScreenLogoSize: CGFloat = 120
    
}
