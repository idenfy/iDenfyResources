//
//  IdenfySplashScreenViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfySplashScreenViewUISettingsV2: NSObject {
    // Idenfy Splash Screen View Colors

    @MainActor @objc public static var idenfySplashScreenViewDescriptionTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfySplashScreenViewSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Splash Screen View Fonts

    @MainActor @objc public static var idenfySplashScreenViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    
    @MainActor @objc public static var idenfySplashScreenLogoSize: CGFloat = 32
    
}
