//
//  IdenfyCustomAlertDialogUISettings.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2026-10-29.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyCustomAlertDialogUISettings: NSObject {
    @MainActor @objc public static var idenfyCustomAlertDialogBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyCustomAlertDialogRetakePhotoButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCustomAlertDialogRetakePhotoButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
}
