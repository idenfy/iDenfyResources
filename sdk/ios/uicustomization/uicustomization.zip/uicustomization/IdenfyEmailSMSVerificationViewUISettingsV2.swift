//
//  IdenfyEmailSMSVerificationViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-03-01.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyEmailSMSVerificationViewUISettingsV2: NSObject {
    
    // Idenfy Email Verification View Colors
    @MainActor @objc public static var idenfyEmailSMSVerificationViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor = IdenfyCommonColors.idenfyPurpleV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor = IdenfyCommonColors.idenfyBackgroundPurpleV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBorderColor = IdenfyCommonColors.idenfyBlueColor
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBackgroundColor = IdenfyCommonColors.idenfyLightBlueColor
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardFailedStatusBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardFailedStatusBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardSuccessStatusBorderColor = IdenfyCommonColors.idenfyBorderGreenV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardSuccessStatusBackgroundColor = IdenfyCommonColors.idenfyBackgroundGreenV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardIconTintColor = IdenfyCommonColors.idenfyPurpleV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusIconTintColor = IdenfyCommonColors.idenfyBlueColor
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardFailedStatusIconTintColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardSuccessStatusIconTintColor = IdenfyCommonColors.idenfyBorderGreenV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldPlaceHolderTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageTextColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUnderlineColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUpdatedUnderlineColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationIconTintColor = IdenfyCommonColors.idenfyPurpleV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleMarkedTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleMarkedDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationRemainingTimeTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleMarkedTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleMarkedDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    
    @MainActor @objc public static var idenfyEmailSMSVerificationViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    
    // Idenfy Email Verification View Fonts
    @MainActor @objc public static var idenfyEmailSMSVerificationViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 32)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationMarkedTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationMarkedTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    
    // Idenfy Email Verification View Styles
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineWidth = CGFloat(30)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHSpacing = CGFloat(8)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineVMargin = CGFloat(11)
    @MainActor @objc public static var idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHeight = CGFloat(3)
}
