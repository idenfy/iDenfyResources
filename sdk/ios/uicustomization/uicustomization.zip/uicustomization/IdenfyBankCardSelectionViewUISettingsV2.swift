//
//  IdenfyBankCardSelectionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardSelectionViewUISettingsV2: NSObject {

    @MainActor @objc public static var idenfyBankCardSelectionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBankCardSelectionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardSelectionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardSelectionViewSpinnerBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyBankCardSelectionViewSpinnerBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardSelectionViewSpinnerTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyBankCardSelectionViewButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyBankCardSelectionViewButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyBankCardSelectionViewButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyBankCardSelectionViewLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    @MainActor @objc public static var idenfyBankCardSelectionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyBankCardSelectionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyBankCardSelectionViewSpinnerFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)

    @MainActor @objc public static var idenfyBankCardSelectionViewSpinnerBorderWidth: CGFloat = 1
    @MainActor @objc public static var idenfyBankCardSelectionViewSpinnerCornerRadius: CGFloat = 4
}
