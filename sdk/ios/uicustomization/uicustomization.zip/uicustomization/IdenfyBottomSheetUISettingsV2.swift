//
//  IdenfyBottomSheetUISettingsV2.swift
//  idenfyviews
//
//  Created by iDenfy on 2026-05-21.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBottomSheetUISettingsV2: NSObject {

    // Idenfy Bottom Sheet Colors
    @MainActor @objc public static var idenfyBottomSheetBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyBottomSheetDimmedBackgroundColor = UIColor.black
    @MainActor @objc public static var idenfyBottomSheetDragHandleColor = IdenfyCommonColors.idenfySecondColorV2
    
    // Idenfy Bottom Sheet Values
    @MainActor @objc public static var idenfyBottomSheetCornerRadius: CGFloat = 16
    @MainActor @objc public static var idenfyBottomSheetDragHandleWidth: CGFloat = 40
    @MainActor @objc public static var idenfyBottomSheetDragHandleHeight: CGFloat = 4
    @MainActor @objc public static var idenfyBottomSheetDragHandleCornerRadius: CGFloat = 2
}
