//
//  IdenfyUploadPhotoViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyUploadPhotoViewUISettingsV2: NSObject {
    // Idenfy Upload Photo View Colors

    @MainActor @objc public static var idenfyUploadPhotoViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewDescriptionTextColor =
        IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingBackgroundColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingBackgroundDimColor = IdenfyCommonColors.idenfyWhite.withAlphaComponent(0.3)
    @MainActor @objc public static var idenfyUploadPhotoViewChooseAnotherPhotoButtonTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewChooseAnotherPhotoButtonBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyUploadPhotoViewChooseAnotherPhotoButtonBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyUploadPhotoViewContinuePhotoButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingRectangleGridColor = IdenfyCommonColors.idenfyWhite.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingRectangleCornerColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Upload Photo View Fonts

    @MainActor @objc public static var idenfyUploadPhotoViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyUploadPhotoViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)

    // Idenfy Upload Photo View Style

    @MainActor @objc public static var idenfyUploadPhotoViewCroppingViewBorderWidth = CGFloat(2)
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingViewCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingRectangleCornerRadius = CGFloat(4)
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingViewMinimumZoomScale = CGFloat(1)
    @MainActor @objc public static var idenfyUploadPhotoViewCroppingViewMaximumZoomScale = CGFloat(5)
}
