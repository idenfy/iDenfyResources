//
//  IdenfyIdentificationSuspectedResultsViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-02-21.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyIdentificationSuspectedResultsViewUISettingsV2: NSObject {
    // IdentificationSuspectedResultsViewV2 Colors

    @objc public static var idenfyIdentificationSuspectedResultsViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyIdentificationSuspectedResultsViewCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @objc public static var idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionEmailTextColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyIdentificationSuspectedResultsViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // IdentificationSuspectedResultsViewV2 Fonts

    @objc public static var idenfyIdentificationSuspectedResultsViewCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionEmailFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 15)
}
