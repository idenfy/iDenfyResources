//
//  EIDSessionCodeVerificationViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 17/06/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class EIDSessionCodeVerificationViewUISettingsV2: NSObject {
    
    // Idenfy EID Session Code Verifiction View Colors
    
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeHintTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusIconTintColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusBackgroundColor = IdenfyCommonColors.idenfyErrorLightRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorMessageTextColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldPlaceHolderTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorBorderColor = IdenfyCommonColors.idenfyRedColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInformationRemainingTimeTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewContinueButtonDisabledTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewContinueButtonDisabledBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewContinueButtonEnabledTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewContinueButtonLoadingSpinnerTintColor = IdenfyCommonColors.idenfyWhite

    // Idenfy EID Session Code Verification Fonts

    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 48)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorMessageFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeRemainingTimeTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
    
    // Idenfy EID Session Code Verification Styles
    
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputInformationCardBorderWidth = CGFloat(1)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldCornerRadius = CGFloat(3)
    @MainActor @objc public static var idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBorderWidth = CGFloat(1)
}
