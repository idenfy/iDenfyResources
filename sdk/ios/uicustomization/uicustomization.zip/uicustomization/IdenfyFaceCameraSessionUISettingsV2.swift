//
//  IdenfyFaceCameraSessionUiSettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyFaceCameraSessionUISettingsV2: NSObject {
    // Idenfy Face Camera Preview Session Colors

    @objc public static var idenfyFaceCameraPreviewSessionBackgroundColor = IdenfyCommonColors.idenfyBlack
    @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = IdenfyCommonColors.idenfyTakePhotoButtonIconUnFocused
    @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedTintColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyFaceCameraPreviewSessionFaceOvalColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = IdenfyCommonColors.idenfyWhite.withAlphaComponent(0.5)
    
    // Idenfy Face Camera Preview Session Fonts

    @objc public static var idenfyFaceCameraPreviewSessionFaceDetectionDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
}
