//
//  IdenfyFaceCameraSessionUiSettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-02-12.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyFaceCameraSessionUISettingsV2: NSObject {
    // Idenfy Face Camera Preview Session Colors

    @MainActor @objc public static var idenfyFaceCameraPreviewSessionBackgroundColor = IdenfyCommonColors.idenfyBlack
    @MainActor @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = IdenfyCommonColors.idenfyTakePhotoButtonIconUnFocused
    @MainActor @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedTintColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedBackgroundColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyFaceCameraPreviewSessionFaceOvalColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = IdenfyCommonColors.idenfyWhite.withAlphaComponent(0.5)
    @MainActor @objc public static var idenfyFaceCameraPreviewSessionFaceOvalOutsideColor  = IdenfyCommonColors.idenfyDrawerBackgroundColor
    
    // Idenfy Face Camera Preview Session Fonts

    @MainActor @objc public static var idenfyFaceCameraPreviewSessionFaceDetectionDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 14)
}
