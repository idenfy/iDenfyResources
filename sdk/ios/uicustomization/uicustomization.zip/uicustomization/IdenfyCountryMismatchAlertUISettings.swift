//
//  IdenfyCountryMismatchAlertUISettings.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2026-10-29.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyCountryMismatchAlertUISettings: NSObject {
    // Country Mismatch Alert Colors
    @MainActor @objc public static var idenfyCountryMismatchAlertViewBackgroundColor = IdenfyCustomAlertDialogUISettings.idenfyCustomAlertDialogBackgroundColor
    @MainActor @objc public static var idenfyCountryMismatchAlertTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountryMismatchAlertDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyCountryMismatchAlertContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @MainActor @objc public static var idenfyCountryMismatchAlertBackButtonTextColor = IdenfyCommonColors.idenfyMainColorV2

    // Country Mismatch Alert Fonts
    @MainActor @objc public static var idenfyCountryMismatchAlertTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyCountryMismatchAlertDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
}
