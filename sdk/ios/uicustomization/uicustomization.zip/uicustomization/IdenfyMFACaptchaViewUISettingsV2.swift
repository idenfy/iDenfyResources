//
//  IdenfyMFACaptchaViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-04-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyMFACaptchaViewUISettingsV2: NSObject {
    // Idenfy MFA Captcha View Colors

    @MainActor @objc public static var idenfyMFACaptchaViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @MainActor @objc public static var idenfyMFACaptchaViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFACaptchaViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFACaptchaViewHintTextColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFACaptchaViewInputViewHintTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)
    @MainActor @objc public static var idenfyMFACaptchaViewInputViewTextColor = IdenfyCommonColors.idenfySecondColorV2
    @MainActor @objc public static var idenfyMFACaptchaViewInputBorderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.06)
    @MainActor @objc public static var idenfyMFACaptchaViewInputFocusedBorderColor = IdenfyCommonColors.idenfyMainColorV2
    @MainActor @objc public static var idenfyMFACaptchaViewInputViewBackgroundColor = UIColor.white
    @MainActor @objc public static var idenfyMFACaptchaViewContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    
    // Idenfy MFA Captcha View Fonts

    @MainActor @objc public static var idenfyMFACaptchaViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @MainActor @objc public static var idenfyMFACaptchaViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @MainActor @objc public static var idenfyMFACaptchaViewHintFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 10)
    @MainActor @objc public static var idenfyMFACaptchaViewInputViewFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 16)

    // Idenfy MFA Captcha View Style

    @MainActor @objc public static var idenfyMFACaptchaViewInputViewCorderRadius = CGFloat(3)
    @MainActor @objc public static var idenfyMFACaptchaViewInputViewBorderWidth = CGFloat(1)
}
