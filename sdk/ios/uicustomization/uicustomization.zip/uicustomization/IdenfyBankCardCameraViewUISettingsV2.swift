//
//  IdenfyBankCardCameraViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-09-28.
//  Copyright (c) 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

@objc open class IdenfyBankCardCameraViewUISettingsV2: NSObject {
    @MainActor @objc public static var idenfyBankCardCameraViewLoadingSpinnerColor: UIColor = .white
}
