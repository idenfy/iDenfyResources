//
//  CountryQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2022-09-26.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class CountryQuestionCell: UITableViewCell, CountryQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var countryInputView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBackgroundColor
        view.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldCornerRadius
        view.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderWidth
        view.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderColor.cgColor
        view.layer.masksToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    
    public var countryUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCountryLabelFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCountryLabelTextColor
        return label
    }()
    
    public var cancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isOpaque = true
        button.isHidden = true
        button.isUserInteractionEnabled = true
        var config = UIButton.Configuration.plain()
        config.contentInsets = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 0)
        button.configuration = config
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCancelIconTintColor
        return button
    }()
    
    public var arrowIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewArrowIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leadingAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.trailingAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(countryInputView)
        countryInputView.leadingAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        countryInputView.trailingAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        countryInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        countryInputView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        countryInputView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        
        cellView.addSubview(countryUILabel)
        countryUILabel.leadingAnchor.constraint(equalTo: countryInputView.leadingAnchor, constant: 16).isActive = true
        countryUILabel.centerYAnchor.constraint(equalTo: countryInputView.centerYAnchor).isActive = true
        countryUILabel.trailingAnchor.constraint(equalTo: countryInputView.trailingAnchor, constant: -16).isActive = true
        
        cellView.addSubview(cancelButton)
        cancelButton.heightAnchor.constraint(equalToConstant: 25).isActive = true
        cancelButton.widthAnchor.constraint(equalToConstant: 25).isActive = true
        cancelButton.trailingAnchor.constraint(equalTo: countryInputView.trailingAnchor, constant: -16).isActive = true
        cancelButton.centerYAnchor.constraint(equalTo: countryInputView.centerYAnchor).isActive = true
        
        cellView.addSubview(arrowIcon)
        arrowIcon.heightAnchor.constraint(equalToConstant: 25).isActive = true
        arrowIcon.widthAnchor.constraint(equalToConstant: 25).isActive = true
        arrowIcon.trailingAnchor.constraint(equalTo: countryInputView.trailingAnchor, constant: -16).isActive = true
        arrowIcon.centerYAnchor.constraint(equalTo: countryInputView.centerYAnchor).isActive = true
    }
}

