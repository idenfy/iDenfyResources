//
//  BankCardSelectionViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol BankCardSelectionViewButtonActionsDelegate: AnyObject {
    func verifyButtonPressed()
    func pickerButtonTapped()
}

public protocol BankCardSelectionViewableV2: UIView {
    var delegate: BankCardSelectionViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2Default { get }
    var bankCardSelectionTitle: UILabel { get }
    var bankCardSelectionDescription: UILabel { get }
    var pickerButton: UIButton { get }
    var verifyEnabledButton: UIButton { get }
    var verifyDisabledButton: UIButton { get }
    var verifyButtonSpinner: LottieAnimationView { get }

    func applyGradients()
}

@objc open class BankCardSelectionViewV2: UIView, BankCardSelectionViewableV2 {
    open weak var delegate: BankCardSelectionViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var bankCardSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewTitleTextColor
        return label
    }()

    public var bankCardSelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewDescriptionTextColor
        return label
    }()

    public var pickerButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        var config = UIButton.Configuration.plain()
        config.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16)
        config.background.backgroundColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewSpinnerBackgroundColor
        config.background.cornerRadius = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewSpinnerCornerRadius
        config.background.strokeColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewSpinnerBorderColor
        config.background.strokeWidth = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewSpinnerBorderWidth
        let font = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewSpinnerFont ?? UIFont.systemFont(ofSize: 15)
        config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var outgoing = incoming
            outgoing.font = font
            return outgoing
        }
        config.baseForegroundColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewSpinnerTextColor.withAlphaComponent(0.4)
        button.configuration = config
        button.contentHorizontalAlignment = .left
        return button
    }()

    public var verifyEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isHidden = true
        return button
    }()

    public var verifyDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        return button
    }()

    public var verifyButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyBankCardSelectionViewUISettingsV2.idenfyBankCardSelectionViewBackgroundColor
        setupToolbar()
        setupTitle()
        setupPicker()
        setupVerifyButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        verifyEnabledButton.addTarget(self, action: #selector(verifyButtonAction), for: .touchUpInside)
        pickerButton.addTarget(self, action: #selector(pickerButtonAction), for: .touchUpInside)
    }

    @objc func verifyButtonAction() { delegate?.verifyButtonPressed() }
    @objc func pickerButtonAction() { delegate?.pickerButtonTapped() }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTitle() {
        addSubview(bankCardSelectionTitle)
        bankCardSelectionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        bankCardSelectionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        bankCardSelectionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(bankCardSelectionDescription)
        bankCardSelectionDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        bankCardSelectionDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        bankCardSelectionDescription.topAnchor.constraint(equalTo: bankCardSelectionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupPicker() {
        addSubview(pickerButton)
        pickerButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        pickerButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        pickerButton.topAnchor.constraint(equalTo: bankCardSelectionDescription.bottomAnchor, constant: 24).isActive = true
        pickerButton.heightAnchor.constraint(equalToConstant: 48).isActive = true
    }

    open func setupVerifyButton() {
        addSubview(verifyEnabledButton)
        verifyEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        verifyEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        verifyEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        verifyEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(verifyDisabledButton)
        verifyDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        verifyDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        verifyDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        verifyDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(verifyButtonSpinner)
        verifyButtonSpinner.centerYAnchor.constraint(equalTo: verifyEnabledButton.centerYAnchor).isActive = true
        verifyButtonSpinner.leadingAnchor.constraint(equalTo: verifyEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        verifyButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        verifyButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func applyGradients() {
        verifyEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
