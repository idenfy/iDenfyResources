//
//  FileQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2022-09-26.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class FileQuestionCell: UITableViewCell, FileQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var fileUploadContainerView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerBackgroundColor
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerBorderColor
        view.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerBorderWidth
        view.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerCornerRadius
        return view
    }()
    
    public var fileUploadButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "idenfy_ic_confirmation_upload_photo", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewUploadIconTintColor
        button.isUserInteractionEnabled = false
        return button
    }()
    
    public var photoUploadLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_animation_photo_result_loading_indicator", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.alpha = 0.6
        lottieView.isHidden = true
        return lottieView
    }()
    
    public var cancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        var config = UIButton.Configuration.plain()
        config.contentInsets = NSDirectionalEdgeInsets(top: 4, leading: 4, bottom: 4, trailing: 4)
        button.configuration = config
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.isUserInteractionEnabled = true
        button.isHidden = true
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewCancelIconTintColor
        return button
    }()
    
    public var filePlaceHolder: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewFileDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewFileDescriptionTextColor
        return label
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leadingAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.trailingAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(fileUploadContainerView)
        fileUploadContainerView.leadingAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        fileUploadContainerView.trailingAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        fileUploadContainerView.heightAnchor.constraint(equalToConstant: 80).isActive = true
        fileUploadContainerView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        fileUploadContainerView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        
        cellView.addSubview(photoUploadLoadingSpinner)
        photoUploadLoadingSpinner.centerXAnchor.constraint(equalTo: fileUploadContainerView.centerXAnchor).isActive = true
        photoUploadLoadingSpinner.centerYAnchor.constraint(equalTo: fileUploadContainerView.centerYAnchor, constant: -16).isActive = true
        photoUploadLoadingSpinner.widthAnchor.constraint(equalToConstant: 35).isActive = true
        photoUploadLoadingSpinner.heightAnchor.constraint(equalToConstant: 35).isActive = true

        
        cellView.addSubview(fileUploadButton)
        fileUploadButton.centerXAnchor.constraint(equalTo: fileUploadContainerView.centerXAnchor).isActive = true
        fileUploadButton.centerYAnchor.constraint(equalTo: fileUploadContainerView.centerYAnchor, constant: -16).isActive = true
        fileUploadButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        fileUploadButton.heightAnchor.constraint(equalToConstant: 35).isActive = true
        
        cellView.addSubview(cancelButton)
        cancelButton.trailingAnchor.constraint(equalTo: fileUploadContainerView.trailingAnchor, constant: -4).isActive = true
        cancelButton.topAnchor.constraint(equalTo: fileUploadContainerView.topAnchor, constant: 4).isActive = true
        cancelButton.widthAnchor.constraint(equalToConstant: 26).isActive = true
        cancelButton.heightAnchor.constraint(equalToConstant: 26).isActive = true
        
        cellView.addSubview(filePlaceHolder)
        filePlaceHolder.topAnchor.constraint(equalTo: fileUploadButton.bottomAnchor).isActive = true
        filePlaceHolder.bottomAnchor.constraint(equalTo: fileUploadContainerView.bottomAnchor, constant: -8).isActive = true
        filePlaceHolder.leadingAnchor.constraint(equalTo: fileUploadContainerView.leadingAnchor, constant: 16).isActive = true
        filePlaceHolder.trailingAnchor.constraint(equalTo: fileUploadContainerView.trailingAnchor, constant: -16).isActive = true
    }
}

