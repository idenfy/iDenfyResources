//
//  EmailVerificationViewV2.swift
//  iDenfySDK
//
//  Created by Viktas Juskys on 2019-11-29.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit
import Lottie
import idenfycore

public protocol EmailVerificationViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
}

public protocol EmailVerificationViewableV2: UIView {
    var delegate: EmailVerificationViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var emailVerificationTitle: UILabel { get }
    var emailVerificationDescription: UILabel { get }
    
    // Email input content
    var emailInputContentView: UIView { get }
    var emailInputInformationCard: UIView { get }
    var emailInputInformationIcon: UIImageView { get }
    var emailInputInformationTitle: UILabel { get }
    var emailInputInformationDescription: UILabel { get }
    var emailInputView: UITextField { get }
    var errorMessage: UILabel { get }
    var emailInputStatusInformationCard: UIView { get }
    var emailInputStatusInformationTitle: UILabel { get }
    var emailInputStatusInformationIcon: UIImageView { get }
    
    // Email code input content
    var emailCodeInputStackView: UIStackView { get }
    var emailCodeInputTextField: PinCodeInputTextField { get }
    var emailCodeInputInformationCard: UIView { get }
    var emailCodeInputInformationTitle: UILabel { get }
    var emailCodeInputInformationIcon: UIImageView { get }
    var resendEmailCodeInformationTitle: UILabel { get }
    var changeEmailAddressInformationTitle: UILabel { get }
    
    var continueEnabledButton: UIButton { get }
    var continueDisabledButton: UIButton { get }
    var continueButtonSpinner: LottieAnimationView { get }
    
    func applyGradients()
}

@objc open class EmailVerificationViewV2: UIView, EmailVerificationViewableV2 {
    open weak var delegate: EmailVerificationViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var emailVerificationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewTitleTextColor
        return label
    }()

    public var emailVerificationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewDescriptionTextColor
        return label
    }()
    
    public var emailInputContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    public var emailInputImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_email_verification).withRenderingMode(.alwaysOriginal)
        return imageView
    }()
    
    public var emailInputInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor
        return view
    }()
    
    public var emailInputInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleTextColor
        return label
    }()
    
    public var emailInputInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardIconTintColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_information_icon).withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var emailInputInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionTextColor
        return label
    }()
    
    public var emailInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldFont
        textField.keyboardType = .emailAddress
        textField.textContentType = .emailAddress
        textField.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldTextColor
        textField.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBackgroundColor
        textField.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldCornerRadius
        textField.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderWidth
        textField.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()
    
    public var errorMessage: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageTextColor
        return label
    }()
    
    public var emailInputStatusInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBackgroundColor
        return view
    }()
    
    public var emailInputStatusInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor
        return label
    }()
    
    public var emailInputStatusInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusIconTintColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_information_icon).withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var emailCodeInputStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    public var emailCodeInputTextField: PinCodeInputTextField = {
        let pinField = PinCodeInputTextField()
        pinField.translatesAutoresizingMaskIntoConstraints = false
        pinField.isOpaque = true
        pinField.underlineWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineWidth
        pinField.underlineHSpacing = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHSpacing
        pinField.underlineVMargin = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineVMargin
        pinField.fontSize = 32
        pinField.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldFont ?? UIFont.systemFont(ofSize: 32)
        pinField.underlineHeight = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHeight
        pinField.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldTextColor
        pinField.underlineColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUnderlineColor
        pinField.updatedUnderlineColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUpdatedUnderlineColor
        pinField.isUserInteractionEnabled = true
        pinField.isHidden = true
        return pinField
    }()
    
    public var emailCodeInputInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor
        return view
    }()
    
    public var emailCodeInputInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor
        return label
    }()
    
    public var emailCodeInputInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationIconTintColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_failed_checkmark).withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var resendEmailCodeInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleTextColor
        return label
    }()
    
    public var changeEmailAddressInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleTextColor
        return label
    }()
    
    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupEmailSelectionContentView()
        setupContinueButton()
        setupEmailCodeInputView()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(emailVerificationTitle)
        emailVerificationTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        emailVerificationTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        emailVerificationTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(emailVerificationDescription)
        emailVerificationDescription.widthAnchor.constraint(equalTo: emailVerificationTitle.widthAnchor, multiplier: 0.8).isActive = true
        emailVerificationDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        emailVerificationDescription.topAnchor.constraint(equalTo: emailVerificationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupEmailSelectionContentView() {
        addSubview(emailInputContentView)
        emailInputContentView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        emailInputContentView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        emailInputContentView.topAnchor.constraint(equalTo: emailVerificationDescription.bottomAnchor).isActive = true
        
        emailInputContentView.addSubview(emailInputImageView)
        emailInputImageView.topAnchor.constraint(equalTo: emailInputContentView.topAnchor, constant: 24).isActive = true
        emailInputImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        emailInputImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        emailInputImageView.centerXAnchor.constraint(equalTo: emailInputContentView.centerXAnchor).isActive = true
        
        emailInputContentView.addSubview(emailInputInformationCard)
        emailInputInformationCard.topAnchor.constraint(equalTo: emailInputImageView.bottomAnchor, constant: 24).isActive = true
        emailInputInformationCard.leadingAnchor.constraint(equalTo: emailInputContentView.leadingAnchor).isActive = true
        emailInputInformationCard.trailingAnchor.constraint(equalTo: emailInputContentView.trailingAnchor).isActive = true
        
        emailInputInformationCard.addSubview(emailInputInformationIcon)
        emailInputInformationIcon.leadingAnchor.constraint(equalTo: emailInputInformationCard.leadingAnchor, constant: 16).isActive = true
        emailInputInformationIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true
        emailInputInformationIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        emailInputInformationIcon.topAnchor.constraint(equalTo: emailInputInformationCard.topAnchor, constant: 12).isActive = true
        
        emailInputInformationCard.addSubview(emailInputInformationTitle)
        emailInputInformationTitle.leadingAnchor.constraint(equalTo: emailInputInformationIcon.trailingAnchor, constant: 8).isActive = true
        emailInputInformationTitle.topAnchor.constraint(equalTo: emailInputInformationIcon.topAnchor).isActive = true
        emailInputInformationTitle.trailingAnchor.constraint(equalTo: emailInputInformationCard.trailingAnchor, constant: -8).isActive = true
        
        emailInputInformationCard.addSubview(emailInputInformationDescription)
        emailInputInformationDescription.topAnchor.constraint(equalTo: emailInputInformationTitle.bottomAnchor, constant: 12).isActive = true
        emailInputInformationDescription.leadingAnchor.constraint(equalTo: emailInputInformationTitle.leadingAnchor).isActive = true
        emailInputInformationDescription.trailingAnchor.constraint(equalTo: emailInputInformationCard.trailingAnchor, constant: -16).isActive = true
        emailInputInformationDescription.bottomAnchor.constraint(equalTo: emailInputInformationCard.bottomAnchor, constant: -12).isActive = true
        
        emailInputContentView.addSubview(emailInputView)
        emailInputView.leadingAnchor.constraint(equalTo: emailInputContentView.leadingAnchor).isActive = true
        emailInputView.trailingAnchor.constraint(equalTo: emailInputContentView.trailingAnchor).isActive = true
        emailInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        emailInputView.topAnchor.constraint(equalTo: emailInputInformationCard.bottomAnchor, constant: 16).isActive = true
        emailInputView.bottomAnchor.constraint(equalTo: emailInputContentView.bottomAnchor).isActive = true
        
        emailInputContentView.addSubview(errorMessage)
        errorMessage.topAnchor.constraint(equalTo: emailInputView.topAnchor, constant: 2).isActive = true
        errorMessage.leadingAnchor.constraint(equalTo: emailInputView.safeLeftAnchor, constant: 10).isActive = true
        errorMessage.trailingAnchor.constraint(equalTo: emailInputView.safeRightAnchor).isActive = true
        
        addSubview(emailInputStatusInformationCard)
        
        emailInputStatusInformationCard.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        emailInputStatusInformationCard.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        emailInputStatusInformationCard.topAnchor.constraint(equalTo: emailInputView.bottomAnchor, constant: 24).isActive = true
        
        emailInputStatusInformationCard.addSubview(emailInputStatusInformationIcon)
        emailInputStatusInformationIcon.leadingAnchor.constraint(equalTo: emailInputStatusInformationCard.leadingAnchor, constant: 16).isActive = true
        emailInputStatusInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        emailInputStatusInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        emailInputStatusInformationIcon.centerYAnchor.constraint(equalTo: emailInputStatusInformationCard.centerYAnchor).isActive = true
        
        emailInputStatusInformationCard.addSubview(emailInputStatusInformationTitle)
        emailInputStatusInformationTitle.leadingAnchor.constraint(equalTo: emailInputStatusInformationIcon.trailingAnchor, constant: 8).isActive = true
        emailInputStatusInformationTitle.topAnchor.constraint(equalTo: emailInputStatusInformationCard.topAnchor, constant: 12).isActive = true
        emailInputStatusInformationTitle.bottomAnchor.constraint(equalTo: emailInputStatusInformationCard.bottomAnchor, constant: -12).isActive = true
        emailInputStatusInformationTitle.trailingAnchor.constraint(equalTo: emailInputStatusInformationCard.trailingAnchor, constant: -16).isActive = true
    }
    
    open func setupEmailCodeInputView() {
        addSubview(emailCodeInputTextField)
        emailCodeInputTextField.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        emailCodeInputTextField.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        emailCodeInputTextField.topAnchor.constraint(equalTo: emailVerificationDescription.bottomAnchor, constant: 24).isActive = true
        emailCodeInputTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        let spacerView = UIView()
        spacerView.translatesAutoresizingMaskIntoConstraints = false
        spacerView.setContentHuggingPriority(.defaultLow, for: .vertical)
        
        let labelsContainer = UIView()
        labelsContainer.translatesAutoresizingMaskIntoConstraints = false
        labelsContainer.addSubview(resendEmailCodeInformationTitle)
        resendEmailCodeInformationTitle.leadingAnchor.constraint(equalTo: labelsContainer.leadingAnchor).isActive = true
        resendEmailCodeInformationTitle.trailingAnchor.constraint(equalTo: labelsContainer.trailingAnchor).isActive = true
        resendEmailCodeInformationTitle.topAnchor.constraint(equalTo: labelsContainer.topAnchor, constant: 24).isActive = true
        
        labelsContainer.addSubview(changeEmailAddressInformationTitle)
        changeEmailAddressInformationTitle.leadingAnchor.constraint(equalTo: labelsContainer.leadingAnchor).isActive = true
        changeEmailAddressInformationTitle.trailingAnchor.constraint(equalTo: labelsContainer.trailingAnchor).isActive = true
        changeEmailAddressInformationTitle.topAnchor.constraint(equalTo: resendEmailCodeInformationTitle.bottomAnchor, constant: 12).isActive = true
        changeEmailAddressInformationTitle.bottomAnchor.constraint(equalTo: labelsContainer.bottomAnchor).isActive = true
        
        emailCodeInputStackView.addArrangedSubview(emailCodeInputInformationCard)
        emailCodeInputStackView.addArrangedSubview(labelsContainer)
        emailCodeInputStackView.addArrangedSubview(spacerView)
        
        addSubview(emailCodeInputStackView)
        
        emailCodeInputStackView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        emailCodeInputStackView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        emailCodeInputStackView.topAnchor.constraint(equalTo: emailCodeInputTextField.bottomAnchor, constant: 24).isActive = true
        
        emailCodeInputInformationCard.addSubview(emailCodeInputInformationIcon)
        emailCodeInputInformationIcon.leadingAnchor.constraint(equalTo: emailCodeInputInformationCard.leadingAnchor, constant: 16).isActive = true
        emailCodeInputInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        emailCodeInputInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        emailCodeInputInformationIcon.centerYAnchor.constraint(equalTo: emailCodeInputInformationCard.centerYAnchor).isActive = true
        
        emailCodeInputInformationCard.addSubview(emailCodeInputInformationTitle)
        emailCodeInputInformationTitle.leadingAnchor.constraint(equalTo: emailCodeInputInformationIcon.trailingAnchor, constant: 8).isActive = true
        emailCodeInputInformationTitle.topAnchor.constraint(equalTo: emailCodeInputInformationCard.topAnchor, constant: 12).isActive = true
        emailCodeInputInformationTitle.bottomAnchor.constraint(equalTo: emailCodeInputInformationCard.bottomAnchor, constant: -12).isActive = true
        emailCodeInputInformationTitle.trailingAnchor.constraint(equalTo: emailCodeInputInformationCard.trailingAnchor, constant: -16).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueDisabledButton)
        continueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
