//
//  DocumentCameraResultViewV2.swift
//  iDenfySDK
//
//  Created by Viktas Juskys on 2020-01-10.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol FileResultViewV2ButtonActionsDelegate: AnyObject {
    func confirmButtonPressedAction()
    func retakeButtonPressedAction()
}

public protocol CameraResultViewableV2: UIView, Sendable {
    var photoResultTitle: UILabel { get }
    var photoResultDetailsCard: UIView { get }
    var photoResultDetailsCardTitle: UILabel { get }
    var photoResultDetailsCardSecond: UIView { get }
    var photoResultDetailsCardTitleSecond: UILabel { get }
    var photoResultDetailsCardQuestionMark: UIImageView { get }
    var photoResultDetailsSpinner: LottieAnimationView { get }
    var delegate: FileResultViewV2ButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2CameraSession { get }
    var continueButton: UIButton { get }
    var chooseAnotherFileButton: UIButton { get }
    var fileResultImageView: UIImageView { get }
    
    func applyGradients()
}

@objc open class CameraResultViewV2: UIView, CameraResultViewableV2 {
    open weak var delegate: FileResultViewV2ButtonActionsDelegate?

    public required init(frame: CGRect, withRectangle: IdenfyCameraViewType) {
        super.init(frame: frame)
        setupConstraints(withRectangle)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero, withRectangle: .withoutRectangle)
    }

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var photoResultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewTitleColor
        return label
    }()

    public var photoResultDetailsCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardSecond: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardQuestionMark: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_photo_result_view_details_card_questionmark).withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return imageView
    }()

    public var photoResultDetailsCardQuestionMarkSecond: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_photo_result_view_details_card_questionmark).withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return imageView
    }()

    public var photoResultDetailsCardTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public var photoResultDetailsCardTitleSecond: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public var fileResultImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPhotoCornerRadius
        return imageView
    }()
    
    public var photoResultDetailsSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_animation_photo_result_loading_indicator, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.alpha = 0.6
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewLoadingSpinnerTintColor)
        return lottieView
    }()

    public var continueButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var chooseAnotherFileButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.masksToBounds = true
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.borderWidth = IdenfyButtonsUISettingsV2.idenfyChooseAnotherPhotoButtonCornerRadius
        button.layer.borderColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonBorderColor.cgColor
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.alwaysBounceVertical = false
        return scrollView
    }()

    var resultContentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    @objc open func setupConstraints(_ withRectangle: IdenfyCameraViewType) {
        backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewBackgroundColor
        setupToolbar()
        setupButtons()
        setupButtonActions()
        setupSpinner()

        switch withRectangle {
        case .withRectangle:
            setupScrollView()
            setupImageView()
            setupTitle()
            setupDocumentDetailCards()
        case .withoutRectangle:
            setupFaceDetailCard()
            setupFaceTitle()
            setupFaceImageView()
        }

    }

    private func setupScrollView() {
        addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: toolbar.bottomAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: continueButton.topAnchor, constant: -16).isActive = true

        scrollView.addSubview(resultContentView)
        resultContentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        resultContentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        resultContentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        resultContentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        resultContentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(confirmPhotoButtonPressed), for: .touchUpInside)
        chooseAnotherFileButton.addTarget(self, action: #selector(retakePhotoButtonPressed), for: .touchUpInside)
    }

    @objc func confirmPhotoButtonPressed() {
        delegate?.confirmButtonPressedAction()
    }

    @objc func retakePhotoButtonPressed() {
        delegate?.retakeButtonPressedAction()
    }
    
    private func setupSpinner() {
        addSubview(photoResultDetailsSpinner)
        photoResultDetailsSpinner.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -24).isActive = true
        photoResultDetailsSpinner.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        photoResultDetailsSpinner.heightAnchor.constraint(equalToConstant: 150).isActive = true
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupButtons() {
        addSubview(chooseAnotherFileButton)
        chooseAnotherFileButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        chooseAnotherFileButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButton)
        continueButton.bottomAnchor.constraint(equalTo: chooseAnotherFileButton.topAnchor, constant: -16).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    private func setupTitle() {
        resultContentView.addSubview(photoResultTitle)
        photoResultTitle.centerXAnchor.constraint(equalTo: resultContentView.centerXAnchor).isActive = true
        photoResultTitle.topAnchor.constraint(equalTo: fileResultImageView.bottomAnchor, constant: 12).isActive = true
        photoResultTitle.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 16).isActive = true
        photoResultTitle.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -16).isActive = true
    }

    private func setupDocumentDetailCards() {
        resultContentView.addSubview(photoResultDetailsCard)
        photoResultDetailsCard.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 32).isActive = true
        photoResultDetailsCard.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -32).isActive = true
        photoResultDetailsCard.topAnchor.constraint(equalTo: photoResultTitle.bottomAnchor, constant: 12).isActive = true
        photoResultDetailsCard.heightAnchor.constraint(greaterThanOrEqualToConstant: 50).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardQuestionMark)
        photoResultDetailsCardQuestionMark.leadingAnchor.constraint(equalTo: photoResultDetailsCard.leadingAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMark.topAnchor.constraint(equalTo: photoResultDetailsCard.topAnchor).isActive = true
        photoResultDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: photoResultDetailsCard.bottomAnchor).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardTitle)
        photoResultDetailsCardTitle.leadingAnchor.constraint(equalTo: photoResultDetailsCard.leadingAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitle.trailingAnchor.constraint(equalTo: photoResultDetailsCard.trailingAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitle.topAnchor.constraint(equalTo: photoResultDetailsCard.topAnchor, constant: 8).isActive = true
        photoResultDetailsCardTitle.bottomAnchor.constraint(equalTo: photoResultDetailsCard.bottomAnchor, constant: -8).isActive = true

        resultContentView.addSubview(photoResultDetailsCardSecond)
        photoResultDetailsCardSecond.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 32).isActive = true
        photoResultDetailsCardSecond.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -32).isActive = true
        photoResultDetailsCardSecond.topAnchor.constraint(equalTo: photoResultDetailsCard.bottomAnchor, constant: 16).isActive = true
        photoResultDetailsCardSecond.heightAnchor.constraint(equalToConstant: 50).isActive = true
        photoResultDetailsCardSecond.bottomAnchor.constraint(equalTo: resultContentView.bottomAnchor, constant: -16).isActive = true

        photoResultDetailsCardSecond.addSubview(photoResultDetailsCardQuestionMarkSecond)
        photoResultDetailsCardQuestionMarkSecond.leadingAnchor.constraint(equalTo: photoResultDetailsCardSecond.leadingAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMarkSecond.topAnchor.constraint(equalTo: photoResultDetailsCardSecond.topAnchor).isActive = true
        photoResultDetailsCardQuestionMarkSecond.bottomAnchor.constraint(equalTo: photoResultDetailsCardSecond.bottomAnchor).isActive = true

        photoResultDetailsCardSecond.addSubview(photoResultDetailsCardTitleSecond)
        photoResultDetailsCardTitleSecond.leadingAnchor.constraint(equalTo: photoResultDetailsCardSecond.leadingAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitleSecond.trailingAnchor.constraint(equalTo: photoResultDetailsCardSecond.trailingAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitleSecond.topAnchor.constraint(equalTo: photoResultDetailsCardSecond.topAnchor).isActive = true
        photoResultDetailsCardTitleSecond.bottomAnchor.constraint(equalTo: photoResultDetailsCardSecond.bottomAnchor).isActive = true
    }

    private func setupFaceDetailCard() {
        addSubview(photoResultDetailsCard)
        photoResultDetailsCard.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        photoResultDetailsCard.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        photoResultDetailsCard.bottomAnchor.constraint(equalTo: continueButton.topAnchor, constant: -24).isActive = true
        photoResultDetailsCard.heightAnchor.constraint(equalToConstant: 50).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardQuestionMark)
        photoResultDetailsCardQuestionMark.leadingAnchor.constraint(equalTo: photoResultDetailsCard.leadingAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMark.topAnchor.constraint(equalTo: photoResultDetailsCard.topAnchor).isActive = true
        photoResultDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: photoResultDetailsCard.bottomAnchor).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardTitle)
        photoResultDetailsCardTitle.leadingAnchor.constraint(equalTo: photoResultDetailsCard.leadingAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitle.trailingAnchor.constraint(equalTo: photoResultDetailsCard.trailingAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitle.topAnchor.constraint(equalTo: photoResultDetailsCard.topAnchor).isActive = true
        photoResultDetailsCardTitle.bottomAnchor.constraint(equalTo: photoResultDetailsCard.bottomAnchor).isActive = true
    }

    private func setupFaceTitle() {
        addSubview(photoResultTitle)
        photoResultTitle.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        photoResultTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        photoResultTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        photoResultTitle.bottomAnchor.constraint(equalTo: photoResultDetailsCard.topAnchor, constant: -12).isActive = true
    }

    private func setupImageView() {
        resultContentView.addSubview(fileResultImageView)
        fileResultImageView.centerXAnchor.constraint(equalTo: resultContentView.centerXAnchor).isActive = true
        fileResultImageView.topAnchor.constraint(equalTo: resultContentView.topAnchor, constant: 16).isActive = true
        fileResultImageView.leadingAnchor.constraint(greaterThanOrEqualTo: resultContentView.leadingAnchor, constant: 16).isActive = true
        fileResultImageView.trailingAnchor.constraint(lessThanOrEqualTo: resultContentView.trailingAnchor, constant: -16).isActive = true

        let height = fileResultImageView.heightAnchor.constraint(equalToConstant: 0)
        height.identifier = "photoHeight"
        height.isActive = true

        let width = fileResultImageView.widthAnchor.constraint(equalToConstant: 0)
        width.identifier = "photoWidth"
        width.priority = .defaultHigh
        width.isActive = true
    }

    private func setupFaceImageView() {
        addSubview(fileResultImageView)
        let topConstraint = fileResultImageView.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 16)
        topConstraint.isActive = true
        let bottomConstraint = fileResultImageView.bottomAnchor.constraint(equalTo: photoResultTitle.topAnchor, constant: -12)
        bottomConstraint.isActive = true
        fileResultImageView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        fileResultImageView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        fileResultImageView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
    }

    
    nonisolated open func applyGradients() {
        Task { @MainActor in
            continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
        }
    }
}
