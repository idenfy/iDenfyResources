//
//  DocumentSelectionViewV2.swift
//  iDenfySDK
//
//  Created by Viktas Juskys on 2019-11-29.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol DocumentSelectionViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
}

public protocol DocumentSelectionViewableV2: UIView {
    var delegate: DocumentSelectionViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var documentSelectionTitle: UILabel { get }
    var documentSelectionDescription: UILabel { get }
    var documentTableView: UITableView { get }
    var continueEnabledButton: UIButton? { get }
    var continueDisabledButton: UIButton? { get }
    var continueButtonSpinner: LottieAnimationView { get }
    
    func applyGradients()
}

@objc open class DocumentSelectionViewV2: UIView, DocumentSelectionViewableV2 {
    open weak var delegate: DocumentSelectionViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var documentSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewTitleTextColor
        return label
    }()

    public var documentSelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDescriptionTextColor
        return label
    }()

    public var emptyArea: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .clear
        return view
    }()

    public var documentTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.bounces = false
        tableView.isScrollEnabled = true
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.backgroundColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewBackgroundColor
        tableView.showsVerticalScrollIndicator = false
        tableView.layer.cornerRadius = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewCornerRadius
        tableView.layer.borderWidth = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewBorderWidth
        tableView.layer.borderColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewBorderColor.cgColor
        return tableView
    }()
    
    public var continueDisabledButton: UIButton? = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton? = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupDocumentTableView()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton?.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupTopTitle() {
        addSubview(documentSelectionTitle)
        documentSelectionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        documentSelectionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        documentSelectionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(documentSelectionDescription)
        documentSelectionDescription.widthAnchor.constraint(equalTo: documentSelectionTitle.widthAnchor, multiplier: 0.8).isActive = true
        documentSelectionDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        documentSelectionDescription.topAnchor.constraint(equalTo: documentSelectionTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupContinueButton() {
        guard let unwrappedEnabledContinueButton = continueEnabledButton else { return }
        guard let unwrappedDisabledContinueButton = continueDisabledButton else { return }
        addSubview(unwrappedEnabledContinueButton)
        unwrappedEnabledContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        unwrappedEnabledContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        unwrappedEnabledContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        unwrappedEnabledContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(unwrappedDisabledContinueButton)
        unwrappedDisabledContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        unwrappedDisabledContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        unwrappedDisabledContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        unwrappedDisabledContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: unwrappedEnabledContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: unwrappedEnabledContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func setupDocumentTableView() {
        addSubview(emptyArea)
        emptyArea.topAnchor.constraint(equalTo: documentSelectionDescription.bottomAnchor, constant: 32).isActive = true
        if let unwrappedEnabledButton = continueEnabledButton {
            emptyArea.bottomAnchor.constraint(equalTo: unwrappedEnabledButton.topAnchor, constant: -16).isActive = true
        } else {
            emptyArea.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -16).isActive = true
        }
        emptyArea.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        emptyArea.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true

        addSubview(documentTableView)
        documentTableView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        documentTableView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        documentTableView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        documentTableView.topAnchor.constraint(equalTo: emptyArea.safeTopAnchor).isActive = true
        let bottom = documentTableView.bottomAnchor.constraint(equalTo: emptyArea.safeBottomAnchor)
        bottom.priority = UILayoutPriority.fittingSizeLevel
        bottom.isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton?.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
