//
//  DrawerContentViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import AVFoundation

@objc open class DrawerContentViewV2: UIView, DrawerContentViewableV2 {
    open weak var delegate: CameraSessionDrawerDelegate?

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var descriptionLabelV2: UILabel = {
        let label = UILabel()
        label.textColor = IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionTextColor
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionFont
        label.numberOfLines = 3
        return label
    }()

    public var infoLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = IdenfyDrawerUISettingsV2.idenfyDrawerTitleFont
        label.textColor = IdenfyDrawerUISettingsV2.idenfyDrawerTitleTextColor
        label.numberOfLines = 0
        return label
    }()
    
    public var descriptionSpace: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var faceDetectionAlertImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isHidden = true
        imageView.image = UIImage(named: "idenfy_ic_info_alert", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyCommonColors.idenfyFaceNotDetectedColor
        return imageView
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = IdenfyCommonColors.idenfyDrawerBackgroundColor
        setupToolbar()
        setupLabel()
        setupDescription()
        setupButtonActions()
    }

    public convenience init() {
        self.init(frame: CGRect.zero)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }
    
    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
        
        toolbar.backButton.imageView?.setImageColor(IdenfyDrawerUISettingsV2.idenfyDrawerBackButtonTintColor)
        
        toolbar.addSubview(faceDetectionAlertImage)
        faceDetectionAlertImage.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor, constant: -4).isActive = true
        faceDetectionAlertImage.centerXAnchor.constraint(equalTo: toolbar.centerXAnchor).isActive = true
        faceDetectionAlertImage.widthAnchor.constraint(equalToConstant: 32).isActive = true
        faceDetectionAlertImage.heightAnchor.constraint(equalToConstant: 32).isActive = true
        
        if let device = AVCaptureDevice.default(for: AVMediaType.video) {
            if device.hasTorch {
                toolbar.idenfyToggleFlashButton.widthAnchor.constraint(equalToConstant: 24).isActive = true
                toolbar.idenfyToggleFlashButton.setNeedsLayout()
                toolbar.idenfyToggleFlashButton.isHidden = false
            } else {
                toolbar.idenfyToggleFlashButton.widthAnchor.constraint(equalToConstant: 0).isActive = true
                toolbar.idenfyToggleFlashButton.setNeedsLayout()
                toolbar.idenfyToggleFlashButton.isHidden = true
            }
        }
    }
    
    open func setupLabel() {
        addSubview(infoLabel)
        infoLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        infoLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        infoLabel.topAnchor.constraint(equalTo: toolbar.topAnchor, constant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight - 16).isActive = true
    }

    open func setupDescription() {
        addSubview(descriptionSpace)
        descriptionSpace.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8).isActive = true
        descriptionSpace.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8).isActive = true
        descriptionSpace.topAnchor.constraint(equalTo: infoLabel.bottomAnchor, constant: 8).isActive = true
        descriptionSpace.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8).isActive = true
        
        descriptionSpace.addSubview(descriptionLabelV2)
        descriptionLabelV2.leadingAnchor.constraint(equalTo: descriptionSpace.leadingAnchor).isActive = true
        descriptionLabelV2.trailingAnchor.constraint(equalTo: descriptionSpace.trailingAnchor).isActive = true
        descriptionLabelV2.centerYAnchor.constraint(equalTo: descriptionSpace.centerYAnchor, constant: -4).isActive = true
    }

    private func setupButtonActions() {
        toolbar.backButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        toolbar.idenfyToggleFlashButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(toggleFlashButtonPressed)))
        toolbar.instructionDialogButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(instructionDialogButtonPressed)))
    }

    @objc func backButtonPressed() {
        delegate?.backButtonPressedAction()
    }
    
    @objc func toggleFlashButtonPressed() {
        delegate?.toggleFlashButtonPressedAction()
    }
    
    @objc func instructionDialogButtonPressed() {
        delegate?.instructionDialogButtonPressedAction()
    }
}
