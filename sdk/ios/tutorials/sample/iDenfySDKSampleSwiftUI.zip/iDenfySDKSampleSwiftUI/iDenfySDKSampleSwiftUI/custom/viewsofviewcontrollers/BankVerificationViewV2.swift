//
//  BankVerificationViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 27/03/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class BankVerificationViewV2: UIView, BankVerificationViewableV2 {
    open weak var delegate: BankVerificationViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var bankVerificationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewTitleTextColor
        return label
    }()

    public var bankVerificationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewDescriptionTextColor
        return label
    }()
    
    public var bankSelectionContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var countrySelectionInputView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewBackgroundColor
        view.layer.cornerRadius = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewCornerRadius
        view.layer.borderWidth = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewBorderWidth
        view.layer.borderColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewBorderColor.cgColor
        view.layer.masksToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    
    public var countrySelectionFlagImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.isOpaque = true
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewCountryFlagBorderWidth
        imageView.layer.borderColor = UIColor.black.cgColor
        return imageView
    }()
    
    public var countrySelectionUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewTextColor
        return label
    }()
    
    public var countrySelectionCancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isOpaque = true
        button.isHidden = true
        button.isUserInteractionEnabled = true
        button.imageEdgeInsets = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 5)
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewCancelIconTintColor
        return button
    }()
    
    public var countrySelectionArrowIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewArrowIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()
    
    public var bankSelectionInputView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewBackgroundColor
        view.layer.cornerRadius = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewCornerRadius
        view.layer.borderWidth = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewBorderWidth
        view.layer.borderColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewBorderColor.cgColor
        view.layer.masksToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    
    public var bankSelectionUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewTextColor
        return label
    }()
    
    public var bankSelectionCancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isOpaque = true
        button.isHidden = true
        button.isUserInteractionEnabled = true
        button.imageEdgeInsets = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 5)
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewCancelIconTintColor
        return button
    }()
    
    public var bankSelectionArrowIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewItemSelectionInputViewArrowIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()
    
    public var bankSelectionAnimationSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()
    
    public var bankNotListedUiSwitch: UISwitch = {
        let button = UISwitch(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.onTintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewUISwitchTintColor
        button.isUserInteractionEnabled = true
        button.transform = CGAffineTransform(scaleX: 0.75, y: 0.75)
        return button
    }()
    
    public var bankNotListedUiSwitchDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewUISwitchDescriptionFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewUISwitchDescriptionTextColor
        return label
    }()
    
    public var bankNotListedInformationImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = false
        imageView.isUserInteractionEnabled = true
        imageView.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewBankNotListedUISwitchInformationIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_information_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()
    
    public var bankResultContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    public var bankResultCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultStatusCardCorderRadius
        view.layer.borderWidth = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultStatusCardBorderWidth
        view.layer.borderColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultSuccessStatusCardBorderColor.cgColor
        view.backgroundColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultSuccessStatusCardBackgroundColor
        return view
    }()
    
    public var bankResultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultStatusTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultStatusTitleTextColor
        return label
    }()
    
    public var bankResultIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultSuccessStatusCardBorderColor
        imageView.image = UIImage(named: "idenfy_ic_success_checkmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()
    
    public var bankResultDescriptionIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultSuccessStatusDescriptionIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_information_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()
    
    public var bankResultDescriptionLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultFailedStatusDescriptionFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewResultFailedStatusDescriptionTextColor
        return label
    }()
    
    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupBankResultContentView()
        setupBankResultCard()
        setupBankSelectionContentView()
        setupCountrySelectionPicker()
        setupBankSelectionPicker()
        setupBankNotListedCheckBox()
        setupContinueButton()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
        bankNotListedInformationImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(bankNotListedInformationButtonPressed)))
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }
    
    @objc func bankNotListedInformationButtonPressed() {
        delegate?.bankNotListedInformationButtonPressed()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(bankVerificationTitle)
        bankVerificationTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        bankVerificationTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        bankVerificationTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(bankVerificationDescription)
        bankVerificationDescription.widthAnchor.constraint(equalTo: bankVerificationTitle.widthAnchor, multiplier: 0.8).isActive = true
        bankVerificationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        bankVerificationDescription.topAnchor.constraint(equalTo: bankVerificationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupBankSelectionContentView() {
        addSubview(bankSelectionContentView)
        bankSelectionContentView.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        bankSelectionContentView.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        bankSelectionContentView.topAnchor.constraint(equalTo: bankResultContentView.bottomAnchor).isActive = true
    }
    
    open func setupCountrySelectionPicker() {
        bankSelectionContentView.addSubview(countrySelectionInputView)
        countrySelectionInputView.leadingAnchor.constraint(equalTo: bankSelectionContentView.leadingAnchor, constant: 32).isActive = true
        countrySelectionInputView.trailingAnchor.constraint(equalTo: bankSelectionContentView.trailingAnchor, constant: -32).isActive = true
        countrySelectionInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        countrySelectionInputView.topAnchor.constraint(equalTo: bankSelectionContentView.topAnchor, constant: 32).isActive = true
        
        let countryFlagLabelStackView = UIStackView(arrangedSubviews: [countrySelectionFlagImageView, countrySelectionUILabel])
        countryFlagLabelStackView.axis = .horizontal
        countryFlagLabelStackView.alignment = .center
        countryFlagLabelStackView.spacing = 8
        countryFlagLabelStackView.translatesAutoresizingMaskIntoConstraints = false
        bankSelectionContentView.addSubview(countryFlagLabelStackView)
        countryFlagLabelStackView.leadingAnchor.constraint(equalTo: countrySelectionInputView.leadingAnchor, constant: 12).isActive = true
        countryFlagLabelStackView.trailingAnchor.constraint(lessThanOrEqualTo: countrySelectionInputView.trailingAnchor, constant: -16).isActive = true
        countryFlagLabelStackView.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true
        countrySelectionFlagImageView.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        bankSelectionContentView.addSubview(countrySelectionCancelButton)
        countrySelectionCancelButton.heightAnchor.constraint(equalToConstant: 20).isActive = true
        countrySelectionCancelButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        countrySelectionCancelButton.trailingAnchor.constraint(equalTo: countrySelectionInputView.trailingAnchor, constant: -16).isActive = true
        countrySelectionCancelButton.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true
        
        bankSelectionContentView.addSubview(countrySelectionArrowIcon)
        countrySelectionArrowIcon.heightAnchor.constraint(equalToConstant: 25).isActive = true
        countrySelectionArrowIcon.widthAnchor.constraint(equalToConstant: 25).isActive = true
        countrySelectionArrowIcon.trailingAnchor.constraint(equalTo: countrySelectionInputView.trailingAnchor, constant: -16).isActive = true
        countrySelectionArrowIcon.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true
    }
    
    open func setupBankSelectionPicker() {
        bankSelectionContentView.addSubview(bankSelectionInputView)
        bankSelectionInputView.leadingAnchor.constraint(equalTo: bankSelectionContentView.leadingAnchor, constant: 32).isActive = true
        bankSelectionInputView.trailingAnchor.constraint(equalTo: bankSelectionContentView.trailingAnchor, constant: -32).isActive = true
        bankSelectionInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        bankSelectionInputView.topAnchor.constraint(equalTo: countrySelectionInputView.bottomAnchor, constant: 8).isActive = true
        
        bankSelectionContentView.addSubview(bankSelectionUILabel)
        bankSelectionUILabel.leadingAnchor.constraint(equalTo: bankSelectionInputView.leadingAnchor, constant: 16).isActive = true
        bankSelectionUILabel.centerYAnchor.constraint(equalTo: bankSelectionInputView.centerYAnchor).isActive = true
        bankSelectionUILabel.trailingAnchor.constraint(equalTo: bankSelectionInputView.trailingAnchor, constant: -16).isActive = true
        
        bankSelectionContentView.addSubview(bankSelectionCancelButton)
        bankSelectionCancelButton.heightAnchor.constraint(equalToConstant: 20).isActive = true
        bankSelectionCancelButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        bankSelectionCancelButton.trailingAnchor.constraint(equalTo: bankSelectionInputView.trailingAnchor, constant: -16).isActive = true
        bankSelectionCancelButton.centerYAnchor.constraint(equalTo: bankSelectionInputView.centerYAnchor).isActive = true
        
        bankSelectionContentView.addSubview(bankSelectionArrowIcon)
        bankSelectionArrowIcon.heightAnchor.constraint(equalToConstant: 25).isActive = true
        bankSelectionArrowIcon.widthAnchor.constraint(equalToConstant: 25).isActive = true
        bankSelectionArrowIcon.trailingAnchor.constraint(equalTo: bankSelectionInputView.trailingAnchor, constant: -16).isActive = true
        bankSelectionArrowIcon.centerYAnchor.constraint(equalTo: bankSelectionInputView.centerYAnchor).isActive = true
        
        bankSelectionContentView.addSubview(bankSelectionAnimationSpinner)
        bankSelectionAnimationSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
        bankSelectionAnimationSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        bankSelectionAnimationSpinner.trailingAnchor.constraint(equalTo: bankSelectionInputView.trailingAnchor, constant: -16).isActive = true
        bankSelectionAnimationSpinner.centerYAnchor.constraint(equalTo: bankSelectionInputView.centerYAnchor).isActive = true
    }
    
    open func setupBankNotListedCheckBox() {
        bankSelectionContentView.addSubview(bankNotListedUiSwitch)
        bankNotListedUiSwitch.leadingAnchor.constraint(equalTo: bankSelectionContentView.leadingAnchor, constant: 32).isActive = true
        bankNotListedUiSwitch.topAnchor.constraint(equalTo: bankSelectionInputView.bottomAnchor, constant: 24).isActive = true
        bankNotListedUiSwitch.bottomAnchor.constraint(equalTo: bankSelectionContentView.bottomAnchor).isActive = true
        
        bankSelectionContentView.addSubview(bankNotListedInformationImageView)
        bankNotListedInformationImageView.trailingAnchor.constraint(equalTo: bankSelectionContentView.trailingAnchor, constant: -32).isActive = true
        bankNotListedInformationImageView.heightAnchor.constraint(equalToConstant: 20).isActive = true
        bankNotListedInformationImageView.widthAnchor.constraint(equalToConstant: 20).isActive = true
        bankNotListedInformationImageView.topAnchor.constraint(equalTo: bankNotListedUiSwitch.topAnchor).isActive = true
        bankNotListedInformationImageView.bottomAnchor.constraint(equalTo: bankNotListedUiSwitch.bottomAnchor).isActive = true
        
        bankSelectionContentView.addSubview(bankNotListedUiSwitchDescription)
        bankNotListedUiSwitchDescription.leadingAnchor.constraint(equalTo: bankNotListedUiSwitch.trailingAnchor, constant: 16).isActive = true
        bankNotListedUiSwitchDescription.trailingAnchor.constraint(equalTo: bankNotListedInformationImageView.leadingAnchor, constant: -16).isActive = true
        bankNotListedUiSwitchDescription.topAnchor.constraint(equalTo: bankNotListedUiSwitch.topAnchor).isActive = true
        bankNotListedUiSwitchDescription.bottomAnchor.constraint(equalTo: bankNotListedUiSwitch.bottomAnchor).isActive = true
    }
    
    open func setupBankResultContentView() {
        addSubview(bankResultContentView)
        bankResultContentView.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        bankResultContentView.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        bankResultContentView.topAnchor.constraint(equalTo: bankVerificationDescription.bottomAnchor).isActive = true
        let heightAnchor = bankResultContentView.heightAnchor.constraint(greaterThanOrEqualToConstant: CoreConsts.bankVerificationResultCardHeightConstant)
        heightAnchor.identifier = "resultCardHeight"
        heightAnchor.isActive = true
    }
    
    open func setupBankResultCard() {
        bankResultContentView.addSubview(bankResultCard)
        bankResultCard.topAnchor.constraint(equalTo: bankResultContentView.topAnchor, constant: 32).isActive = true
        bankResultCard.leadingAnchor.constraint(equalTo: bankResultContentView.leadingAnchor, constant: 32).isActive = true
        bankResultCard.trailingAnchor.constraint(equalTo: bankResultContentView.trailingAnchor, constant: -32).isActive = true
        bankResultCard.heightAnchor.constraint(equalToConstant: 52).isActive = true
        
        bankResultCard.addSubview(bankResultIcon)
        bankResultIcon.trailingAnchor.constraint(equalTo: bankResultCard.trailingAnchor, constant: -16).isActive = true
        bankResultIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        bankResultIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        bankResultIcon.centerYAnchor.constraint(equalTo: bankResultCard.centerYAnchor).isActive = true
        
        bankResultCard.addSubview(bankResultTitle)
        bankResultTitle.leadingAnchor.constraint(equalTo: bankResultCard.leadingAnchor, constant: 16).isActive = true
        bankResultTitle.topAnchor.constraint(equalTo: bankResultCard.topAnchor).isActive = true
        bankResultTitle.bottomAnchor.constraint(equalTo: bankResultCard.bottomAnchor).isActive = true
        bankResultTitle.trailingAnchor.constraint(equalTo: bankResultIcon.leadingAnchor, constant: -16).isActive = true
        
        bankResultContentView.addSubview(bankResultDescriptionIcon)
        bankResultDescriptionIcon.topAnchor.constraint(equalTo: bankResultCard.bottomAnchor, constant: 32).isActive = true
        bankResultDescriptionIcon.leadingAnchor.constraint(equalTo: bankResultContentView.leadingAnchor, constant: 32).isActive = true
        bankResultDescriptionIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        bankResultDescriptionIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        
        bankResultContentView.addSubview(bankResultDescriptionLabel)
        bankResultDescriptionLabel.leadingAnchor.constraint(equalTo: bankResultDescriptionIcon.trailingAnchor, constant: 16).isActive = true
        bankResultDescriptionLabel.centerYAnchor.constraint(equalTo: bankResultDescriptionIcon.centerYAnchor).isActive = true
        bankResultDescriptionLabel.trailingAnchor.constraint(equalTo: bankResultContentView.trailingAnchor, constant: -32).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueDisabledButton)
        continueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

@objc open class BankCell: UITableViewCell, BankCellViewable {
    public var hasBorder = false

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var bankLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationAlertItemTableViewCellFont
        label.text = "bank"
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyBankVerificationViewUISettingsV2.idenfyBankVerificationAlertItemTableViewCellTextColor
        return label
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        addSubview(cellView)
        cellView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        cellView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(bankLabel)
        bankLabel.leadingAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        bankLabel.trailingAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -(frame.width * 0.3)).isActive = true
        bankLabel.topAnchor.constraint(equalTo: cellView.safeTopAnchor).isActive = true
        bankLabel.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        bankLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor).isActive = true
    }
}
