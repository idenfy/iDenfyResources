//
//  BankCardUploadViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol BankCardUploadViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
    func uploadAreaTapped()
}

public protocol BankCardUploadViewableV2: UIView {
    var delegate: BankCardUploadViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var bankCardUploadTitle: UILabel { get }
    var bankCardUploadDescription: UILabel { get }
    var uploadAreaView: UIView { get }
    var uploadIconImageView: UIImageView { get }
    var clickToUploadLabel: UILabel { get }
    var fileSizeHintLabel: UILabel { get }
    var webViewContainer: UIView { get }
    var webViewLoadingSpinner: LottieAnimationView { get }
    var continueEnabledButton: UIButton { get }
    var continueDisabledButton: UIButton { get }
    var continueButtonSpinner: LottieAnimationView { get }

    func applyGradients()
}

@objc open class BankCardUploadViewV2: UIView, BankCardUploadViewableV2 {
    open weak var delegate: BankCardUploadViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var bankCardUploadTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewTitleTextColor
        return label
    }()

    public var bankCardUploadDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewDescriptionTextColor
        return label
    }()

    public var uploadAreaView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewContainerBackgroundColor
        view.layer.cornerRadius = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewContainerCornerRadius
        view.layer.borderWidth = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewContainerBorderWidth
        view.layer.borderColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewContainerBorderColor.cgColor
        view.isUserInteractionEnabled = true
        return view
    }()

    public var uploadIconImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_confirmation_upload_photo).withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewUploadIconTintColor
        return imageView
    }()

    public var clickToUploadLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewClickToUploadFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewClickToUploadTextColor
        return label
    }()

    public var fileSizeHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewFileHintFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewFileHintTextColor
        return label
    }()

    public var webViewContainer: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.clipsToBounds = true
        view.isHidden = true
        return view
    }()

    public var webViewLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewUploadIconTintColor)
        return lottieView
    }()

    public var uploadContentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 8
        return stackView
    }()

    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isHidden = true
        return button
    }()

    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        return button
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyBankCardUploadViewUISettingsV2.idenfyBankCardUploadViewBackgroundColor
        setupToolbar()
        setupTitle()
        setupUploadArea()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonAction), for: .touchUpInside)
        uploadAreaView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(uploadAreaAction)))
    }

    @objc func continueButtonAction() { delegate?.continueButtonPressed() }
    @objc func uploadAreaAction() { delegate?.uploadAreaTapped() }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTitle() {
        addSubview(bankCardUploadTitle)
        bankCardUploadTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        bankCardUploadTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        bankCardUploadTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(bankCardUploadDescription)
        bankCardUploadDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        bankCardUploadDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        bankCardUploadDescription.topAnchor.constraint(equalTo: bankCardUploadTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupUploadArea() {
        addSubview(uploadAreaView)
        uploadAreaView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        uploadAreaView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        uploadAreaView.topAnchor.constraint(equalTo: bankCardUploadDescription.bottomAnchor, constant: 24).isActive = true

        uploadIconImageView.widthAnchor.constraint(equalToConstant: 22).isActive = true
        uploadIconImageView.heightAnchor.constraint(equalToConstant: 22).isActive = true

        uploadContentStackView.addArrangedSubview(uploadIconImageView)
        uploadContentStackView.addArrangedSubview(clickToUploadLabel)
        uploadContentStackView.addArrangedSubview(fileSizeHintLabel)

        uploadAreaView.addSubview(uploadContentStackView)
        uploadContentStackView.leadingAnchor.constraint(equalTo: uploadAreaView.leadingAnchor, constant: 24).isActive = true
        uploadContentStackView.trailingAnchor.constraint(equalTo: uploadAreaView.trailingAnchor, constant: -24).isActive = true
        uploadContentStackView.topAnchor.constraint(equalTo: uploadAreaView.topAnchor, constant: 24).isActive = true
        uploadContentStackView.bottomAnchor.constraint(equalTo: uploadAreaView.bottomAnchor, constant: -24).isActive = true

        // WebView container — same position as upload area, shown when webview is used
        addSubview(webViewContainer)
        webViewContainer.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        webViewContainer.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        webViewContainer.topAnchor.constraint(equalTo: bankCardUploadDescription.bottomAnchor, constant: 24).isActive = true
        webViewContainer.heightAnchor.constraint(equalToConstant: 168).isActive = true

        addSubview(webViewLoadingSpinner)
        webViewLoadingSpinner.centerXAnchor.constraint(equalTo: webViewContainer.centerXAnchor).isActive = true
        webViewLoadingSpinner.centerYAnchor.constraint(equalTo: webViewContainer.centerYAnchor).isActive = true
        webViewLoadingSpinner.widthAnchor.constraint(equalToConstant: 30).isActive = true
        webViewLoadingSpinner.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }

    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueDisabledButton)
        continueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
