//
//  EIDSessionCodeVerificationViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 22/07/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class EIDSessionCodeVerificationViewV2: UIView, EIDSessionCodeVerificationViewableV2 {
    open weak var delegate: EIDSessionCodeVerificationViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var eidSessionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewTitleFont
        label.textAlignment = .center
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewTitleTextColor
        return label
    }()

    public var eidSessionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewDescriptionFont
        label.textAlignment = .center
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewDescriptionTextColor
        return label
    }()
    
    public var eidSessionCodeInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldFont
        textField.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldTextColor
        textField.backgroundColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var phoneNumberInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldFont
        textField.keyboardType = .phonePad
        textField.textContentType = .telephoneNumber
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(54)
        textField.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldTextColor
        textField.backgroundColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.isUserInteractionEnabled = true
        textField.isHidden = true
        return textField
    }()

    public var inputStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 16
        return stackView
    }()

    public var phoneInputCountryImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.isOpaque = true
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryFlagBorderWidth
        imageView.layer.borderColor = UIColor.black.cgColor
        return imageView
    }()
    
    public var errorMessage: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorMessageFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorMessageTextColor
        return label
    }()

    public var phoneNumberErrorMessage: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorMessageFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputTextFieldErrorMessageTextColor
        return label
    }()

    public var eidSessionCodeInputStatusInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        view.layer.cornerRadius = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardCornerRadius
        view.layer.borderWidth = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardBorderWidth
        view.layer.borderColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusBorderColor.cgColor
        view.backgroundColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusBackgroundColor
        return view
    }()
    
    public var eidSessionCodeInputStatusInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusTitleTextColor
        return label
    }()
    
    public var eidSessionCodeInputStatusInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeInputInformationCardFailedStatusIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_information_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()

    public var eidSessionProviderIconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var eidSessionCodeHintDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeHintFont
        label.textAlignment = .center
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewCodeHintTextColor
        return label
    }()
    
    public var eidSessionCodeExpirationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewDescriptionFont
        label.textAlignment = .center
        label.textColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewDescriptionTextColor
        return label
    }()

    public var eidSessionContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var eidSessionContinueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = EIDSessionCodeVerificationViewUISettingsV2.idenfyEIDSessionCodeVerificationViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupCodeInputView()
        setupCenterImageView()
        setupCodeStatusInformationCard()
        setupCodeHint()
        setupButtonActions()
    }

    private func setupButtonActions() {
        eidSessionContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(eidSessionTitle)
        eidSessionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        eidSessionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        eidSessionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(eidSessionDescription)
        eidSessionDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        eidSessionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        eidSessionDescription.topAnchor.constraint(equalTo: eidSessionTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupCodeInputView() {
        eidSessionCodeInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        phoneNumberInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true

        inputStackView.addArrangedSubview(eidSessionCodeInputView)
        inputStackView.addArrangedSubview(phoneNumberInputView)

        addSubview(inputStackView)
        inputStackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 32).isActive = true
        inputStackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -32).isActive = true
        inputStackView.topAnchor.constraint(equalTo: eidSessionDescription.bottomAnchor, constant: 24).isActive = true

        addSubview(phoneInputCountryImageView)
        phoneInputCountryImageView.leadingAnchor.constraint(equalTo: phoneNumberInputView.leadingAnchor, constant: 12).isActive = true
        phoneInputCountryImageView.centerYAnchor.constraint(equalTo: phoneNumberInputView.centerYAnchor).isActive = true
        phoneInputCountryImageView.widthAnchor.constraint(equalToConstant: 35).isActive = true
        phoneInputCountryImageView.heightAnchor.constraint(equalToConstant: 25).isActive = true

        addSubview(errorMessage)
        errorMessage.topAnchor.constraint(equalTo: eidSessionCodeInputView.topAnchor, constant: 2).isActive = true
        errorMessage.leadingAnchor.constraint(equalTo: eidSessionCodeInputView.safeLeftAnchor, constant: 10).isActive = true
        errorMessage.trailingAnchor.constraint(equalTo: eidSessionCodeInputView.safeRightAnchor).isActive = true

        addSubview(phoneNumberErrorMessage)
        phoneNumberErrorMessage.topAnchor.constraint(equalTo: phoneNumberInputView.topAnchor, constant: 2).isActive = true
        phoneNumberErrorMessage.leadingAnchor.constraint(equalTo: phoneInputCountryImageView.trailingAnchor, constant: 8).isActive = true
        phoneNumberErrorMessage.trailingAnchor.constraint(equalTo: phoneNumberInputView.safeRightAnchor).isActive = true
    }
    
    open func setupCodeStatusInformationCard() {
        addSubview(eidSessionCodeInputStatusInformationCard)
        
        eidSessionCodeInputStatusInformationCard.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 32).isActive = true
        eidSessionCodeInputStatusInformationCard.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -32).isActive = true
        eidSessionCodeInputStatusInformationCard.topAnchor.constraint(equalTo: inputStackView.bottomAnchor, constant: 24).isActive = true
        
        eidSessionCodeInputStatusInformationCard.addSubview(eidSessionCodeInputStatusInformationIcon)
        eidSessionCodeInputStatusInformationIcon.leadingAnchor.constraint(equalTo: eidSessionCodeInputStatusInformationCard.leadingAnchor, constant: 16).isActive = true
        eidSessionCodeInputStatusInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        eidSessionCodeInputStatusInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        eidSessionCodeInputStatusInformationIcon.centerYAnchor.constraint(equalTo: eidSessionCodeInputStatusInformationCard.centerYAnchor).isActive = true
        
        eidSessionCodeInputStatusInformationCard.addSubview(eidSessionCodeInputStatusInformationTitle)
        eidSessionCodeInputStatusInformationTitle.leadingAnchor.constraint(equalTo: eidSessionCodeInputStatusInformationIcon.trailingAnchor, constant: 8).isActive = true
        eidSessionCodeInputStatusInformationTitle.topAnchor.constraint(equalTo: eidSessionCodeInputStatusInformationCard.topAnchor, constant: 12).isActive = true
        eidSessionCodeInputStatusInformationTitle.bottomAnchor.constraint(equalTo: eidSessionCodeInputStatusInformationCard.bottomAnchor, constant: -12).isActive = true
        eidSessionCodeInputStatusInformationTitle.trailingAnchor.constraint(equalTo: eidSessionCodeInputStatusInformationCard.trailingAnchor, constant: -16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(eidSessionProviderIconImageView)
        eidSessionProviderIconImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        eidSessionProviderIconImageView.heightAnchor.constraint(equalToConstant: 60).isActive = true
        eidSessionProviderIconImageView.topAnchor.constraint(equalTo: eidSessionDescription.bottomAnchor, constant: 24).isActive = true
    }
    
    open func setupCodeHint() {
        addSubview(eidSessionCodeHintDescription)
        eidSessionCodeHintDescription.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionCodeHintDescription.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionCodeHintDescription.topAnchor.constraint(equalTo: eidSessionProviderIconImageView.bottomAnchor, constant: 24).isActive = true
        
        addSubview(eidSessionCodeExpirationDescription)
        eidSessionCodeExpirationDescription.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionCodeExpirationDescription.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionCodeExpirationDescription.topAnchor.constraint(equalTo: eidSessionCodeHintDescription.bottomAnchor, constant: 24).isActive = true
    }

    open func setupContinueButton() {
        addSubview(eidSessionContinueButton)
        eidSessionContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(eidSessionContinueDisabledButton)
        eidSessionContinueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: eidSessionContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: eidSessionContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        eidSessionContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
