//
//  CameraPermissionViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class CameraPermissionViewV2: UIView, CameraPermissionViewableV2 {
    open weak var delegate: CameraPermissionViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        toolbar.backButton.isHidden = true
        return toolbar
    }()

    public var cameraPermissionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewTitleTextColor
        return label
    }()

    public var cameraPermissionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewDescriptionTextColor
        return label
    }()

    public var cameraPermissionImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_camera_permissions_v2", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var cameraPermissionGuidanceDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewGuidanceDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewGuidancePermissionTextColor
        return label
    }()

    public var cameraPermissionGoToSettingsButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewGoToSettingsButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyCameraPermissionViewUISettingsV2.idenfyCameraPermissionViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupGoToSettingsButton()
        setupCenterImageView()
        setupCenterTitle()
        setupButtonActions()
    }

    private func setupButtonActions() {
        cameraPermissionGoToSettingsButton.addTarget(self, action: #selector(goToSettingsButtonPressed), for: .touchUpInside)
    }

    @objc func goToSettingsButtonPressed() {
        delegate?.goToSettingsButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(cameraPermissionTitle)
        cameraPermissionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        cameraPermissionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        cameraPermissionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(cameraPermissionDescription)
        cameraPermissionDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        cameraPermissionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        cameraPermissionDescription.topAnchor.constraint(equalTo: cameraPermissionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(cameraPermissionImageView)
        cameraPermissionImageView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        cameraPermissionImageView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cameraPermissionImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        let top = cameraPermissionImageView.topAnchor.constraint(equalTo: cameraPermissionDescription.bottomAnchor, constant: 16)
        top.priority = UILayoutPriority.fittingSizeLevel
        top.isActive = true
        let bottom = cameraPermissionImageView.bottomAnchor.constraint(equalTo: cameraPermissionGoToSettingsButton.topAnchor, constant: -16)
        bottom.priority = UILayoutPriority.fittingSizeLevel
        bottom.isActive = true
    }

    open func setupCenterTitle() {
        addSubview(cameraPermissionGuidanceDescription)
        cameraPermissionGuidanceDescription.topAnchor.constraint(equalTo: cameraPermissionImageView.bottomAnchor, constant: 24).isActive = true
        cameraPermissionGuidanceDescription.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        cameraPermissionGuidanceDescription.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
    }

    open func setupGoToSettingsButton() {
        addSubview(cameraPermissionGoToSettingsButton)
        cameraPermissionGoToSettingsButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        cameraPermissionGoToSettingsButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        cameraPermissionGoToSettingsButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        cameraPermissionGoToSettingsButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        cameraPermissionGoToSettingsButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
