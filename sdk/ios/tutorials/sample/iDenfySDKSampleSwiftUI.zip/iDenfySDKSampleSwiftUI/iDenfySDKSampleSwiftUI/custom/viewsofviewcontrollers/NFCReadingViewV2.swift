//
//  NFCReadingViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-03-29.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import Lottie
import UIKit

public protocol NFCReadingViewableV2: UIView {
    var idenfyToolbarV2Common: IdenfyToolbarV2Default { get }
    var idenfyUILabelNFCReadingCommonInformationTitle: UILabel { get }
    var idenfyUIImageViewNFCReadingCommonInformationIcon: UIImageView { get }
    var idenfyUILabelNFCReadingCommonInformationDescription: UILabel { get }
    var idenfyNFCReadingAnimation: LottieAnimationView { get }
}

@objc open class NFCReadingViewV2: UIView, NFCReadingViewableV2 {

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var idenfyUILabelNFCReadingCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyNFCReadingViewUISettingsV2.idenfyNFCReadingCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyNFCReadingViewUISettingsV2.idenfyNFCReadingCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelNFCReadingCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyNFCReadingViewUISettingsV2.idenfyNFCReadingCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyNFCReadingViewUISettingsV2.idenfyNFCReadingCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewNFCReadingCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_nfc_reading_success)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyNFCReadingAnimation: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_animation_nfc_reading_progress, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        return lottieView
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyNFCReadingViewUISettingsV2.idenfyNFCReadingViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupCenterImageView()
        setupLoadingSpiner()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelNFCReadingCommonInformationTitle)
        idenfyUILabelNFCReadingCommonInformationTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelNFCReadingCommonInformationTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelNFCReadingCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelNFCReadingCommonInformationDescription)
        idenfyUILabelNFCReadingCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelNFCReadingCommonInformationDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        idenfyUILabelNFCReadingCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelNFCReadingCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIImageViewNFCReadingCommonInformationIcon)
        idenfyUIImageViewNFCReadingCommonInformationIcon.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        idenfyUIImageViewNFCReadingCommonInformationIcon.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIImageViewNFCReadingCommonInformationIcon.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIImageViewNFCReadingCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUILabelNFCReadingCommonInformationDescription.bottomAnchor, constant: 24).isActive = true
    }

    open func setupLoadingSpiner() {
        addSubview(idenfyNFCReadingAnimation)
        idenfyNFCReadingAnimation.widthAnchor.constraint(equalToConstant: 250).isActive = true
        idenfyNFCReadingAnimation.heightAnchor.constraint(equalToConstant: 250).isActive = true
        idenfyNFCReadingAnimation.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyNFCReadingAnimation.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyNFCReadingAnimation.topAnchor.constraint(equalTo: idenfyUILabelNFCReadingCommonInformationDescription.bottomAnchor).isActive = true
    }
}
