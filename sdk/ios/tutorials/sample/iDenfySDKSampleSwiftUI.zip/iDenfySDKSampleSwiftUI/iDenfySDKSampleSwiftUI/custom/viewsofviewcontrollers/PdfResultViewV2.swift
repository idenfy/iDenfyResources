//
//  PdfResultViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2021-06-16.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit

@objc open class PdfResultViewV2: UIView, PdfResultViewableV2 {
    open weak var delegate: FileResultViewV2ButtonActionsDelegate?

    public required override init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var pdfResultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewTitleTextColor
        return label
    }()

    public var pdfResultDetailsCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardCornerRadius
        return view
    }()

    public var pdfResultDetailsCardQuestionMark: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.tintColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardTitleColor
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var pdfResultDetailsCardTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardTitleColor
        return label
    }()

    public var fileResultImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        return imageView
    }()

    public var continueButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var chooseAnotherFileButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewRetakePdfButtonBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.masksToBounds = true
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.borderWidth = IdenfyButtonsUISettingsV2.idenfyChooseAnotherPhotoButtonCornerRadius
        button.layer.borderColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewRetakePdfButtonBorderColor.cgColor
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewBackgroundColor
        setupToolbar()
        setupButtons()
        setupButtonActions()
        setupImageView()
        setupTitle()
        setupDocumentDetailCards()
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(confirmPhotoButtonPressed), for: .touchUpInside)
        chooseAnotherFileButton.addTarget(self, action: #selector(retakePhotoButtonPressed), for: .touchUpInside)
    }

    @objc func confirmPhotoButtonPressed() {
        delegate?.confirmButtonPressedAction()
    }

    @objc func retakePhotoButtonPressed() {
        delegate?.retakeButtonPressedAction()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupButtons() {
        addSubview(chooseAnotherFileButton)
        chooseAnotherFileButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        chooseAnotherFileButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButton)
        continueButton.bottomAnchor.constraint(equalTo: chooseAnotherFileButton.topAnchor, constant: -16).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    private func setupTitle() {
        addSubview(pdfResultTitle)
        pdfResultTitle.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        pdfResultTitle.topAnchor.constraint(equalTo: fileResultImageView.bottomAnchor, constant: 12).isActive = true
    }

    private func setupDocumentDetailCards() {
        addSubview(pdfResultDetailsCard)
        pdfResultDetailsCard.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        pdfResultDetailsCard.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        pdfResultDetailsCard.topAnchor.constraint(equalTo: pdfResultTitle.bottomAnchor, constant: 12).isActive = true
        pdfResultDetailsCard.heightAnchor.constraint(equalToConstant: 50).isActive = true

        pdfResultDetailsCard.addSubview(pdfResultDetailsCardQuestionMark)
        pdfResultDetailsCardQuestionMark.leadingAnchor.constraint(equalTo: pdfResultDetailsCard.safeLeftAnchor, constant: 16).isActive = true
        pdfResultDetailsCardQuestionMark.topAnchor.constraint(equalTo: pdfResultDetailsCard.safeTopAnchor).isActive = true
        pdfResultDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: pdfResultDetailsCard.safeBottomAnchor).isActive = true

        pdfResultDetailsCard.addSubview(pdfResultDetailsCardTitle)
        pdfResultDetailsCardTitle.leadingAnchor.constraint(equalTo: pdfResultDetailsCard.safeLeftAnchor, constant: 50).isActive = true
        pdfResultDetailsCardTitle.trailingAnchor.constraint(equalTo: pdfResultDetailsCard.safeRightAnchor, constant: -24).isActive = true
        pdfResultDetailsCardTitle.topAnchor.constraint(equalTo: pdfResultDetailsCard.safeTopAnchor).isActive = true
        pdfResultDetailsCardTitle.bottomAnchor.constraint(equalTo: pdfResultDetailsCard.safeBottomAnchor).isActive = true
    }

    private func setupImageView() {
        addSubview(fileResultImageView)
        fileResultImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        fileResultImageView.topAnchor.constraint(equalTo: toolbar.topAnchor, constant: 54).isActive = true
        fileResultImageView.heightAnchor.constraint(equalToConstant: 200).isActive = true
    }
    
    open func applyGradients() {
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
