//
//  UploadResultViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-06-01.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit

public protocol PdfResultViewableV2: UIView, Sendable {
    var pdfResultTitle: UILabel { get }
    var pdfResultDetailsCard: UIView { get }
    var pdfResultDetailsCardTitle: UILabel { get }
    var delegate: FileResultViewV2ButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2CameraSession { get }
    var continueButton: UIButton { get }
    var chooseAnotherFileButton: UIButton { get }
    var fileResultImageView: UIImageView { get }
    
    func applyGradients()
}

@objc open class PdfResultViewV2: UIView, PdfResultViewableV2 {
    open weak var delegate: FileResultViewV2ButtonActionsDelegate?

    public required override init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var pdfResultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewTitleTextColor
        return label
    }()

    public var pdfResultDetailsCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardCornerRadius
        return view
    }()

    public var pdfResultDetailsCardQuestionMark: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.tintColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardTitleColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_photo_result_view_details_card_questionmark)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var pdfResultDetailsCardTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewDetailsCardTitleColor
        return label
    }()

    public var fileResultImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        return imageView
    }()

    public var continueButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var chooseAnotherFileButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewRetakePdfButtonBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.masksToBounds = true
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.borderWidth = IdenfyButtonsUISettingsV2.idenfyChooseAnotherPhotoButtonCornerRadius
        button.layer.borderColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewRetakePdfButtonBorderColor.cgColor
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    private var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.alwaysBounceVertical = false
        return scrollView
    }()

    private var resultContentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyPdfResultViewUISettingsV2.idenfyPdfResultViewBackgroundColor
        setupToolbar()
        setupButtons()
        setupButtonActions()
        setupScrollView()
        setupImageView()
        setupTitle()
        setupDocumentDetailCards()
    }

    private func setupScrollView() {
        addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: toolbar.bottomAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: continueButton.topAnchor, constant: -16).isActive = true

        scrollView.addSubview(resultContentView)
        resultContentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        resultContentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        resultContentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        resultContentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        resultContentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(confirmPhotoButtonPressed), for: .touchUpInside)
        chooseAnotherFileButton.addTarget(self, action: #selector(retakePhotoButtonPressed), for: .touchUpInside)
    }

    @objc func confirmPhotoButtonPressed() {
        delegate?.confirmButtonPressedAction()
    }

    @objc func retakePhotoButtonPressed() {
        delegate?.retakeButtonPressedAction()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupButtons() {
        addSubview(chooseAnotherFileButton)
        chooseAnotherFileButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        chooseAnotherFileButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButton)
        continueButton.bottomAnchor.constraint(equalTo: chooseAnotherFileButton.topAnchor, constant: -16).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    private func setupTitle() {
        resultContentView.addSubview(pdfResultTitle)
        pdfResultTitle.centerXAnchor.constraint(equalTo: resultContentView.centerXAnchor).isActive = true
        pdfResultTitle.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 16).isActive = true
        pdfResultTitle.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -16).isActive = true
        pdfResultTitle.topAnchor.constraint(equalTo: fileResultImageView.bottomAnchor, constant: 12).isActive = true
    }

    private func setupDocumentDetailCards() {
        resultContentView.addSubview(pdfResultDetailsCard)
        pdfResultDetailsCard.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 32).isActive = true
        pdfResultDetailsCard.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -32).isActive = true
        pdfResultDetailsCard.topAnchor.constraint(equalTo: pdfResultTitle.bottomAnchor, constant: 12).isActive = true
        pdfResultDetailsCard.heightAnchor.constraint(equalToConstant: 50).isActive = true
        pdfResultDetailsCard.bottomAnchor.constraint(equalTo: resultContentView.bottomAnchor, constant: -16).isActive = true

        pdfResultDetailsCard.addSubview(pdfResultDetailsCardQuestionMark)
        pdfResultDetailsCardQuestionMark.leadingAnchor.constraint(equalTo: pdfResultDetailsCard.leadingAnchor, constant: 16).isActive = true
        pdfResultDetailsCardQuestionMark.topAnchor.constraint(equalTo: pdfResultDetailsCard.topAnchor).isActive = true
        pdfResultDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: pdfResultDetailsCard.bottomAnchor).isActive = true

        pdfResultDetailsCard.addSubview(pdfResultDetailsCardTitle)
        pdfResultDetailsCardTitle.leadingAnchor.constraint(equalTo: pdfResultDetailsCard.leadingAnchor, constant: 50).isActive = true
        pdfResultDetailsCardTitle.trailingAnchor.constraint(equalTo: pdfResultDetailsCard.trailingAnchor, constant: -24).isActive = true
        pdfResultDetailsCardTitle.topAnchor.constraint(equalTo: pdfResultDetailsCard.topAnchor).isActive = true
        pdfResultDetailsCardTitle.bottomAnchor.constraint(equalTo: pdfResultDetailsCard.bottomAnchor).isActive = true
    }

    private func setupImageView() {
        resultContentView.addSubview(fileResultImageView)
        fileResultImageView.centerXAnchor.constraint(equalTo: resultContentView.centerXAnchor).isActive = true
        fileResultImageView.topAnchor.constraint(equalTo: resultContentView.topAnchor, constant: 16).isActive = true
        fileResultImageView.heightAnchor.constraint(equalToConstant: 200).isActive = true
    }
    
    open func applyGradients() {
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
