//
//  ProviderSelectionViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2021-05-05.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import Lottie
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit

@objc open class ProviderSelectionViewV2: UIView, ProviderSelectionViewableV2 {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var providerSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewTitleTextColor
        return label
    }()

    public var providerSelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewDescriptionTextColor
        return label
    }()

    public var searchIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarSearchIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_country_selection_search", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()

    public var providerSearchBarLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.backgroundColor = .clear
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarHintTextColor
        label.font = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewSearchBarHintFont
        return label
    }()

    public var providerSearchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        searchBar.setImage(UIImage(), for: .search, state: .normal)
        searchBar.setPositionAdjustment(UIOffset(horizontal: -10, vertical: 0), for: .search)
        searchBar.semanticContentAttribute = .forceLeftToRight
        searchBar.barTintColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarBackgroundColor
        searchBar.backgroundColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarBackgroundColor
        searchBar.backgroundImage = UIImage()
        searchBar.layer.cornerRadius = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarCorderRadius
        searchBar.layer.borderWidth = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarBorderWidth
        searchBar.layer.borderColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarBorderColor.cgColor
        let textField = searchBar.searchTextField
        textField.backgroundColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarBackgroundColor
        textField.textColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderSearchBarTextColor
        textField.borderStyle = .none
        textField.clearButtonMode = .never
        textField.font = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewSearchBarFont
        if #available(iOS 26.0, *) {
            textField.layer.cornerRadius = 0
            textField.layer.borderWidth = 0
            textField.layer.masksToBounds = true
        }
        return searchBar
    }()

    public var searchBarMask: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .clear
        return view
    }()

    public var providerTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.isHidden = true
        tableView.bounces = false
        tableView.isScrollEnabled = true
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.backgroundColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderTableViewBackgroundColor
        tableView.showsVerticalScrollIndicator = false
        tableView.layer.cornerRadius = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderTableViewCornerRadius
        tableView.layer.borderWidth = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderTableViewBorderWidth
        tableView.layer.borderColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderTableViewBorderColor.cgColor
        return tableView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupSearchBar()
        setupProviderTableView()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(providerSelectionTitle)
        providerSelectionTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        providerSelectionTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        providerSelectionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(providerSelectionDescription)
        providerSelectionDescription.widthAnchor.constraint(equalTo: providerSelectionTitle.widthAnchor, multiplier: 0.8).isActive = true
        providerSelectionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        providerSelectionDescription.topAnchor.constraint(equalTo: providerSelectionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupSearchBar() {
        addSubview(providerSearchBar)
        providerSearchBar.topAnchor.constraint(equalTo: providerSelectionDescription.bottomAnchor, constant: 48).isActive = true
        providerSearchBar.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        providerSearchBar.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        providerSearchBar.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        providerSearchBar.heightAnchor.constraint(equalToConstant: 56).isActive = true

        addSubview(searchIcon)
        searchIcon.centerYAnchor.constraint(equalTo: providerSearchBar.centerYAnchor).isActive = true
        searchIcon.rightAnchor.constraint(equalTo: providerSearchBar.rightAnchor, constant: -16).isActive = true
        searchIcon.heightAnchor.constraint(equalToConstant: 17).isActive = true
        searchIcon.widthAnchor.constraint(equalTo: searchIcon.heightAnchor, multiplier: 1).isActive = true

        addSubview(providerSearchBarLabel)
        providerSearchBarLabel.leftAnchor.constraint(equalTo: providerSearchBar.leftAnchor, constant: 16).isActive = true
        providerSearchBarLabel.rightAnchor.constraint(equalTo: providerSearchBar.rightAnchor).isActive = true
        providerSearchBarLabel.topAnchor.constraint(equalTo: providerSearchBar.topAnchor).isActive = true
        providerSearchBarLabel.bottomAnchor.constraint(equalTo: providerSearchBar.bottomAnchor).isActive = true

        addSubview(searchBarMask)
        searchBarMask.leftAnchor.constraint(equalTo: providerSearchBar.safeLeftAnchor).isActive = true
        searchBarMask.rightAnchor.constraint(equalTo: providerSearchBar.safeRightAnchor).isActive = true
        searchBarMask.topAnchor.constraint(equalTo: providerSearchBar.safeTopAnchor).isActive = true
        searchBarMask.bottomAnchor.constraint(equalTo: providerSearchBar.safeBottomAnchor).isActive = true
    }

    open func setupProviderTableView() {
        addSubview(providerTableView)
        providerTableView.topAnchor.constraint(equalTo: providerSearchBar.bottomAnchor, constant: 24).isActive = true
        providerTableView.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        providerTableView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        providerTableView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        providerTableView.widthAnchor.constraint(equalTo: providerSearchBar.widthAnchor).isActive = true
        providerTableView.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -16).isActive = true
    }
}

@objc open class ProviderCell: UITableViewCell, ProviderCellViewable {
    public var hasBorder = false

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var providerLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderTableViewCellFont
        label.textAlignment = .left
        label.textColor = IdenfyProviderSelectionViewUISettingsV2.idenfyProviderSelectionViewProviderTableViewCellTextColor
        return label
    }()

    public var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        lottieView.contentMode = .scaleAspectFit
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        addSubview(cellView)
        cellView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(loadingSpinner)
        loadingSpinner.topAnchor.constraint(equalTo: cellView.safeTopAnchor).isActive = true
        loadingSpinner.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        loadingSpinner.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true

        cellView.addSubview(providerLabel)
        providerLabel.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        providerLabel.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -(frame.width * 0.3)).isActive = true
        providerLabel.topAnchor.constraint(equalTo: cellView.safeTopAnchor).isActive = true
        providerLabel.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        providerLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor).isActive = true
    }
}
