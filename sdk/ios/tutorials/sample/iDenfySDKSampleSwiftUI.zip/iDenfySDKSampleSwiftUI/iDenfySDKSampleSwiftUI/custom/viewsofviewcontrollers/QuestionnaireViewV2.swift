//
//  QuestionnaireViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 2022-09-15.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import Lottie
import UIKit

public protocol QuestionnaireViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
}

public protocol QuestionnaireViewableV2: UIView {
    var delegate: QuestionnaireViewButtonActionsDelegate? { get set }
    var idenfyToolbarV2Common: IdenfyToolbarV2Questionnaire { get }
    var questionnaireTitle: UILabel { get }
    var questionnaireDescription: UITextView { get }
    var questionnaireSectionTitle: UILabel { get }
    var questionnaireSectionDescription: UITextView { get }
    var questionnaireTableViewHeader: UIView { get }
    var questionnaireTableView: UITableView { get }
    var questionnaireDisabledContinueButton: UIButton { get }
    var questionnaireContinueButton: UIButton { get }
    var questionnaireContinueButtonSpinner: LottieAnimationView { get }
    
    func applyGradients()
}

@objc open class QuestionnaireViewV2: UIView, QuestionnaireViewableV2 {
    open weak var delegate: QuestionnaireViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyToolbarV2Questionnaire = {
        let toolbar = IdenfyToolbarV2Questionnaire(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var questionnaireTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewTitleTextColor
        return label
    }()

    public var questionnaireDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewDescriptionTextColor
        return label
    }()
    
    public var questionnaireSectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewSectionTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewSectionTitleTextColor
        return label
    }()

    public var questionnaireSectionDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.translatesAutoresizingMaskIntoConstraints = false
        label.dataDetectorTypes = UIDataDetectorTypes.all
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewSectionDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewSectionDescriptionTextColor
        return label
    }()
    
    public var questionnaireTableViewHeader: UIView = {
        let view = UIView()
        view.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        return view
    }()

    public var questionnaireTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.bounces = false
        tableView.isScrollEnabled = true
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.showsVerticalScrollIndicator = false
        tableView.isUserInteractionEnabled = true
        tableView.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        return tableView
    }()
    
    public var questionnaireDisabledContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var questionnaireContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.isHidden = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var questionnaireContinueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupTableViewHeader()
        setupQuestionnaireTableView()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        questionnaireContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTableViewHeader() {
        questionnaireTableViewHeader.addSubview(questionnaireTitle)
        questionnaireTitle.trailingAnchor.constraint(equalTo: questionnaireTableViewHeader.safeRightAnchor, constant: -16).isActive = true
        questionnaireTitle.leadingAnchor.constraint(equalTo: questionnaireTableViewHeader.safeLeftAnchor, constant: 16).isActive = true
        questionnaireTitle.topAnchor.constraint(equalTo: questionnaireTableViewHeader.safeTopAnchor, constant: 24).isActive = true

        questionnaireTableViewHeader.addSubview(questionnaireDescription)
        questionnaireDescription.widthAnchor.constraint(equalTo: questionnaireTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionnaireDescription.centerXAnchor.constraint(equalTo: questionnaireTableViewHeader.centerXAnchor).isActive = true
        questionnaireDescription.topAnchor.constraint(equalTo: questionnaireTitle.bottomAnchor, constant: 16).isActive = true
        
        questionnaireTableViewHeader.addSubview(questionnaireSectionTitle)
        questionnaireSectionTitle.trailingAnchor.constraint(equalTo: questionnaireTableViewHeader.safeRightAnchor, constant: -16).isActive = true
        questionnaireSectionTitle.leadingAnchor.constraint(equalTo: questionnaireTableViewHeader.safeLeftAnchor, constant: 16).isActive = true
        questionnaireSectionTitle.topAnchor.constraint(equalTo: questionnaireDescription.bottomAnchor, constant: 32).isActive = true

        questionnaireTableViewHeader.addSubview(questionnaireSectionDescription)
        questionnaireSectionDescription.widthAnchor.constraint(equalTo: questionnaireSectionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionnaireSectionDescription.centerXAnchor.constraint(equalTo: questionnaireTableViewHeader.centerXAnchor).isActive = true
        questionnaireSectionDescription.topAnchor.constraint(equalTo: questionnaireSectionTitle.bottomAnchor, constant: 16).isActive = true
        questionnaireSectionDescription.bottomAnchor.constraint(equalTo: questionnaireTableViewHeader.bottomAnchor, constant: -24).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(questionnaireDisabledContinueButton)
        questionnaireDisabledContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        questionnaireDisabledContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        questionnaireDisabledContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        questionnaireDisabledContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(questionnaireContinueButton)
        questionnaireContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        questionnaireContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        questionnaireContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        questionnaireContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(questionnaireContinueButtonSpinner)
        questionnaireContinueButtonSpinner.centerYAnchor.constraint(equalTo: questionnaireContinueButton.centerYAnchor).isActive = true
        questionnaireContinueButtonSpinner.leadingAnchor.constraint(equalTo: questionnaireContinueButton.safeLeftAnchor, constant: 16).isActive = true
        questionnaireContinueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        questionnaireContinueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        questionnaireContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }

    open func setupQuestionnaireTableView() {
        addSubview(questionnaireTableView)
        questionnaireTableView.topAnchor.constraint(equalTo: idenfyToolbarV2Common.safeBottomAnchor, constant: 1).isActive = true
        questionnaireTableView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        questionnaireTableView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        questionnaireTableView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        questionnaireTableView.bottomAnchor.constraint(equalTo: questionnaireContinueButton.topAnchor, constant: -8).isActive = true
    }
}
