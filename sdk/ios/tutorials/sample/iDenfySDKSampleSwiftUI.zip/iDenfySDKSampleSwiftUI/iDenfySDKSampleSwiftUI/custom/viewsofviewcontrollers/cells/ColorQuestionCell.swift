//
//  ColorQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2023-07-26.
//  Copyright © 2023 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class ColorQuestionCell: UITableViewCell, ColorQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var colorInputView: UIView = {
        let textField = UIView(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.backgroundColor = UIColor.black
        textField.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyColorQuestionColorPickerBorderCornerRadius
        textField.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyColorQuestionColorPickerBorderWidth
        textField.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyColorQuestionColorPickerBorderColor.cgColor
        textField.layer.masksToBounds = true
        return textField
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leadingAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.trailingAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(colorInputView)
        colorInputView.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        colorInputView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        colorInputView.heightAnchor.constraint(equalToConstant: 30).isActive = true
        colorInputView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        colorInputView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
    }
}

