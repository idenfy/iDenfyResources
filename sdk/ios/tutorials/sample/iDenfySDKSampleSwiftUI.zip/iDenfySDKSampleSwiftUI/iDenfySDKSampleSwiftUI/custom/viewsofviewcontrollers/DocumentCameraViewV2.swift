//
//  DocumentCameraViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class DocumentCameraViewV2: UIView, DocumentCameraViewableV2 {
    public var documentCameraAlertCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraAlertCardBackgroundColor
        view.isHidden = true
        return view
    }()

    public var documentCameraAlertCardImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = UIImage(named: "idenfy_ic_warning_alert", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraAlertCardImageTintColor
        return imageView
    }()

    public var documentCameraAlertCardTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraAlertCardTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraAlertCardTitleColor
        return label
    }()
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public convenience init() {
        self.init(frame: CGRect.zero)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public lazy var cameraView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        view.backgroundColor = IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionBackgroundColor
        return view
    }()

    public var photoImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        return imageView
    }()

    public var rectangleView: IdenfyRectangleViewV2 = {
        let view = IdenfyRectangleViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.clear
        view.tintColor = UIColor.clear
        view.isOpaque = true
        return view
    }()
    
    public var rectanglePathView: IdenfyRectanglePathViewV2 = {
        let imageView = IdenfyRectanglePathViewV2(frame: .zero)
        imageView.isOpaque = true
        imageView.contentMode = .scaleToFill
        return imageView
    }()

    public var cameraSessionsButtons: CameraSessionsButtonsViewableV2 = {
        let view = CameraSessionsButtonsViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        return view
    }()
    
    public var drawerContentView: DrawerContentViewableV2 = {
        let view = DrawerContentViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    @objc private func setupConstraints() {
        setupCameraView()
        setupPhotoView()
        setupRectangleView()
        setupCameraSessionsButtons()
        setupDocumentWarningCard()
        setupDrawerView()
    }
    
    func setupDrawerView() {
        addSubview(drawerContentView)
        drawerContentView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        drawerContentView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        drawerContentView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        drawerContentView.heightAnchor.constraint(equalToConstant: CameraSessionUIHelper.getDrawerHeight()).isActive = true
    }

    func setupCameraSessionsButtons() {
        addSubview(cameraSessionsButtons)
        cameraSessionsButtons.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        cameraSessionsButtons.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        cameraSessionsButtons.topAnchor.constraint(equalTo: topAnchor).isActive = true
        cameraSessionsButtons.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    func setupCameraView() {
        addSubview(cameraView)
        cameraView.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        cameraView.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        cameraView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        cameraView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    func setupPhotoView() {
        cameraView.addSubview(photoImageView)
        photoImageView.topAnchor.constraint(equalTo: cameraView.topAnchor).isActive = true
        photoImageView.bottomAnchor.constraint(equalTo: cameraView.bottomAnchor).isActive = true
        photoImageView.leadingAnchor.constraint(equalTo: cameraView.leadingAnchor).isActive = true
        photoImageView.trailingAnchor.constraint(equalTo: cameraView.trailingAnchor).isActive = true
    }
    
    func setupDocumentWarningCard() {
        addSubview(documentCameraAlertCard)
        documentCameraAlertCard.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        documentCameraAlertCard.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -(UIScreen.main.bounds.height * ConstsIdenfyUI.idenfyCameraBottomControlsHeightMultiplier + 16)).isActive = true
        documentCameraAlertCard.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
        documentCameraAlertCard.rightAnchor.constraint(equalTo: rightAnchor, constant: -16).isActive = true
        documentCameraAlertCard.heightAnchor.constraint(greaterThanOrEqualToConstant: 50).isActive = true

        documentCameraAlertCard.addSubview(documentCameraAlertCardImage)
        documentCameraAlertCardImage.leftAnchor.constraint(equalTo: documentCameraAlertCard.safeLeftAnchor, constant: 16).isActive = true
        documentCameraAlertCardImage.topAnchor.constraint(equalTo: documentCameraAlertCard.safeTopAnchor).isActive = true
        documentCameraAlertCardImage.bottomAnchor.constraint(equalTo: documentCameraAlertCard.safeBottomAnchor).isActive = true

        documentCameraAlertCard.addSubview(documentCameraAlertCardTitle)
        documentCameraAlertCardTitle.leftAnchor.constraint(equalTo: documentCameraAlertCard.safeLeftAnchor, constant: 50).isActive = true
        documentCameraAlertCardTitle.rightAnchor.constraint(equalTo: documentCameraAlertCard.safeRightAnchor, constant: -24).isActive = true
        documentCameraAlertCardTitle.topAnchor.constraint(equalTo: documentCameraAlertCard.safeTopAnchor, constant: 8).isActive = true
        documentCameraAlertCardTitle.bottomAnchor.constraint(equalTo: documentCameraAlertCard.safeBottomAnchor, constant: -8).isActive = true
    }

    func setupRectangleView() {
        cameraView.addSubview(rectangleView)
        cameraView.addSubview(rectanglePathView)
        rectangleView.topAnchor.constraint(equalTo: cameraView.topAnchor).isActive = true
        rectangleView.bottomAnchor.constraint(equalTo: cameraView.bottomAnchor).isActive = true
        rectangleView.leadingAnchor.constraint(equalTo: cameraView.leadingAnchor).isActive = true
        rectangleView.trailingAnchor.constraint(equalTo: cameraView.trailingAnchor).isActive = true
    }
}
