//
//  EIDSessionCPFCheckViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juškys on 02/10/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol EIDSessionCPFCheckViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
    func dateOfBirthFieldTapped()
}

public protocol EIDSessionCPFCheckViewableV2: UIView {
    var delegate: EIDSessionCPFCheckViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var eidSessionTitle: UILabel { get }
    var eidSessionDescription: UILabel { get }
    var cpfTextField: UITextField { get }
    var cpfErrorLabel: UILabel { get }
    var dateOfBirthTextField: UITextField { get }
    var errorCardView: UIView { get }
    var errorCardLabel: UILabel { get }
    var eidSessionContinueButton: UIButton { get }
    var eidSessionContinueDisabledButton: UIButton { get }
    var continueButtonSpinner: LottieAnimationView { get }

    func applyGradients()
}

@objc open class EIDSessionCPFCheckViewV2: UIView, EIDSessionCPFCheckViewableV2 {
    open weak var delegate: EIDSessionCPFCheckViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var eidSessionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewTitleFont
        label.textAlignment = .center
        label.textColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewTitleTextColor
        return label
    }()

    public var eidSessionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewDescriptionFont
        label.textAlignment = .center
        label.textColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewDescriptionTextColor
        return label
    }()

    public var cpfTextField: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.borderStyle = .none
        textField.layer.cornerRadius = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewInputCornerRadius
        textField.layer.borderWidth = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewInputBorderWidth
        textField.layer.borderColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewCpfInputBorderColor.cgColor
        textField.textColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewCpfInputTextColor
        textField.font = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewCpfInputFont
        textField.keyboardType = .numberPad
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var cpfErrorLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewErrorCardTextFont
        label.textAlignment = .natural
        label.textColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewCpfErrorTextColor
        label.isHidden = true
        return label
    }()

    public var dateOfBirthTextField: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.borderStyle = .none
        textField.layer.cornerRadius = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewInputCornerRadius
        textField.layer.borderWidth = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewInputBorderWidth
        textField.layer.borderColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewDateOfBirthInputBorderColor.cgColor
        textField.textColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewDateOfBirthInputTextColor
        textField.font = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewDateOfBirthInputFont
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var errorCardView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        view.layer.cornerRadius = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewInputCornerRadius
        view.layer.borderWidth = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewInputBorderWidth
        view.layer.borderColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewErrorCardBorderColor.cgColor
        view.backgroundColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewErrorCardBackgroundColor
        return view
    }()

    public var errorCardIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_information_icon).withRenderingMode(.alwaysTemplate)
        imageView.tintColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewErrorCardIconTintColor
        return imageView
    }()

    public var errorCardLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewErrorCardTextFont
        label.textAlignment = .natural
        label.textColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewErrorCardTextColor
        return label
    }()

    public var eidSessionContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var eidSessionContinueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = EIDSessionCPFCheckViewUISettingsV2.idenfyEIDSessionCPFCheckViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupCpfField()
        setupDateOfBirthField()
        setupErrorCard()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        eidSessionContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
        dateOfBirthTextField.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dateOfBirthFieldTapped)))
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    @objc func dateOfBirthFieldTapped() {
        delegate?.dateOfBirthFieldTapped()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(eidSessionTitle)
        eidSessionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        eidSessionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        eidSessionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(eidSessionDescription)
        eidSessionDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        eidSessionDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        eidSessionDescription.topAnchor.constraint(equalTo: eidSessionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCpfField() {
        addSubview(cpfTextField)
        cpfTextField.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        cpfTextField.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        cpfTextField.topAnchor.constraint(equalTo: eidSessionDescription.bottomAnchor, constant: 24).isActive = true
        cpfTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true

        addSubview(cpfErrorLabel)
        cpfErrorLabel.topAnchor.constraint(equalTo: cpfTextField.topAnchor, constant: 2).isActive = true
        cpfErrorLabel.leadingAnchor.constraint(equalTo: cpfTextField.leadingAnchor, constant: 10).isActive = true
        cpfErrorLabel.trailingAnchor.constraint(equalTo: cpfTextField.trailingAnchor).isActive = true
    }

    open func setupDateOfBirthField() {
        addSubview(dateOfBirthTextField)
        dateOfBirthTextField.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        dateOfBirthTextField.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        dateOfBirthTextField.topAnchor.constraint(equalTo: cpfTextField.bottomAnchor, constant: 12).isActive = true
        dateOfBirthTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }

    open func setupErrorCard() {
        addSubview(errorCardView)
        errorCardView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        errorCardView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        errorCardView.topAnchor.constraint(equalTo: dateOfBirthTextField.bottomAnchor, constant: 8).isActive = true

        errorCardView.addSubview(errorCardIcon)
        errorCardIcon.leadingAnchor.constraint(equalTo: errorCardView.leadingAnchor, constant: 16).isActive = true
        errorCardIcon.centerYAnchor.constraint(equalTo: errorCardView.centerYAnchor).isActive = true
        errorCardIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        errorCardIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true

        errorCardView.addSubview(errorCardLabel)
        errorCardLabel.leadingAnchor.constraint(equalTo: errorCardIcon.trailingAnchor, constant: 8).isActive = true
        errorCardLabel.trailingAnchor.constraint(equalTo: errorCardView.trailingAnchor, constant: -16).isActive = true
        errorCardLabel.topAnchor.constraint(equalTo: errorCardView.topAnchor, constant: 12).isActive = true
        errorCardLabel.bottomAnchor.constraint(equalTo: errorCardView.bottomAnchor, constant: -12).isActive = true
    }

    open func setupContinueButton() {
        addSubview(eidSessionContinueButton)
        eidSessionContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(eidSessionContinueDisabledButton)
        eidSessionContinueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: eidSessionContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: eidSessionContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func applyGradients() {
        eidSessionContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
