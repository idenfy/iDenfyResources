//
//  BankCardPhotoResultViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-09-28.
//  Copyright (c) 2026 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

// swiftlint:disable all

@objc open class BankCardPhotoResultViewV2: CameraResultViewV2, BankCardPhotoResultViewableV2 {

    public var webViewContainer: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.clipsToBounds = true
        return view
    }()

    public var photoResultDetailsCardThird: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardQuestionMarkThird: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return imageView
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    public var photoResultDetailsCardTitleThird: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public convenience init() {
        self.init(frame: .zero, withRectangle: .withRectangle)
    }

    public required init(frame: CGRect, withRectangle: IdenfyCameraViewType) {
        super.init(frame: frame, withRectangle: withRectangle)
        setupBankCardWebView()
    }

    public required convenience init?(coder: NSCoder) {
        self.init(frame: .zero, withRectangle: .withRectangle)
    }

    private func setupBankCardWebView() {
        let screenWidth = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first?.screen.bounds.width ?? 0
        let imageWidth = screenWidth - 32
        let imageHeight = imageWidth * (9.0 / 16.0)
        for constraint in fileResultImageView.constraints {
            if constraint.identifier == "photoWidth" {
                constraint.constant = imageWidth
            }
            if constraint.identifier == "photoHeight" {
                constraint.constant = imageHeight
            }
        }

        addSubview(webViewContainer)
        NSLayoutConstraint.activate([
            webViewContainer.topAnchor.constraint(equalTo: fileResultImageView.topAnchor),
            webViewContainer.bottomAnchor.constraint(equalTo: fileResultImageView.bottomAnchor),
            webViewContainer.leadingAnchor.constraint(equalTo: fileResultImageView.leadingAnchor),
            webViewContainer.trailingAnchor.constraint(equalTo: fileResultImageView.trailingAnchor),
        ])

        photoResultDetailsCard.isHidden = false
        photoResultDetailsCardSecond.isHidden = false

        addSubview(photoResultDetailsCardThird)
        photoResultDetailsCardThird.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        photoResultDetailsCardThird.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        photoResultDetailsCardThird.topAnchor.constraint(equalTo: photoResultDetailsCardSecond.bottomAnchor, constant: 16).isActive = true
        photoResultDetailsCardThird.heightAnchor.constraint(equalToConstant: 50).isActive = true
        let bottomConstraint = photoResultDetailsCardThird.bottomAnchor.constraint(equalTo: continueButton.topAnchor, constant: -16)
        bottomConstraint.priority = .fittingSizeLevel
        bottomConstraint.isActive = true

        photoResultDetailsCardThird.addSubview(photoResultDetailsCardQuestionMarkThird)
        photoResultDetailsCardQuestionMarkThird.leadingAnchor.constraint(equalTo: photoResultDetailsCardThird.safeLeftAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMarkThird.topAnchor.constraint(equalTo: photoResultDetailsCardThird.safeTopAnchor).isActive = true
        photoResultDetailsCardQuestionMarkThird.bottomAnchor.constraint(equalTo: photoResultDetailsCardThird.safeBottomAnchor).isActive = true

        photoResultDetailsCardThird.addSubview(photoResultDetailsCardTitleThird)
        photoResultDetailsCardTitleThird.leadingAnchor.constraint(equalTo: photoResultDetailsCardThird.safeLeftAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitleThird.trailingAnchor.constraint(equalTo: photoResultDetailsCardThird.safeRightAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitleThird.topAnchor.constraint(equalTo: photoResultDetailsCardThird.safeTopAnchor).isActive = true
        photoResultDetailsCardTitleThird.bottomAnchor.constraint(equalTo: photoResultDetailsCardThird.safeBottomAnchor).isActive = true

        addSubview(continueButtonSpinner)
        NSLayoutConstraint.activate([
            continueButtonSpinner.centerYAnchor.constraint(equalTo: continueButton.centerYAnchor),
            continueButtonSpinner.leadingAnchor.constraint(equalTo: continueButton.safeLeftAnchor, constant: 16),
            continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25),
            continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25),
        ])
    }
}
