//
//  BankCardPhotoResultViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-09-28.
//  Copyright (c) 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie
import idenfycore

// swiftlint:disable all

public protocol BankCardPhotoResultViewableV2: CameraResultViewableV2 {
    var webViewContainer: UIView { get }
    var photoResultDetailsCardThird: UIView { get }
    var photoResultDetailsCardQuestionMarkThird: UIImageView { get }
    var photoResultDetailsCardTitleThird: UILabel { get }
    var continueButtonSpinner: LottieAnimationView { get }
}

@objc open class BankCardPhotoResultViewV2: CameraResultViewV2, BankCardPhotoResultViewableV2 {

    public var webViewContainer: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.clipsToBounds = true
        return view
    }()

    public var photoResultDetailsCardThird: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardQuestionMarkThird: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_photo_result_view_details_card_questionmark).withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return imageView
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewConfirmButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    public var photoResultDetailsCardTitleThird: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public convenience init() {
        self.init(frame: .zero, withRectangle: .withRectangle)
    }

    public required init(frame: CGRect, withRectangle: IdenfyCameraViewType) {
        super.init(frame: frame, withRectangle: withRectangle)
        setupBankCardWebView()
    }

    public required convenience init?(coder: NSCoder) {
        self.init(frame: .zero, withRectangle: .withRectangle)
    }

    private func setupBankCardWebView() {
        // Remove the fixed width/height constraints from parent, use proportional instead
        for constraint in fileResultImageView.constraints {
            if constraint.identifier == "photoWidth" || constraint.identifier == "photoHeight" {
                constraint.isActive = false
            }
        }
        fileResultImageView.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 16).isActive = true
        fileResultImageView.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -16).isActive = true
        fileResultImageView.heightAnchor.constraint(equalTo: fileResultImageView.widthAnchor, multiplier: 9.0 / 16.0).isActive = true

        resultContentView.addSubview(webViewContainer)
        NSLayoutConstraint.activate([
            webViewContainer.topAnchor.constraint(equalTo: fileResultImageView.topAnchor),
            webViewContainer.bottomAnchor.constraint(equalTo: fileResultImageView.bottomAnchor),
            webViewContainer.leadingAnchor.constraint(equalTo: fileResultImageView.leadingAnchor),
            webViewContainer.trailingAnchor.constraint(equalTo: fileResultImageView.trailingAnchor),
        ])

        photoResultDetailsCard.isHidden = false
        photoResultDetailsCardSecond.isHidden = false

        // Remove the parent's bottom constraint on photoResultDetailsCardSecond so we can extend with a third card
        for constraint in resultContentView.constraints where constraint.firstItem === photoResultDetailsCardSecond && constraint.firstAttribute == .bottom {
            constraint.isActive = false
        }

        resultContentView.addSubview(photoResultDetailsCardThird)
        photoResultDetailsCardThird.leadingAnchor.constraint(equalTo: resultContentView.leadingAnchor, constant: 32).isActive = true
        photoResultDetailsCardThird.trailingAnchor.constraint(equalTo: resultContentView.trailingAnchor, constant: -32).isActive = true
        photoResultDetailsCardThird.topAnchor.constraint(equalTo: photoResultDetailsCardSecond.bottomAnchor, constant: 16).isActive = true
        photoResultDetailsCardThird.heightAnchor.constraint(equalToConstant: 50).isActive = true
        photoResultDetailsCardThird.bottomAnchor.constraint(equalTo: resultContentView.bottomAnchor, constant: -16).isActive = true

        photoResultDetailsCardThird.addSubview(photoResultDetailsCardQuestionMarkThird)
        photoResultDetailsCardQuestionMarkThird.leadingAnchor.constraint(equalTo: photoResultDetailsCardThird.leadingAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMarkThird.topAnchor.constraint(equalTo: photoResultDetailsCardThird.topAnchor).isActive = true
        photoResultDetailsCardQuestionMarkThird.bottomAnchor.constraint(equalTo: photoResultDetailsCardThird.bottomAnchor).isActive = true

        photoResultDetailsCardThird.addSubview(photoResultDetailsCardTitleThird)
        photoResultDetailsCardTitleThird.leadingAnchor.constraint(equalTo: photoResultDetailsCardThird.leadingAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitleThird.trailingAnchor.constraint(equalTo: photoResultDetailsCardThird.trailingAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitleThird.topAnchor.constraint(equalTo: photoResultDetailsCardThird.topAnchor).isActive = true
        photoResultDetailsCardTitleThird.bottomAnchor.constraint(equalTo: photoResultDetailsCardThird.bottomAnchor).isActive = true

        addSubview(continueButtonSpinner)
        NSLayoutConstraint.activate([
            continueButtonSpinner.centerYAnchor.constraint(equalTo: continueButton.centerYAnchor),
            continueButtonSpinner.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 16),
            continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25),
            continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25),
        ])
    }
}
