//
//  MFAGeneralViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-04-08.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol MFAGeneralViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
}

public protocol MFAGeneralViewableV2: UIView {
    var delegate: MFAGeneralViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var mfaGeneralTitle: UILabel { get }
    var mfaGeneralDescription: UILabel { get }
    var mfaGeneralHintLabel: UILabel { get }
    var mfaGeneralInputView: UITextField { get }
    var mfaContinueButton: UIButton { get }
    var mfaExternalPhoneImageView: UIImageView { get }
    var continueButtonSpinner: LottieAnimationView { get }
    
    func applyGradients()
}

@objc open class MFAGeneralViewV2: UIView, MFAGeneralViewableV2 {
    open weak var delegate: MFAGeneralViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var mfaGeneralTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewTitleTextColor
        return label
    }()

    public var mfaGeneralDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewDescriptionTextColor
        return label
    }()
    
    public var mfaGeneralHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewHintFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewHintTextColor
        return label
    }()
    
    public var mfaGeneralInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewInputViewFont
        textField.textColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewInputViewTextColor
        textField.backgroundColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewInputViewBackgroundColor
        textField.returnKeyType = .done
        textField.layer.cornerRadius = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewInputViewCorderRadius
        textField.layer.borderWidth = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewInputViewBorderWidth
        textField.layer.borderColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewInputBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        return textField
    }()
    
    public var mfaExternalPhoneImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isHidden = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_external_phone)
        return imageView
    }()

    public var mfaContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewContinueButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.isHidden = true
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.applyColorTint(IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyMFAGeneralViewUISettingsV2.idenfyMFAGeneralViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupTopTitle()
        setupCenterTextFields()
        setupButtonActions()
    }

    private func setupButtonActions() {
        mfaContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(mfaGeneralTitle)
        mfaGeneralTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        mfaGeneralTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        mfaGeneralTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(mfaGeneralDescription)
        mfaGeneralDescription.widthAnchor.constraint(equalTo: mfaGeneralTitle.widthAnchor, multiplier: 0.8).isActive = true
        mfaGeneralDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        mfaGeneralDescription.topAnchor.constraint(equalTo: mfaGeneralTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupContinueButton() {
        addSubview(mfaContinueButton)
        mfaContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        mfaContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        mfaContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        mfaContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: mfaContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: mfaContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func setupCenterTextFields() {
        addSubview(mfaGeneralInputView)
        mfaGeneralInputView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        mfaGeneralInputView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        mfaGeneralInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        mfaGeneralInputView.leadingAnchor.constraint(equalTo: mfaContinueButton.leadingAnchor, constant: 24).isActive = true
        mfaGeneralInputView.trailingAnchor.constraint(equalTo: mfaContinueButton.trailingAnchor, constant: -24).isActive = true
        
        addSubview(mfaExternalPhoneImageView)
        mfaExternalPhoneImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        mfaExternalPhoneImageView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        mfaExternalPhoneImageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        mfaExternalPhoneImageView.heightAnchor.constraint(equalTo: mfaExternalPhoneImageView.widthAnchor, multiplier: 1).isActive = true
        
        addSubview(mfaGeneralHintLabel)
        mfaGeneralHintLabel.topAnchor.constraint(equalTo: mfaGeneralInputView.topAnchor, constant: 2).isActive = true
        mfaGeneralHintLabel.leadingAnchor.constraint(equalTo: mfaGeneralInputView.safeLeftAnchor, constant: 10).isActive = true
        mfaGeneralHintLabel.trailingAnchor.constraint(equalTo: mfaGeneralInputView.safeRightAnchor).isActive = true
    }
    
    open func applyGradients() {
        mfaContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
