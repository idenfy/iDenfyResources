//
//  NFCRequiredViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2021-04-06.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class NFCRequiredViewV2: UIView, NFCRequiredViewableV2 {
    open weak var delegate: NFCRequiredViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.backButton.isHidden = true
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var idenfyUILabelNFCRequiredCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyNFCRequiredViewUISettingsV2.idenfyNFCRequiredCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyNFCRequiredViewUISettingsV2.idenfyNFCRequiredCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelNFCRequiredCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyNFCRequiredViewUISettingsV2.idenfyNFCRequiredCommonInformationDescriptionFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyNFCRequiredViewUISettingsV2.idenfyNFCRequiredCommonInformationDescriptionTextColor
        return label
    }()
    
    public var idenfyUIViewCenterSpace: UIView = {
        let uiview = UIView()
        uiview.translatesAutoresizingMaskIntoConstraints = false
        return uiview
    }()

    public var idenfyUIImageViewNFCRequiredCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_nfc_reading_failure", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyUIButtonNFCRequiredContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = IdenfyNFCRequiredViewUISettingsV2.idenfyNFCRequiredContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyNFCRequiredViewUISettingsV2.idenfyNFCRequiredViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupCenterImageView()
        setupButtonActions()
    }

    private func setupButtonActions() {
        idenfyUIButtonNFCRequiredContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelNFCRequiredCommonInformationTitle)
        idenfyUILabelNFCRequiredCommonInformationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelNFCRequiredCommonInformationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelNFCRequiredCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelNFCRequiredCommonInformationDescription)
        idenfyUILabelNFCRequiredCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelNFCRequiredCommonInformationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUILabelNFCRequiredCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelNFCRequiredCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIViewCenterSpace)
        idenfyUIViewCenterSpace.topAnchor.constraint(equalTo: idenfyUILabelNFCRequiredCommonInformationDescription.bottomAnchor, constant: 32).isActive = true
        let bottom = idenfyUIViewCenterSpace.bottomAnchor.constraint(equalTo: idenfyUIButtonNFCRequiredContinue.topAnchor, constant: -50)
        bottom.isActive = true
        bottom.priority = UILayoutPriority.fittingSizeLevel
        idenfyUIViewCenterSpace.leftAnchor.constraint(equalTo: leftAnchor, constant: 30).isActive = true
        idenfyUIViewCenterSpace.rightAnchor.constraint(equalTo: rightAnchor, constant: -50).isActive = true
        
        idenfyUIViewCenterSpace.addSubview(idenfyUIImageViewNFCRequiredCommonInformationIcon)
        idenfyUIImageViewNFCRequiredCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUIViewCenterSpace.topAnchor).isActive = true
        idenfyUIImageViewNFCRequiredCommonInformationIcon.leftAnchor.constraint(equalTo: idenfyUIViewCenterSpace.leftAnchor).isActive = true
        idenfyUIImageViewNFCRequiredCommonInformationIcon.rightAnchor.constraint(equalTo: idenfyUIViewCenterSpace.rightAnchor).isActive = true
        idenfyUIImageViewNFCRequiredCommonInformationIcon.bottomAnchor.constraint(equalTo: idenfyUIViewCenterSpace.bottomAnchor).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIButtonNFCRequiredContinue)
        idenfyUIButtonNFCRequiredContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIButtonNFCRequiredContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIButtonNFCRequiredContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIButtonNFCRequiredContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIButtonNFCRequiredContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
