//
//  StaticCameraOnBoardingViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2022-03-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit
import AVFoundation
import Lottie

@objc open class StaticCameraOnBoardingViewV2: UIView, StaticCameraOnBoardingViewableV2 {
    open weak var delegate: StaticCameraOnBoardingViewButtonActionsDelegate?
    
    public var documentTypeData: DocumentTypeData!
    public var shouldInstructionsBePlayed: Bool! {
        didSet {
            setupConstraints()
        }
    }
    public var currentStep: Step!
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyCameraOnBoardingToolbarV2 = {
        let toolbar = IdenfyCameraOnBoardingToolbarV2(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var idenfyUILabelCameraOnBoardingCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelCameraOnBoardingCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 5
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewCameraOnBoardingCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_camera_onboarding_other_document_image", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()

    public var idenfyUIDisabledButtonCameraOnBoardingContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonTextColor, for: .normal)
        button.backgroundColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonBackgroundColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var idenfyUIEnabledButtonCameraOnBoardingContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingEnabledContinueButtonTextColor, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.isHidden = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var instrutionCameraOnBoardingVideoContainer: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        return view
    }()
    
    public var instructionCameraOnBoardingProgressView: UIProgressView = {
        let progressView = UIProgressView(frame: .zero)
        progressView.translatesAutoresizingMaskIntoConstraints = false
        progressView.progressTintColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewProgressBarFillColor
        progressView.trackTintColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewProgressBackgroundColor
        return progressView
    }()
    
    public var idenfyUILabelinstructionDescriptionsTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTitleTextFont
        label.textAlignment = .left
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTitleTextColor
        return label
    }()
    
    public var instructionDescriptionsTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.bounces = false
        tableView.isScrollEnabled = true
        tableView.allowsSelection = false
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.backgroundColor = .clear
        return tableView
    }()
    
    public var idenfyLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_animation_nfc_screen_loading_indicator", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        return lottieView
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupButtonActions()
        if shouldInstructionsBePlayed {
            setupCenterVideoView()
        } else {
            setupCenterImageView()
        }
    }

    private func setupButtonActions() {
        idenfyUIEnabledButtonCameraOnBoardingContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }
    
    public func playInstructions(_ trustedPartner: Bool) -> InstructionVideo {
        let instructionVideo = InstructionVideo(frame: instrutionCameraOnBoardingVideoContainer.bounds)
        switch currentStep! {
        case Step.FACE:
            instructionVideo.configure("idenfy_instructions_face_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
        case Step.LIVENESS:
            instructionVideo.configure("idenfy_instructions_liveness_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
        default:
            switch trustedPartner {
            case true:
                instructionVideo.configure("idenfy_instructions_document_trusted_partner", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
            case false:
                instructionVideo.configure("idenfy_instructions_document_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
            }
        }
        instructionVideo.isLoop = true
        instructionVideo.play()
        instrutionCameraOnBoardingVideoContainer.addSubview(instructionVideo)
        return instructionVideo
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelCameraOnBoardingCommonInformationTitle)
        idenfyUILabelCameraOnBoardingCommonInformationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelCameraOnBoardingCommonInformationDescription)
        idenfyUILabelCameraOnBoardingCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.9).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupCenterVideoView() {
        addSubview(instrutionCameraOnBoardingVideoContainer)
        instrutionCameraOnBoardingVideoContainer.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        instrutionCameraOnBoardingVideoContainer.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationDescription.bottomAnchor, constant: 32).isActive = true
        instrutionCameraOnBoardingVideoContainer.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        instrutionCameraOnBoardingVideoContainer.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        instrutionCameraOnBoardingVideoContainer.heightAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.widthAnchor, multiplier: 0.6).isActive = true
        
        addSubview(idenfyLoadingSpinner)
        idenfyLoadingSpinner.centerXAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.centerXAnchor).isActive = true
        idenfyLoadingSpinner.centerYAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.centerYAnchor).isActive = true
        idenfyLoadingSpinner.heightAnchor.constraint(equalToConstant: 130).isActive = true
        idenfyLoadingSpinner.widthAnchor.constraint(equalToConstant: 130).isActive = true
        
        bringSubviewToFront(instrutionCameraOnBoardingVideoContainer)
        
        addSubview(instructionCameraOnBoardingProgressView)
        instructionCameraOnBoardingProgressView.topAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.bottomAnchor, constant: 16).isActive = true
        instructionCameraOnBoardingProgressView.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        instructionCameraOnBoardingProgressView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        instructionCameraOnBoardingProgressView.heightAnchor.constraint(equalToConstant: 5).isActive = true
        
        addSubview(idenfyUILabelinstructionDescriptionsTitle)
        idenfyUILabelinstructionDescriptionsTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelinstructionDescriptionsTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUILabelinstructionDescriptionsTitle.topAnchor.constraint(equalTo: instructionCameraOnBoardingProgressView.bottomAnchor, constant: 16).isActive = true
        
        addSubview(instructionDescriptionsTableView)
        instructionDescriptionsTableView.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        instructionDescriptionsTableView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        instructionDescriptionsTableView.topAnchor.constraint(equalTo: idenfyUILabelinstructionDescriptionsTitle.bottomAnchor, constant: 16).isActive = true
        let bottom = instructionDescriptionsTableView.bottomAnchor.constraint(equalTo: idenfyUIDisabledButtonCameraOnBoardingContinue.topAnchor, constant: -16)
        bottom.priority = .fittingSizeLevel
        bottom.isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIImageViewCameraOnBoardingCommonInformationIcon)
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationDescription.bottomAnchor, constant: 32).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.heightAnchor.constraint(equalToConstant: 170).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIEnabledButtonCameraOnBoardingContinue)
        idenfyUIEnabledButtonCameraOnBoardingContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(idenfyUIDisabledButtonCameraOnBoardingContinue)
        idenfyUIDisabledButtonCameraOnBoardingContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIEnabledButtonCameraOnBoardingContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

@objc open class InstructionDescriptionsCellV2: UITableViewCell, InstructionDescriptionsCellViewableV2 {
    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var instructionDescriptionsLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTableViewCellTextFont
        label.text = "Step"
        label.textAlignment = .left
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTableViewCellTextColor
        return label
    }()

    public var instructionDescriptionsCircle: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.isOpaque = true
        imageView.tintColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsCellCircleTintColor
        imageView.image = UIImage(named: "idenfy_ic_confirmation_item_step_circle", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    open func setupView() {
        addSubview(cellView)
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true

        cellView.addSubview(instructionDescriptionsCircle)
        instructionDescriptionsCircle.heightAnchor.constraint(equalToConstant: 8).isActive = true
        instructionDescriptionsCircle.widthAnchor.constraint(equalTo: instructionDescriptionsCircle.heightAnchor, multiplier: 1).isActive = true
        instructionDescriptionsCircle.centerYAnchor.constraint(equalTo: cellView.centerYAnchor).isActive = true
        instructionDescriptionsCircle.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor).isActive = true

        cellView.addSubview(instructionDescriptionsLabel)
        instructionDescriptionsLabel.topAnchor.constraint(equalTo: cellView.topAnchor, constant: 4).isActive = true
        instructionDescriptionsLabel.bottomAnchor.constraint(equalTo: cellView.bottomAnchor, constant: -4).isActive = true
        instructionDescriptionsLabel.leftAnchor.constraint(equalTo: instructionDescriptionsCircle.rightAnchor, constant: 16).isActive = true
        instructionDescriptionsLabel.rightAnchor.constraint(equalTo: cellView.rightAnchor).isActive = true
    }
}


