//
//  StaticCameraOnBoardingViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-03-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import Lottie
import UIKit
import AVFoundation
import idenfycore

public protocol StaticCameraOnBoardingViewButtonActionsDelegate: AnyObject {
    func continueButtonPressedAction()
}

public protocol StaticCameraOnBoardingViewableV2: UIView {
    var delegate: StaticCameraOnBoardingViewButtonActionsDelegate? { get set }
    var idenfyToolbarV2Common: IdenfyCameraOnBoardingToolbarV2 { get }
    var idenfyUILabelCameraOnBoardingCommonInformationTitle: UILabel { get }
    var idenfyUILabelCameraOnBoardingCommonInformationDescription: UILabel { get }
    var idenfyUIImageViewCameraOnBoardingCommonInformationIcon: UIImageView { get }
    var idenfyUIDisabledButtonCameraOnBoardingContinue: UIButton { get }
    var idenfyUIEnabledButtonCameraOnBoardingContinue: UIButton { get }
    var instrutionCameraOnBoardingVideoContainer: UIView { get }
    var instructionCameraOnBoardingProgressView: UIProgressView { get }
    var idenfyLoadingSpinner: LottieAnimationView { get }
    var instructionDescriptionsTableView: UITableView { get }
    var idenfyUILabelinstructionDescriptionsTitle: UILabel { get }
    
    var shouldInstructionsBePlayed: Bool! { get set }
    var documentTypeData: DocumentTypeData! { get set }
    var currentStep: Step! { get set }
    
    func playInstructions(_ trustedPartner: Bool) -> InstructionVideo
    func applyGradients()
}

@objc open class StaticCameraOnBoardingViewV2: UIView, StaticCameraOnBoardingViewableV2 {
    open weak var delegate: StaticCameraOnBoardingViewButtonActionsDelegate?
    
    public var documentTypeData: DocumentTypeData!
    public var shouldInstructionsBePlayed: Bool! {
        didSet {
            setupConstraints()
        }
    }
    public var currentStep: Step!
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyCameraOnBoardingToolbarV2 = {
        let toolbar = IdenfyCameraOnBoardingToolbarV2(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var idenfyUILabelCameraOnBoardingCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelCameraOnBoardingCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 5
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewCameraOnBoardingCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_camera_onboarding_other_document_image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()

    public var idenfyUIDisabledButtonCameraOnBoardingContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonTextColor, for: .normal)
        button.backgroundColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var idenfyUIEnabledButtonCameraOnBoardingContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingEnabledContinueButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.isHidden = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var instrutionCameraOnBoardingVideoContainer: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        return view
    }()
    
    public var instructionCameraOnBoardingProgressView: UIProgressView = {
        let progressView = UIProgressView(frame: .zero)
        progressView.translatesAutoresizingMaskIntoConstraints = false
        progressView.progressTintColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewProgressBarFillColor
        progressView.trackTintColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewProgressBackgroundColor
        return progressView
    }()
    
    public var idenfyUILabelinstructionDescriptionsTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTitleTextFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTitleTextColor
        return label
    }()
    
    public var instructionDescriptionsTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.bounces = false
        tableView.isScrollEnabled = false
        tableView.allowsSelection = false
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.backgroundColor = .clear
        return tableView
    }()
    
    public var idenfyLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_animation_nfc_screen_loading_indicator, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.applyColorTint(IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionLoadingSpinnerTintColor)
        return lottieView
    }()

    private var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.alwaysBounceVertical = false
        return scrollView
    }()

    private var scrollContentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupButtonActions()
        setupScrollView()
        setupTopTitle()
        if shouldInstructionsBePlayed {
            setupCenterVideoView()
        } else {
            setupCenterImageView()
        }
    }

    private func setupScrollView() {
        addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: idenfyUIEnabledButtonCameraOnBoardingContinue.topAnchor, constant: -16).isActive = true

        scrollView.addSubview(scrollContentView)
        scrollContentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        scrollContentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        scrollContentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        scrollContentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        scrollContentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }

    private func setupButtonActions() {
        idenfyUIEnabledButtonCameraOnBoardingContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }
    
    public func playInstructions(_ trustedPartner: Bool) -> InstructionVideo {
        let instructionVideo = InstructionVideo(frame: instrutionCameraOnBoardingVideoContainer.bounds)
        switch currentStep! {
        case Step.FACE:
            instructionVideo.configure("idenfy_instructions_face_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
        case Step.LIVENESS:
            instructionVideo.configure("idenfy_instructions_liveness_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
        default:
            switch trustedPartner {
            case true:
                instructionVideo.configure("idenfy_instructions_document_trusted_partner", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
            case false:
                instructionVideo.configure("idenfy_instructions_document_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
            }
        }
        instructionVideo.isLoop = true
        instructionVideo.play()
        instrutionCameraOnBoardingVideoContainer.addSubview(instructionVideo)
        return instructionVideo
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        scrollContentView.addSubview(idenfyUILabelCameraOnBoardingCommonInformationTitle)
        idenfyUILabelCameraOnBoardingCommonInformationTitle.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -16).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationTitle.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 16).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationTitle.topAnchor.constraint(equalTo: scrollContentView.topAnchor, constant: 24).isActive = true

        scrollContentView.addSubview(idenfyUILabelCameraOnBoardingCommonInformationDescription)
        idenfyUILabelCameraOnBoardingCommonInformationDescription.widthAnchor.constraint(equalTo: scrollContentView.widthAnchor, multiplier: 0.9).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationDescription.centerXAnchor.constraint(equalTo: scrollContentView.centerXAnchor).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupCenterVideoView() {
        scrollContentView.addSubview(instrutionCameraOnBoardingVideoContainer)
        instrutionCameraOnBoardingVideoContainer.centerXAnchor.constraint(equalTo: scrollContentView.centerXAnchor).isActive = true
        instrutionCameraOnBoardingVideoContainer.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationDescription.bottomAnchor, constant: 32).isActive = true
        instrutionCameraOnBoardingVideoContainer.leadingAnchor.constraint(greaterThanOrEqualTo: scrollContentView.leadingAnchor, constant: 16).isActive = true
        instrutionCameraOnBoardingVideoContainer.trailingAnchor.constraint(lessThanOrEqualTo: scrollContentView.trailingAnchor, constant: -16).isActive = true
        let widthConstraint = instrutionCameraOnBoardingVideoContainer.widthAnchor.constraint(equalToConstant: 500)
        widthConstraint.priority = .defaultHigh
        widthConstraint.isActive = true
        instrutionCameraOnBoardingVideoContainer.heightAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.widthAnchor, multiplier: 0.6).isActive = true
        
        scrollContentView.addSubview(idenfyLoadingSpinner)
        idenfyLoadingSpinner.centerXAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.centerXAnchor).isActive = true
        idenfyLoadingSpinner.centerYAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.centerYAnchor).isActive = true
        idenfyLoadingSpinner.heightAnchor.constraint(equalToConstant: 130).isActive = true
        idenfyLoadingSpinner.widthAnchor.constraint(equalToConstant: 130).isActive = true

        scrollContentView.bringSubviewToFront(instrutionCameraOnBoardingVideoContainer)

        scrollContentView.addSubview(instructionCameraOnBoardingProgressView)
        instructionCameraOnBoardingProgressView.topAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.bottomAnchor, constant: 16).isActive = true
        instructionCameraOnBoardingProgressView.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 16).isActive = true
        instructionCameraOnBoardingProgressView.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -16).isActive = true
        instructionCameraOnBoardingProgressView.heightAnchor.constraint(equalToConstant: 5).isActive = true

        scrollContentView.addSubview(idenfyUILabelinstructionDescriptionsTitle)
        idenfyUILabelinstructionDescriptionsTitle.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 16).isActive = true
        idenfyUILabelinstructionDescriptionsTitle.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -32).isActive = true
        idenfyUILabelinstructionDescriptionsTitle.topAnchor.constraint(equalTo: instructionCameraOnBoardingProgressView.bottomAnchor, constant: 16).isActive = true

        scrollContentView.addSubview(instructionDescriptionsTableView)
        instructionDescriptionsTableView.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 24).isActive = true
        instructionDescriptionsTableView.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -32).isActive = true
        instructionDescriptionsTableView.topAnchor.constraint(equalTo: idenfyUILabelinstructionDescriptionsTitle.bottomAnchor, constant: 16).isActive = true
        instructionDescriptionsTableView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100).isActive = true
        instructionDescriptionsTableView.bottomAnchor.constraint(equalTo: scrollContentView.bottomAnchor, constant: -16).isActive = true
    }

    open func setupCenterImageView() {
        scrollContentView.addSubview(idenfyUIImageViewCameraOnBoardingCommonInformationIcon)
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationDescription.bottomAnchor, constant: 32).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.centerXAnchor.constraint(equalTo: scrollContentView.centerXAnchor).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.heightAnchor.constraint(equalToConstant: 170).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.bottomAnchor.constraint(equalTo: scrollContentView.bottomAnchor, constant: -16).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIEnabledButtonCameraOnBoardingContinue)
        idenfyUIEnabledButtonCameraOnBoardingContinue.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(idenfyUIDisabledButtonCameraOnBoardingContinue)
        idenfyUIDisabledButtonCameraOnBoardingContinue.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIEnabledButtonCameraOnBoardingContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

public protocol InstructionDescriptionsCellViewableV2: UITableViewCell {
    var cellView: UIView { get }
    var instructionDescriptionsLabel: UILabel { get }
    var instructionDescriptionsCircle: UIImageView { get }
}

@objc open class InstructionDescriptionsCellV2: UITableViewCell, InstructionDescriptionsCellViewableV2 {
    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var instructionDescriptionsLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTableViewCellTextFont
        label.text = "Step"
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsTableViewCellTextColor
        return label
    }()

    public var instructionDescriptionsCircle: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.isOpaque = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_confirmation_item_step_circle).withRenderingMode(.alwaysTemplate)
        imageView.setImageColor(IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingInstructionDetailsCellCircleTintColor)
        return imageView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    open func setupView() {
        addSubview(cellView)
        cellView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        cellView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true

        cellView.addSubview(instructionDescriptionsCircle)
        instructionDescriptionsCircle.heightAnchor.constraint(equalToConstant: 8).isActive = true
        instructionDescriptionsCircle.widthAnchor.constraint(equalTo: instructionDescriptionsCircle.heightAnchor, multiplier: 1).isActive = true
        instructionDescriptionsCircle.centerYAnchor.constraint(equalTo: cellView.centerYAnchor).isActive = true
        instructionDescriptionsCircle.leadingAnchor.constraint(equalTo: cellView.safeLeftAnchor).isActive = true

        cellView.addSubview(instructionDescriptionsLabel)
        instructionDescriptionsLabel.topAnchor.constraint(equalTo: cellView.topAnchor, constant: 4).isActive = true
        instructionDescriptionsLabel.bottomAnchor.constraint(equalTo: cellView.bottomAnchor, constant: -4).isActive = true
        instructionDescriptionsLabel.leadingAnchor.constraint(equalTo: instructionDescriptionsCircle.trailingAnchor, constant: 16).isActive = true
        instructionDescriptionsLabel.trailingAnchor.constraint(equalTo: cellView.trailingAnchor).isActive = true
    }
}
