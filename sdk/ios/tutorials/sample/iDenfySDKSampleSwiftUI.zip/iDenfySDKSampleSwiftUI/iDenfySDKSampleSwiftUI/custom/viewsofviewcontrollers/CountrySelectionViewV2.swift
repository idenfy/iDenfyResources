//
//  CountrySelectionViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class CountrySelectionViewV2: UIView, CountrySelectionViewableV2 {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var countrySelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewTitleTextColor
        return label
    }()

    public var countrySelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewDescriptionTextColor
        return label
    }()

    public var searchIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarSearchIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_country_selection_search", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()

    public var countrySearchBarLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.backgroundColor = .clear
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarHintTextColor
        label.font = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewSearchBarHintFont
        return label
    }()

    public var countrySearchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        searchBar.setImage(UIImage(), for: .search, state: .normal)
        searchBar.setPositionAdjustment(UIOffset(horizontal: -10, vertical: 0), for: .search)
        searchBar.barTintColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarBackgroundColor
        searchBar.backgroundColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarBackgroundColor
        searchBar.backgroundImage = UIImage()
        searchBar.layer.cornerRadius = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarCorderRadius
        searchBar.layer.borderWidth = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarBorderWidth
        searchBar.layer.borderColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarBorderColor.cgColor
        let textField = searchBar.searchTextField
        textField.backgroundColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarBackgroundColor
        textField.textColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountrySearchBarTextColor
        textField.borderStyle = .none
        textField.clearButtonMode = .never
        textField.font = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewSearchBarFont
        if #available(iOS 26.0, *) {
            textField.layer.cornerRadius = 0
            textField.layer.borderWidth = 0
            textField.layer.masksToBounds = true
        }
        return searchBar
    }()

    public var searchBarMask: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .clear
        return view
    }()

    public var countryTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.isHidden = true
        tableView.bounces = false
        tableView.isScrollEnabled = true
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.backgroundColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewBackgroundColor
        tableView.showsVerticalScrollIndicator = false
        tableView.layer.cornerRadius = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewCornerRadius
        tableView.layer.borderWidth = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewBorderWidth
        tableView.layer.borderColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewBorderColor.cgColor
        return tableView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupSearchBar()
        setupCountryTableView()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(countrySelectionTitle)
        countrySelectionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        countrySelectionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        countrySelectionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(countrySelectionDescription)
        countrySelectionDescription.widthAnchor.constraint(equalTo: countrySelectionTitle.widthAnchor, multiplier: 0.8).isActive = true
        countrySelectionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        countrySelectionDescription.topAnchor.constraint(equalTo: countrySelectionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupSearchBar() {
        addSubview(countrySearchBar)
        countrySearchBar.topAnchor.constraint(equalTo: countrySelectionDescription.bottomAnchor, constant: 48).isActive = true
        countrySearchBar.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        countrySearchBar.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        countrySearchBar.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        countrySearchBar.heightAnchor.constraint(equalToConstant: 56).isActive = true

        addSubview(searchIcon)
        searchIcon.centerYAnchor.constraint(equalTo: countrySearchBar.centerYAnchor).isActive = true
        searchIcon.trailingAnchor.constraint(equalTo: countrySearchBar.trailingAnchor, constant: -16).isActive = true
        searchIcon.heightAnchor.constraint(equalToConstant: 17).isActive = true
        searchIcon.widthAnchor.constraint(equalTo: searchIcon.heightAnchor, multiplier: 1).isActive = true

        addSubview(countrySearchBarLabel)
        countrySearchBarLabel.leadingAnchor.constraint(equalTo: countrySearchBar.leadingAnchor, constant: 16).isActive = true
        countrySearchBarLabel.trailingAnchor.constraint(equalTo: countrySearchBar.trailingAnchor).isActive = true
        countrySearchBarLabel.topAnchor.constraint(equalTo: countrySearchBar.topAnchor).isActive = true
        countrySearchBarLabel.bottomAnchor.constraint(equalTo: countrySearchBar.bottomAnchor).isActive = true

        addSubview(searchBarMask)
        searchBarMask.leadingAnchor.constraint(equalTo: countrySearchBar.safeLeftAnchor).isActive = true
        searchBarMask.trailingAnchor.constraint(equalTo: countrySearchBar.safeRightAnchor).isActive = true
        searchBarMask.topAnchor.constraint(equalTo: countrySearchBar.safeTopAnchor).isActive = true
        searchBarMask.bottomAnchor.constraint(equalTo: countrySearchBar.safeBottomAnchor).isActive = true
    }

    open func setupCountryTableView() {
        addSubview(countryTableView)
        countryTableView.topAnchor.constraint(equalTo: countrySearchBar.bottomAnchor, constant: 24).isActive = true
        countryTableView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        countryTableView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        countryTableView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        countryTableView.widthAnchor.constraint(equalTo: countrySearchBar.widthAnchor).isActive = true
        countryTableView.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -16).isActive = true
    }
}

@objc open class CountryCell: UITableViewCell, CountryCellViewable {
    public var hasBorder = false

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var countryLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewCellFont
        label.text = "country"
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewCellTextColor
        return label
    }()

    public var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    public var countryImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.isOpaque = true
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryFlagBorderWidth
        imageView.layer.borderColor = UIColor.black.cgColor
        return imageView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        addSubview(cellView)
        cellView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        cellView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        cellView.addSubview(countryImageView)
        countryImageView.trailingAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        countryImageView.topAnchor.constraint(equalTo: cellView.safeTopAnchor).isActive = true
        countryImageView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        countryImageView.centerYAnchor.constraint(equalTo: cellView.centerYAnchor).isActive = true

        cellView.addSubview(loadingSpinner)
        loadingSpinner.topAnchor.constraint(equalTo: cellView.safeTopAnchor).isActive = true
        loadingSpinner.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        loadingSpinner.trailingAnchor.constraint(equalTo: countryImageView.leadingAnchor, constant: -8).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true

        cellView.addSubview(countryLabel)
        countryLabel.leadingAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        countryLabel.trailingAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -(frame.width * 0.3)).isActive = true
        countryLabel.topAnchor.constraint(equalTo: cellView.safeTopAnchor).isActive = true
        countryLabel.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        countryLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor).isActive = true
    }
}
