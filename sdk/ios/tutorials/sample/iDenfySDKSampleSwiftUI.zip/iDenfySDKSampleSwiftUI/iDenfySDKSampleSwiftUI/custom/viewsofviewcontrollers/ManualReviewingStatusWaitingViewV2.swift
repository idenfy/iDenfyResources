//
//  ManualReviewingViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-07-02.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol ManualReviewingStatusWaitingViewButtonActionsDelegate: AnyObject {
    func stopWaitingButtonPressedAction()
}

public protocol ManualReviewingStatusWaitingViewableV2: UIView {
    var delegate: ManualReviewingStatusWaitingViewButtonActionsDelegate? { get set }
    var idenfyToolbarV2Common: IdenfyToolbarV2WithLanguageSelection { get }
    var idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle: UILabel { get }
    var idenfyManualReviewingStatusWaitingManualReviewCompletedTitle: UILabel { get }
    var idenfyManualReviewingStatusWaitingManualReviewLoadingSpinner: LottieAnimationView { get }
    var idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle: UILabel { get }
    var idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription: UILabel { get }
    var idenfyUILabelViewManualReviewingStatusWaitingTimerTitle: UILabel { get }
    var idenfyViewHolderManualResultsWaitingViewManualReviewCompleted: UIView { get }
    var idenfyManualReviewingStatusWaitingCommonInformationDescription: UILabel { get }
    var idenfyManualReviewingStatusWaitingManualReviewCompletedTick: UIImageView { get }
    var idenfyUIButtonManualReviewingStatusWaitingStopWaiting: UIButton { get }
    var scrollView: UIScrollView { get }
    
    func applyGradients()
}

@objc open class ManualReviewingStatusWaitingViewV2: UIView, ManualReviewingStatusWaitingViewableV2 {
    open weak var delegate: ManualReviewingStatusWaitingViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        toolbar.backButton.isHidden = true
        return toolbar
    }()

    public var scrollView: UIScrollView = {
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.isUserInteractionEnabled = true
        scroll.bounces = false
        return scroll
    }()

    public var scrollViewContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationTopDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationTopDescriptionTextColor
        return label
    }()

    public var idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderCompletedBackgroundColor
        view.layer.shadowColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderShadowColor.cgColor
        view.layer.shadowOpacity = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderShadowOpacity
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderShadowRadius
        return view
    }()

    public var idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCompletedStepFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCompletedStepTitleColor
        return label
    }()

    public var idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTick: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCompletedStepTitleColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_language_selection_language_selected_tick).withRenderingMode(.alwaysTemplate)
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    public var idenfyManualReviewingStatusWaitingTimerImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.contentMode = .scaleAspectFit
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_manual_reviewing_timer_v2).withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
        imageView.layer.masksToBounds = true
        return imageView
    }()

    public var idenfyViewHolderManualResultsWaitingViewManualReviewCompleted: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderBackgroundColor
        view.layer.shadowColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderShadowColor.cgColor
        view.layer.shadowOpacity = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderShadowOpacity
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepViewHolderShadowRadius
        return view
    }()

    public var idenfyManualReviewingStatusWaitingManualReviewCompletedTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStepTitleColor
        return label
    }()
    
    public var idenfyManualReviewingStatusWaitingManualReviewLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_animation_manual_review_loading_spinner, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = false
        return lottieView
    }()

    public var idenfyManualReviewingStatusWaitingManualReviewCompletedTick: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.contentMode = .scaleAspectFit
        imageView.isHidden = true
        imageView.tintColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCompletedStepTitleColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_language_selection_language_selected_tick).withRenderingMode(.alwaysTemplate)
        imageView.layer.masksToBounds = true
        return imageView
    }()

    public var idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationTitleTextColor
        return label
    }()

    public var idenfyManualReviewingStatusWaitingCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewManualReviewingStatusWaitingCommonInformationViewHolder: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var idenfyUILabelViewManualReviewingStatusWaitingTimerTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCommonInformationTimerFont
        label.textAlignment = .center
        label.textColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingTimerTitleTextColor
        return label
    }()
    
    public var idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder: UIView = {
        let button = UIView(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        return button
    }()

    public var idenfyUIButtonManualReviewingStatusWaitingStopWaiting: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStopWaitingButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc public func setupConstraints() {
        backgroundColor = IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingViewBackgroundColor
        setupToolbar()
        setupStopWaitingIdentificationButton()
        setupClockImageView()
        setupDescription()
        setupScrollView()
        setupTopTitle()
        setupCompletedSteps()
        setupButtonActions()
    }

    private func setupButtonActions() {
        idenfyUIButtonManualReviewingStatusWaitingStopWaiting.addTarget(self, action: #selector(stopWaitingIdentificationButtonPressed), for: .touchUpInside)
    }

    @objc func stopWaitingIdentificationButtonPressed() {
        delegate?.stopWaitingButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupScrollView() {
        addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: idenfyToolbarV2Common.safeBottomAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: idenfyManualReviewingStatusWaitingCommonInformationDescription.safeTopAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        
        scrollView.addSubview(scrollViewContentView)
        scrollViewContentView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor).isActive = true
        scrollViewContentView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor).isActive = true
        scrollViewContentView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor).isActive = true
        scrollViewContentView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor).isActive = true
        scrollViewContentView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor).isActive = true

        let height = scrollViewContentView.heightAnchor.constraint(equalTo: scrollView.frameLayoutGuide.heightAnchor)
        height.priority = UILayoutPriority(rawValue: 10)
        height.isActive = true
    }

    open func setupCompletedSteps() {
        scrollViewContentView.addSubview(idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted)
        idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.trailingAnchor.constraint(equalTo: scrollViewContentView.safeRightAnchor, constant: -24).isActive = true
        idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.leadingAnchor.constraint(equalTo: scrollViewContentView.safeLeftAnchor, constant: 24).isActive = true
        idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.topAnchor.constraint(equalTo: idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription.safeBottomAnchor, constant: 24).isActive = true
        idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.heightAnchor.constraint(equalToConstant: 55).isActive = true
        
        idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.addSubview(idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTick)
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTick.trailingAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.safeRightAnchor, constant: -16).isActive = true
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTick.topAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.safeTopAnchor).isActive = true
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTick.bottomAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.safeBottomAnchor).isActive = true
        
        idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.addSubview(idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle)
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle.leadingAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.safeLeftAnchor, constant: 16).isActive = true
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle.topAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.safeTopAnchor).isActive = true
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle.bottomAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.safeBottomAnchor).isActive = true
        idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTitle.trailingAnchor.constraint(equalTo: idenfyManualReviewingStatusWaitingAutomatedReviewCompletedTick.leadingAnchor, constant: -16).isActive = true
        
        scrollViewContentView.addSubview(idenfyViewHolderManualResultsWaitingViewManualReviewCompleted)
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.trailingAnchor.constraint(equalTo: scrollViewContentView.safeRightAnchor, constant: -24).isActive = true
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.leadingAnchor.constraint(equalTo: scrollViewContentView.safeLeftAnchor, constant: 24).isActive = true
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.topAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewAutomatedReviewCompleted.bottomAnchor, constant: 4).isActive = true
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.heightAnchor.constraint(equalToConstant: 55).isActive = true
        
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.addSubview(idenfyManualReviewingStatusWaitingManualReviewLoadingSpinner)
        idenfyManualReviewingStatusWaitingManualReviewLoadingSpinner.trailingAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.trailingAnchor, constant: -10).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewLoadingSpinner.topAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeTopAnchor).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewLoadingSpinner.bottomAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeBottomAnchor).isActive = true
        
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.addSubview(idenfyManualReviewingStatusWaitingManualReviewCompletedTick)
        idenfyManualReviewingStatusWaitingManualReviewCompletedTick.trailingAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.trailingAnchor, constant: -16).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewCompletedTick.topAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeTopAnchor).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewCompletedTick.bottomAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeBottomAnchor).isActive = true
        
        idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.addSubview(idenfyManualReviewingStatusWaitingManualReviewCompletedTitle)
        idenfyManualReviewingStatusWaitingManualReviewCompletedTitle.leadingAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeLeftAnchor, constant: 16).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewCompletedTitle.topAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeTopAnchor).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewCompletedTitle.bottomAnchor.constraint(equalTo: idenfyViewHolderManualResultsWaitingViewManualReviewCompleted.safeBottomAnchor).isActive = true
        idenfyManualReviewingStatusWaitingManualReviewCompletedTitle.trailingAnchor.constraint(equalTo: idenfyManualReviewingStatusWaitingManualReviewCompletedTick.leadingAnchor, constant: -16).isActive = true
    }

    open func setupTopTitle() {
        scrollViewContentView.addSubview(idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle)
        idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle.trailingAnchor.constraint(equalTo: scrollViewContentView.safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle.leadingAnchor.constraint(equalTo: scrollViewContentView.safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle.topAnchor.constraint(equalTo: scrollViewContentView.safeTopAnchor, constant: 24).isActive = true
        
        scrollViewContentView.addSubview(idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription)
        idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription.trailingAnchor.constraint(equalTo: scrollViewContentView.safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription.leadingAnchor.constraint(equalTo: scrollViewContentView.safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelManualReviewingStatusWaitingCommonInformationTopDescription.topAnchor.constraint(equalTo: idenfyUILabelManualReviewingStatusWaitingCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupStopWaitingIdentificationButton() {
        addSubview(idenfyUIButtonManualReviewingStatusWaitingStopWaiting)
        idenfyUIButtonManualReviewingStatusWaitingStopWaiting.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIButtonManualReviewingStatusWaitingStopWaiting.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIButtonManualReviewingStatusWaitingStopWaiting.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIButtonManualReviewingStatusWaitingStopWaiting.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    open func setupClockImageView() {
        addSubview(idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder)
        idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.bottomAnchor.constraint(equalTo: idenfyUIButtonManualReviewingStatusWaitingStopWaiting.topAnchor, constant: -8).isActive = true
        idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.addSubview(idenfyUILabelViewManualReviewingStatusWaitingTimerTitle)
        idenfyUILabelViewManualReviewingStatusWaitingTimerTitle.centerXAnchor.constraint(equalTo: idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.centerXAnchor).isActive = true
        idenfyUILabelViewManualReviewingStatusWaitingTimerTitle.centerYAnchor.constraint(equalTo: idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.centerYAnchor).isActive = true
        
        idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.addSubview(idenfyManualReviewingStatusWaitingTimerImage)
        idenfyManualReviewingStatusWaitingTimerImage.centerYAnchor.constraint(equalTo: idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.centerYAnchor).isActive = true
        idenfyManualReviewingStatusWaitingTimerImage.trailingAnchor.constraint(equalTo: idenfyUILabelViewManualReviewingStatusWaitingTimerTitle.leadingAnchor, constant: -8).isActive = true
    }

    open func setupDescription() {
        addSubview(idenfyManualReviewingStatusWaitingCommonInformationDescription)
        idenfyManualReviewingStatusWaitingCommonInformationDescription.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyManualReviewingStatusWaitingCommonInformationDescription.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyManualReviewingStatusWaitingCommonInformationDescription.bottomAnchor.constraint(equalTo: idenfyUIImageViewManualReviewingStatusWaitingTimerViewHolder.topAnchor, constant: -8).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIButtonManualReviewingStatusWaitingStopWaiting.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
