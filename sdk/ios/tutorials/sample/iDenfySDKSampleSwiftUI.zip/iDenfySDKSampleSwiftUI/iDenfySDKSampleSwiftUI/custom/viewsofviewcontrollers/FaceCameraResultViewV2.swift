//
//  FaceCameraResultViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class FaceCameraResultViewV2: UIView, CameraResultViewableV2 {
    open weak var delegate: FileResultViewV2ButtonActionsDelegate?

    override public required init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var photoResultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewTitleColor
        return label
    }()

    public var poweredByIdenfyCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white
        view.layer.cornerRadius = CGFloat(4)
        view.layer.borderWidth = CGFloat(1)
        view.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.1).cgColor
        view.isHidden = true
        return view
    }()

    public var poweredByIdenfyTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPoweredByIdenfyTitleColor
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPoweredByIdenfyTitleFont
        return label
    }()

    public var photoResultDetailsCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardSecond: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardQuestionMark: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return imageView
    }()

    public var photoResultDetailsCardQuestionMarkSecond: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return imageView
    }()

    public var photoResultDetailsCardTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public var photoResultDetailsCardTitleSecond: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public var fileResultImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPhotoCornerRadius
        return imageView
    }()
    
    public var photoResultDetailsSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_animation_photo_result_loading_indicator", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.alpha = 0.6
        lottieView.isHidden = true
        return lottieView
    }()

    public var continueButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var chooseAnotherFileButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonBackgroundColor
        button.titleLabel?.textAlignment = .center
        button.layer.masksToBounds = true
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.borderWidth = IdenfyButtonsUISettingsV2.idenfyChooseAnotherPhotoButtonCornerRadius
        button.layer.borderColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonBorderColor.cgColor
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewBackgroundColor
        setupToolbar()
        setupButtons()
        setupSpinner()
        setupButtonActions()
        setupFaceDetailCard()
        setupFaceTitle()
        setupFaceImageView()
        setupPoweredByIdenfyCard()
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(confirmPhotoButtonPressed), for: .touchUpInside)
        chooseAnotherFileButton.addTarget(self, action: #selector(retakePhotoButtonPressed), for: .touchUpInside)
    }

    @objc func confirmPhotoButtonPressed() {
        delegate?.confirmButtonPressedAction()
    }

    @objc func retakePhotoButtonPressed() {
        delegate?.retakeButtonPressedAction()
    }
    
    private func setupSpinner() {
        addSubview(photoResultDetailsSpinner)
        photoResultDetailsSpinner.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -24).isActive = true
        photoResultDetailsSpinner.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        photoResultDetailsSpinner.heightAnchor.constraint(equalToConstant: 150).isActive = true
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupButtons() {
        addSubview(chooseAnotherFileButton)
        chooseAnotherFileButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        chooseAnotherFileButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButton)
        continueButton.bottomAnchor.constraint(equalTo: chooseAnotherFileButton.topAnchor, constant: -16).isActive = true
        continueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        continueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    private func setupFaceDetailCard() {
        addSubview(photoResultDetailsCard)
        photoResultDetailsCard.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        photoResultDetailsCard.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        photoResultDetailsCard.bottomAnchor.constraint(equalTo: continueButton.safeTopAnchor, constant: -24).isActive = true
        photoResultDetailsCard.heightAnchor.constraint(equalToConstant: 50).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardQuestionMark)
        photoResultDetailsCardQuestionMark.leftAnchor.constraint(equalTo: photoResultDetailsCard.safeLeftAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMark.topAnchor.constraint(equalTo: photoResultDetailsCard.safeTopAnchor).isActive = true
        photoResultDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: photoResultDetailsCard.safeBottomAnchor).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardTitle)
        photoResultDetailsCardTitle.leftAnchor.constraint(equalTo: photoResultDetailsCard.safeLeftAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitle.rightAnchor.constraint(equalTo: photoResultDetailsCard.safeRightAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitle.topAnchor.constraint(equalTo: photoResultDetailsCard.safeTopAnchor).isActive = true
        photoResultDetailsCardTitle.bottomAnchor.constraint(equalTo: photoResultDetailsCard.safeBottomAnchor).isActive = true
    }

    private func setupFaceTitle() {
        addSubview(photoResultTitle)
        photoResultTitle.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        photoResultTitle.bottomAnchor.constraint(equalTo: photoResultDetailsCard.safeTopAnchor, constant: -12).isActive = true
    }

    private func setupFaceImageView() {
        addSubview(fileResultImageView)
        let topConstraint = fileResultImageView.topAnchor.constraint(equalTo: toolbar.topAnchor, constant: 54)
        topConstraint.isActive = true
        let bottomConstraint = fileResultImageView.bottomAnchor.constraint(equalTo: photoResultTitle.topAnchor, constant: -12)
        bottomConstraint.isActive = true
        fileResultImageView.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
        fileResultImageView.rightAnchor.constraint(equalTo: rightAnchor, constant: -16).isActive = true
        fileResultImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
    }

    private func setupPoweredByIdenfyCard() {
        addSubview(poweredByIdenfyCard)
        poweredByIdenfyCard.topAnchor.constraint(equalTo: fileResultImageView.topAnchor, constant: -15).isActive = true
        poweredByIdenfyCard.heightAnchor.constraint(equalToConstant: 30).isActive = true
        poweredByIdenfyCard.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true

        poweredByIdenfyCard.addSubview(poweredByIdenfyTitle)
        poweredByIdenfyTitle.leftAnchor.constraint(equalTo: poweredByIdenfyCard.safeLeftAnchor, constant: 16).isActive = true
        poweredByIdenfyTitle.rightAnchor.constraint(equalTo: poweredByIdenfyCard.safeRightAnchor, constant: -16).isActive = true
        poweredByIdenfyTitle.topAnchor.constraint(equalTo: poweredByIdenfyCard.safeTopAnchor, constant: 8).isActive = true
        poweredByIdenfyTitle.bottomAnchor.constraint(equalTo: poweredByIdenfyCard.safeBottomAnchor, constant: -8).isActive = true
    }
    
    open func applyGradients() {
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
