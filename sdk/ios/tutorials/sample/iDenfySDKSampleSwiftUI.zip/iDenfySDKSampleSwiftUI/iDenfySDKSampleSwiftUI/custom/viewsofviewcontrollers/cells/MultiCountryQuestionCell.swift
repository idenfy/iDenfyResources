//
//  MultiCountryQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 01/04/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class MultiCountryQuestionCell: UITableViewCell, MultiCountryQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var countryContainerView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBackgroundColor
        view.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldCornerRadius
        view.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderWidth
        view.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderColor.cgColor
        return view
    }()

    public var countryPlaceHolder: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCountryLabelFont
        label.textAlignment = .left
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCountryPlaceholderTextColor
        return label
    }()
    
    public var countryStackView: UIStackView = {
        let stack = UIStackView(frame: .zero)
        stack.axis = .vertical
        stack.distribution = .fill
        stack.spacing = 8
        stack.alignment = UIStackView.Alignment.fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    public var countryContentStackView: UIStackView = {
        let stack = UIStackView(frame: .zero)
        stack.axis = .horizontal
        stack.distribution = .equalSpacing
        stack.spacing = 16
        stack.alignment = UIStackView.Alignment.center
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    public var countryUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCountryLabelFont
        label.textAlignment = .left
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCountryLabelTextColor
        return label
    }()
    
    public var countryCancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewCancelIconTintColor
        button.isUserInteractionEnabled = true
        return button
    }()
    
    public var arrowIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyCountryQuestionCellViewArrowIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(countryContainerView)
        countryContainerView.leftAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        countryContainerView.rightAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        countryContainerView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        countryContainerView.heightAnchor.constraint(greaterThanOrEqualToConstant: 50).isActive = true
        countryContainerView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        
        countryContainerView.addSubview(arrowIcon)
        arrowIcon.heightAnchor.constraint(equalToConstant: 25).isActive = true
        arrowIcon.widthAnchor.constraint(equalToConstant: 25).isActive = true
        arrowIcon.rightAnchor.constraint(equalTo: countryContainerView.rightAnchor, constant: -16).isActive = true
        arrowIcon.centerYAnchor.constraint(equalTo: countryContainerView.centerYAnchor).isActive = true
        
        countryContainerView.addSubview(countryPlaceHolder)
        countryPlaceHolder.centerYAnchor.constraint(equalTo: arrowIcon.centerYAnchor).isActive = true
        countryPlaceHolder.leftAnchor.constraint(equalTo: countryContainerView.leftAnchor, constant: 16).isActive = true
        countryPlaceHolder.rightAnchor.constraint(equalTo: countryContainerView.rightAnchor, constant: -16).isActive = true
        
        countryContainerView.addSubview(countryStackView)
        countryStackView.leftAnchor.constraint(equalTo: countryContainerView.leftAnchor, constant: 16).isActive = true
        countryStackView.rightAnchor.constraint(equalTo: arrowIcon.leftAnchor, constant: -16).isActive = true
        countryStackView.topAnchor.constraint(equalTo: countryContainerView.topAnchor, constant: 16).isActive = true
        countryStackView.bottomAnchor.constraint(equalTo: countryContainerView.bottomAnchor, constant: -16).isActive = true
        
        countryContentStackView.addArrangedSubview(countryCancelButton)
        countryContentStackView.addArrangedSubview(countryUILabel)
    }
}
