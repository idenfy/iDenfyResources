//
//  EIDSessionMultipleInputViewV2.swift
//  testing
//
//  Created by iDenfy on 2026-05-20.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class EIDSessionMultipleInputViewV2: UIView, EIDSessionMultipleInputViewableV2 {
    open weak var delegate: EIDSessionMultipleInputViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var scrollView: UIScrollView = {
        let scrollView = UIScrollView(frame: .zero)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.keyboardDismissMode = .interactive
        return scrollView
    }()

    private var scrollContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var eidSessionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewTitleFont
        label.textAlignment = .center
        label.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewTitleTextColor
        return label
    }()

    public var eidSessionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewDescriptionFont
        label.textAlignment = .center
        label.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewDescriptionTextColor
        return label
    }()

    public var givenNameInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldFont
        textField.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldTextColor
        textField.backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var middleNameInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldFont
        textField.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldTextColor
        textField.backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var familyNameInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldFont
        textField.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldTextColor
        textField.backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var suffixInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldFont
        textField.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldTextColor
        textField.backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var dateOfBirthInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldFont
        textField.textColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldTextColor
        textField.backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBackgroundColor
        textField.layer.cornerRadius = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldCornerRadius
        textField.layer.borderWidth = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderWidth
        textField.layer.borderColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(10)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    public var inputStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 16
        return stackView
    }()

    public var eidSessionContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var eidSessionContinueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = EIDSessionMultipleInputViewUISettingsV2.idenfyEIDSessionMultipleInputViewBackgroundColor
        setupToolbar()
        setupScrollView()
        setupTopTitle()
        setupInputFields()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        eidSessionContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupScrollView() {
        addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: toolbar.bottomAnchor).isActive = true

        scrollView.addSubview(scrollContentView)
        scrollContentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        scrollContentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        scrollContentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        scrollContentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        scrollContentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }

    open func setupTopTitle() {
        scrollContentView.addSubview(eidSessionTitle)
        eidSessionTitle.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -16).isActive = true
        eidSessionTitle.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 16).isActive = true
        eidSessionTitle.topAnchor.constraint(equalTo: scrollContentView.topAnchor, constant: 24).isActive = true

        scrollContentView.addSubview(eidSessionDescription)
        eidSessionDescription.widthAnchor.constraint(equalTo: scrollContentView.widthAnchor, multiplier: 0.8).isActive = true
        eidSessionDescription.centerXAnchor.constraint(equalTo: scrollContentView.centerXAnchor).isActive = true
        eidSessionDescription.topAnchor.constraint(equalTo: eidSessionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupInputFields() {
        givenNameInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        middleNameInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        familyNameInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        suffixInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        dateOfBirthInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true

        inputStackView.addArrangedSubview(givenNameInputView)
        inputStackView.addArrangedSubview(middleNameInputView)
        inputStackView.addArrangedSubview(familyNameInputView)
        inputStackView.addArrangedSubview(suffixInputView)
        inputStackView.addArrangedSubview(dateOfBirthInputView)

        scrollContentView.addSubview(inputStackView)
        inputStackView.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 32).isActive = true
        inputStackView.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -32).isActive = true
        inputStackView.topAnchor.constraint(equalTo: eidSessionDescription.bottomAnchor, constant: 24).isActive = true
        inputStackView.bottomAnchor.constraint(equalTo: scrollContentView.bottomAnchor, constant: -24).isActive = true
    }

    open func setupContinueButton() {
        addSubview(eidSessionContinueButton)
        eidSessionContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        scrollView.bottomAnchor.constraint(equalTo: eidSessionContinueButton.topAnchor, constant: -16).isActive = true

        addSubview(eidSessionContinueDisabledButton)
        eidSessionContinueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: eidSessionContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: eidSessionContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func applyGradients() {
        eidSessionContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
