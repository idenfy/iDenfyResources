//
//  BankCardCameraViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-09-28.
//  Copyright (c) 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie
import idenfycore

// swiftlint:disable all

public protocol BankCardCameraViewableV2: DocumentCameraViewableV2 {
    var webViewContainer: UIView { get }
    var loadingSpinner: LottieAnimationView { get }
}

@objc open class BankCardCameraViewV2: DocumentCameraViewV2, BankCardCameraViewableV2 {

    public var webViewContainer: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.clipsToBounds = true
        return view
    }()

    public var loadingSpinner: LottieAnimationView = {
        let spinner = LottieAnimationView()
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.loopMode = .loop
        spinner.contentMode = .scaleAspectFit
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            spinner.animation = LottieAnimation.filepath(path)
        }
        spinner.play()
        return spinner
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupBankCardOverlay()
    }

    public required convenience init?(coder: NSCoder) {
        self.init(frame: .zero)
    }

    private func setupBankCardOverlay() {
        // Add webview container inside cameraView with 16:9 aspect ratio, centered
        cameraView.addSubview(webViewContainer)
        NSLayoutConstraint.activate([
            webViewContainer.leadingAnchor.constraint(equalTo: cameraView.leadingAnchor),
            webViewContainer.trailingAnchor.constraint(equalTo: cameraView.trailingAnchor),
            webViewContainer.centerYAnchor.constraint(equalTo: cameraView.centerYAnchor),
            webViewContainer.heightAnchor.constraint(equalTo: webViewContainer.widthAnchor, multiplier: 9.0 / 16.0),
        ])

        // Hide the darkened overlay (not needed for bank card)
        rectangleView.isHidden = true

        // Prepare rectangle path view (VC adds it on top of webview and configures margins)
        rectanglePathView.removeFromSuperview()
        rectanglePathView.translatesAutoresizingMaskIntoConstraints = false
        rectanglePathView.image = IdenfyViewUtils.getImage(rectanglePathView.imageAssetName)
        rectanglePathView.contentMode = .scaleToFill
        rectanglePathView.isHidden = false

        // Add loading spinner centered on webview with white tint
        loadingSpinner.applyColorTint(IdenfyBankCardCameraViewUISettingsV2.idenfyBankCardCameraViewLoadingSpinnerColor)
        cameraView.addSubview(loadingSpinner)
        NSLayoutConstraint.activate([
            loadingSpinner.centerXAnchor.constraint(equalTo: cameraView.safeAreaLayoutGuide.centerXAnchor),
            loadingSpinner.centerYAnchor.constraint(equalTo: webViewContainer.centerYAnchor),
            loadingSpinner.widthAnchor.constraint(equalToConstant: 40),
            loadingSpinner.heightAnchor.constraint(equalToConstant: 40),
        ])

        // Hide blur/glare alert cards (not needed for bank card)
        documentCameraAlertCard.isHidden = true
        documentCameraAcceptedDocumentsAlertCard.isHidden = true
    }
}
