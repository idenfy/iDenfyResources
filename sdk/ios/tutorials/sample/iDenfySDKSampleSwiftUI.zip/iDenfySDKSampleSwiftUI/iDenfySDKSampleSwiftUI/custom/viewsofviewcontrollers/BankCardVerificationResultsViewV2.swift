//
//  BankCardVerificationResultsViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-07-02.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit

public protocol BankCardVerificationResultsViewButtonActionsDelegate: AnyObject {
    func continueButtonPressedAction()
}

public protocol BankCardVerificationResultsViewableV2: UIView {
    var delegate: BankCardVerificationResultsViewButtonActionsDelegate? { get set }
    var idenfyToolbarV2Common: IdenfyToolbarV2Default { get }
    var resultTitle: UILabel { get }
    var resultDescription: UILabel { get }
    var resultIcon: UIImageView { get }
    var continueButton: UIButton { get }

    func applyGradients()
}

@objc open class BankCardVerificationResultsViewV2: UIView, BankCardVerificationResultsViewableV2 {
    public weak var delegate: BankCardVerificationResultsViewButtonActionsDelegate?

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var resultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyManualReviewingStatusFailedViewUISettingsV2.idenfyManualReviewingStatusFailedCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardVerificationResultsViewUISettingsV2.idenfyBankCardVerificationResultsViewTitleTextColor
        return label
    }()

    public var resultDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isUserInteractionEnabled = true
        label.font = IdenfyManualReviewingStatusFailedViewUISettingsV2.idenfyManualReviewingStatusFailedCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardVerificationResultsViewUISettingsV2.idenfyBankCardVerificationResultsViewDescriptionTextColor
        return label
    }()

    public var resultIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyBankCardVerificationResultsViewUISettingsV2.idenfyBankCardVerificationResultsViewButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyBankCardVerificationResultsViewUISettingsV2.idenfyBankCardVerificationResultsViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupCenterImageView()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(resultTitle)
        resultTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        resultTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        resultTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(resultDescription)
        resultDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        resultDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        resultDescription.topAnchor.constraint(equalTo: resultTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(resultIcon)
        resultIcon.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        resultIcon.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        resultIcon.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        resultIcon.topAnchor.constraint(equalTo: resultDescription.bottomAnchor, constant: 24).isActive = true
    }

    open func setupContinueButton() {
        addSubview(continueButton)
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    open func applyGradients() {
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
