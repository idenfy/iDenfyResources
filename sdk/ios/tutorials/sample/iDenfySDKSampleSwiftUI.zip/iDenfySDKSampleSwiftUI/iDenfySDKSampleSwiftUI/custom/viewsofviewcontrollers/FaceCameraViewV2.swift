//
//  FaceCameraViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc public class FaceCameraViewV2: UIView, FaceCameraViewableV2 {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    override public func layoutSubviews() {
        super.layoutSubviews()
    }

    public convenience init() {
        self.init(frame: CGRect.zero)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var cameraSessionsButtons: CameraSessionsButtonsViewableV2 = {
        let view = CameraSessionsButtonsViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        return view
    }()

    public var idenfyUIViewFaceOval: IdenfyFaceOvalV2 = {
        let view = IdenfyFaceOvalV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    public var idenfyUIViewFaceOvalV3: IdenfyFaceOvalV3? = {
        let view = IdenfyFaceOvalV3(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = false
        return view
    }()
    
    public var drawerContentView: DrawerContentViewableV2 = {
        let view = DrawerContentViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    open func setupConstraints() {
        setupCameraSessionsButtons()
        setupUIViewFaceOval()
        setupDrawerView()
    }
    
    func setupDrawerView() {
        addSubview(drawerContentView)
        drawerContentView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        drawerContentView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        drawerContentView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        drawerContentView.heightAnchor.constraint(equalToConstant: CameraSessionUIHelper.getDrawerHeight()).isActive = true
    }

    func setupCameraSessionsButtons() {
        addSubview(cameraSessionsButtons)
        cameraSessionsButtons.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        cameraSessionsButtons.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        cameraSessionsButtons.topAnchor.constraint(equalTo: topAnchor).isActive = true
        cameraSessionsButtons.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    func setupUIViewFaceOval() {
        guard let unwrappedIdenfyUIViewFaceOvalV3 = idenfyUIViewFaceOvalV3 else { return }
        addSubview(unwrappedIdenfyUIViewFaceOvalV3)
        unwrappedIdenfyUIViewFaceOvalV3.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        unwrappedIdenfyUIViewFaceOvalV3.bottomAnchor.constraint(equalTo: cameraSessionsButtons.idenfyUIViewContainerOfButtons.topAnchor).isActive = true
        let top = CameraSessionUIHelper.getDrawerHeight()
        unwrappedIdenfyUIViewFaceOvalV3.topAnchor.constraint(equalTo: topAnchor, constant: top).isActive = true
        unwrappedIdenfyUIViewFaceOvalV3.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        unwrappedIdenfyUIViewFaceOvalV3.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        unwrappedIdenfyUIViewFaceOvalV3.setNeedsDisplay()
    }
}
