//
//  IdentificationSuspectedResultsViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2022-02-21.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import UIKit

public protocol IdentificationSuspectedResultsViewButtonActionsDelegate: AnyObject {
    func continueButtonPressedAction()
}

public protocol IdentificationSuspectedResultsViewableV2: UIView {
    var delegate: IdentificationSuspectedResultsViewButtonActionsDelegate? { get set }
    var idenfyToolbarV2Common: IdenfyToolbarV2Default { get }
    var idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle: UILabel { get }
    var idenfyUIButtonIdentificationSuspectedResultsContinue: UIButton { get }
    var idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription: UILabel { get }
    
    func applyGradients()
}

@objc open class IdentificationSuspectedResultsViewV2: UIView, IdentificationSuspectedResultsViewableV2 {
    public weak var delegate: IdentificationSuspectedResultsViewButtonActionsDelegate?

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isUserInteractionEnabled = true
        label.font = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_identification_suspected)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyUIButtonIdentificationSuspectedResultsContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewContinueButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupCenterImageView()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        idenfyUIButtonIdentificationSuspectedResultsContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle)
        idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription)
        idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon)

        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.bottomAnchor, constant: 60).isActive = true
        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.widthAnchor.constraint(equalToConstant: 150).isActive = true
        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.heightAnchor.constraint(equalTo: idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.widthAnchor, multiplier: 1).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIButtonIdentificationSuspectedResultsContinue)
        idenfyUIButtonIdentificationSuspectedResultsContinue.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIButtonIdentificationSuspectedResultsContinue.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIButtonIdentificationSuspectedResultsContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIButtonIdentificationSuspectedResultsContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIButtonIdentificationSuspectedResultsContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
