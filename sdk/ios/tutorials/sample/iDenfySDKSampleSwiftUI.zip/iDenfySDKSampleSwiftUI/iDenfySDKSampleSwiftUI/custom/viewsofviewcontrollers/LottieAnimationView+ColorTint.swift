//
//  LottieAnimationView+ColorTint.swift
//  iDenfySDK
//
//  Created on 2026-02-06.
//  Copyright © 2026 Apple. All rights reserved.
//

import Foundation
import UIKit
import Lottie

extension LottieAnimationView {
    
    /// Applies a color tint to all fills and strokes in the Lottie animation
    /// - Parameter color: The UIColor to apply to the animation elements
    public func applyColorTint(_ color: UIColor) {
        let colorProvider = ColorValueProvider(color.lottieColorValue)
        
        // Apply to fills
        setValueProvider(colorProvider, keypath: AnimationKeypath(keys: ["**", "Fill 1", "Color"]))
        
        // Apply to strokes
        setValueProvider(colorProvider, keypath: AnimationKeypath(keys: ["**", "Stroke 1", "Color"]))
    }
}
