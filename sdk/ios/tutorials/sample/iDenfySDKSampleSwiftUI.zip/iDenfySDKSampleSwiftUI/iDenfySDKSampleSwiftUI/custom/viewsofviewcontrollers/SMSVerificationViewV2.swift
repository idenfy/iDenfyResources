//
//  SMSVerificationViewV2.swift
//  iDenfySDK
//
//  Created by Viktas Juskys on 2019-11-29.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit
import Lottie
import idenfycore

public protocol SMSVerificationViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
}

public protocol SMSVerificationViewableV2: UIView {
    var delegate: SMSVerificationViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var smsVerificationTitle: UILabel { get }
    var smsVerificationDescription: UILabel { get }
    
    // Phone input content
    var phoneInputContentView: UIView { get }
    var phoneInputInformationCard: UIView { get }
    var phoneInputInformationIcon: UIImageView { get }
    var phoneInputInformationTitle: UILabel { get }
    var phoneInputInformationDescription: UILabel { get }
    var phoneInputCountryImageView: UIImageView { get }
    var phoneInputView: UITextField { get }
    var errorMessage: UILabel { get }
    var phoneInputStatusInformationCard: UIView { get }
    var phoneInputStatusInformationTitle: UILabel { get }
    var phoneInputStatusInformationIcon: UIImageView { get }
    
    // SMS code input content
    var smsCodeInputStackView: UIStackView { get }
    var smsCodeInputTextField: PinCodeInputTextField { get }
    var smsCodeInputInformationCard: UIView { get }
    var smsCodeInputInformationTitle: UILabel { get }
    var smsCodeInputInformationIcon: UIImageView { get }
    var resendSMSCodeInformationTitle: UILabel { get }
    var changePhoneNumberInformationTitle: UILabel { get }
    
    var continueEnabledButton: UIButton { get }
    var continueDisabledButton: UIButton { get }
    var continueButtonSpinner: LottieAnimationView { get }
    
    func applyGradients()
}

@objc open class SMSVerificationViewV2: UIView, SMSVerificationViewableV2 {
    open weak var delegate: SMSVerificationViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var smsVerificationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewTitleTextColor
        return label
    }()

    public var smsVerificationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewDescriptionTextColor
        return label
    }()
    
    public var phoneInputContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    public var smsInputImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_sms_verification).withRenderingMode(.alwaysOriginal)
        return imageView
    }()
    
    public var phoneInputInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor
        return view
    }()
    
    public var phoneInputInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleTextColor
        return label
    }()
    
    public var phoneInputInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardIconTintColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_information_icon).withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var phoneInputInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionTextColor
        return label
    }()
    
    public var phoneInputCountryImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.isOpaque = true
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryFlagBorderWidth
        imageView.layer.borderColor = UIColor.black.cgColor
        return imageView
    }()
    
    public var phoneInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldFont
        textField.keyboardType = .phonePad
        textField.textContentType = .telephoneNumber
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(54)
        textField.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldTextColor
        textField.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBackgroundColor
        textField.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldCornerRadius
        textField.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderWidth
        textField.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.isUserInteractionEnabled = true
        return textField
    }()
    
    public var errorMessage: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageTextColor
        return label
    }()
    
    public var phoneInputStatusInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBackgroundColor
        return view
    }()
    
    public var phoneInputStatusInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor
        return label
    }()
    
    public var phoneInputStatusInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusIconTintColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_information_icon).withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var smsCodeInputStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    public var smsCodeInputTextField: PinCodeInputTextField = {
        let pinField = PinCodeInputTextField()
        pinField.translatesAutoresizingMaskIntoConstraints = false
        pinField.isOpaque = true
        pinField.underlineWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineWidth
        pinField.underlineHSpacing = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHSpacing
        pinField.underlineVMargin = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineVMargin
        pinField.fontSize = 32
        pinField.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldFont ?? UIFont.systemFont(ofSize: 32)
        pinField.underlineHeight = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHeight
        pinField.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldTextColor
        pinField.underlineColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUnderlineColor
        pinField.updatedUnderlineColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUpdatedUnderlineColor
        pinField.isUserInteractionEnabled = true
        pinField.isHidden = true
        return pinField
    }()
    
    public var smsCodeInputInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor
        return view
    }()
    
    public var smsCodeInputInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor
        return label
    }()
    
    public var smsCodeInputInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationIconTintColor
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_failed_checkmark).withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var resendSMSCodeInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleTextColor
        return label
    }()
    
    public var changePhoneNumberInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleTextColor
        return label
    }()
    
    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupSMSSelectionContentView()
        setupContinueButton()
        setupSMSCodeInputView()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(smsVerificationTitle)
        smsVerificationTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        smsVerificationTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        smsVerificationTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(smsVerificationDescription)
        smsVerificationDescription.widthAnchor.constraint(equalTo: smsVerificationTitle.widthAnchor, multiplier: 0.8).isActive = true
        smsVerificationDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        smsVerificationDescription.topAnchor.constraint(equalTo: smsVerificationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupSMSSelectionContentView() {
        addSubview(phoneInputContentView)
        phoneInputContentView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        phoneInputContentView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        phoneInputContentView.topAnchor.constraint(equalTo: smsVerificationDescription.bottomAnchor).isActive = true
        
        phoneInputContentView.addSubview(smsInputImageView)
        smsInputImageView.topAnchor.constraint(equalTo: phoneInputContentView.topAnchor, constant: 24).isActive = true
        smsInputImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        smsInputImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        smsInputImageView.centerXAnchor.constraint(equalTo: phoneInputContentView.centerXAnchor).isActive = true
        
        phoneInputContentView.addSubview(phoneInputInformationCard)
        phoneInputInformationCard.topAnchor.constraint(equalTo: smsInputImageView.bottomAnchor, constant: 24).isActive = true
        phoneInputInformationCard.leadingAnchor.constraint(equalTo: phoneInputContentView.leadingAnchor).isActive = true
        phoneInputInformationCard.trailingAnchor.constraint(equalTo: phoneInputContentView.trailingAnchor).isActive = true
        
        phoneInputInformationCard.addSubview(phoneInputInformationIcon)
        phoneInputInformationIcon.leadingAnchor.constraint(equalTo: phoneInputInformationCard.leadingAnchor, constant: 16).isActive = true
        phoneInputInformationIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true
        phoneInputInformationIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        phoneInputInformationIcon.topAnchor.constraint(equalTo: phoneInputInformationCard.topAnchor, constant: 12).isActive = true
        
        phoneInputInformationCard.addSubview(phoneInputInformationTitle)
        phoneInputInformationTitle.leadingAnchor.constraint(equalTo: phoneInputInformationIcon.trailingAnchor, constant: 8).isActive = true
        phoneInputInformationTitle.topAnchor.constraint(equalTo: phoneInputInformationIcon.topAnchor).isActive = true
        phoneInputInformationTitle.trailingAnchor.constraint(equalTo: phoneInputInformationCard.trailingAnchor, constant: -8).isActive = true
        
        phoneInputInformationCard.addSubview(phoneInputInformationDescription)
        phoneInputInformationDescription.topAnchor.constraint(equalTo: phoneInputInformationTitle.bottomAnchor, constant: 12).isActive = true
        phoneInputInformationDescription.leadingAnchor.constraint(equalTo: phoneInputInformationTitle.leadingAnchor).isActive = true
        phoneInputInformationDescription.trailingAnchor.constraint(equalTo: phoneInputInformationCard.trailingAnchor, constant: -16).isActive = true
        phoneInputInformationDescription.bottomAnchor.constraint(equalTo: phoneInputInformationCard.bottomAnchor, constant: -12).isActive = true
        
        phoneInputContentView.addSubview(phoneInputView)
        phoneInputView.leadingAnchor.constraint(equalTo: phoneInputContentView.leadingAnchor).isActive = true
        phoneInputView.trailingAnchor.constraint(equalTo: phoneInputContentView.trailingAnchor).isActive = true
        phoneInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        phoneInputView.topAnchor.constraint(equalTo: phoneInputInformationCard.bottomAnchor, constant: 16).isActive = true
        phoneInputView.bottomAnchor.constraint(equalTo: phoneInputContentView.bottomAnchor).isActive = true
        
        phoneInputContentView.addSubview(phoneInputCountryImageView)
        phoneInputCountryImageView.leadingAnchor.constraint(equalTo: phoneInputView.leadingAnchor, constant: 12).isActive = true
        phoneInputCountryImageView.centerYAnchor.constraint(equalTo: phoneInputView.centerYAnchor).isActive = true
        phoneInputCountryImageView.widthAnchor.constraint(equalToConstant: 35).isActive = true
        phoneInputCountryImageView.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        phoneInputContentView.addSubview(errorMessage)
        errorMessage.topAnchor.constraint(equalTo: phoneInputView.topAnchor, constant: 2).isActive = true
        errorMessage.leadingAnchor.constraint(equalTo: phoneInputCountryImageView.trailingAnchor, constant: 8).isActive = true
        errorMessage.trailingAnchor.constraint(equalTo: phoneInputView.safeRightAnchor).isActive = true
        
        addSubview(phoneInputStatusInformationCard)
        
        phoneInputStatusInformationCard.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        phoneInputStatusInformationCard.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        phoneInputStatusInformationCard.topAnchor.constraint(equalTo: phoneInputView.bottomAnchor, constant: 24).isActive = true
        
        phoneInputStatusInformationCard.addSubview(phoneInputStatusInformationIcon)
        phoneInputStatusInformationIcon.leadingAnchor.constraint(equalTo: phoneInputStatusInformationCard.leadingAnchor, constant: 16).isActive = true
        phoneInputStatusInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        phoneInputStatusInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        phoneInputStatusInformationIcon.centerYAnchor.constraint(equalTo: phoneInputStatusInformationCard.centerYAnchor).isActive = true
        
        phoneInputStatusInformationCard.addSubview(phoneInputStatusInformationTitle)
        phoneInputStatusInformationTitle.leadingAnchor.constraint(equalTo: phoneInputStatusInformationIcon.trailingAnchor, constant: 8).isActive = true
        phoneInputStatusInformationTitle.topAnchor.constraint(equalTo: phoneInputStatusInformationCard.topAnchor, constant: 12).isActive = true
        phoneInputStatusInformationTitle.bottomAnchor.constraint(equalTo: phoneInputStatusInformationCard.bottomAnchor, constant: -12).isActive = true
        phoneInputStatusInformationTitle.trailingAnchor.constraint(equalTo: phoneInputStatusInformationCard.trailingAnchor, constant: -16).isActive = true
    }
    
    open func setupSMSCodeInputView() {
        addSubview(smsCodeInputTextField)
        smsCodeInputTextField.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        smsCodeInputTextField.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        smsCodeInputTextField.topAnchor.constraint(equalTo: smsVerificationDescription.bottomAnchor, constant: 24).isActive = true
        smsCodeInputTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        let spacerView = UIView()
        spacerView.translatesAutoresizingMaskIntoConstraints = false
        spacerView.setContentHuggingPriority(.defaultLow, for: .vertical)
        
        let labelsContainer = UIView()
        labelsContainer.translatesAutoresizingMaskIntoConstraints = false
        labelsContainer.addSubview(resendSMSCodeInformationTitle)
        resendSMSCodeInformationTitle.leadingAnchor.constraint(equalTo: labelsContainer.leadingAnchor).isActive = true
        resendSMSCodeInformationTitle.trailingAnchor.constraint(equalTo: labelsContainer.trailingAnchor).isActive = true
        resendSMSCodeInformationTitle.topAnchor.constraint(equalTo: labelsContainer.topAnchor, constant: 24).isActive = true
        
        labelsContainer.addSubview(changePhoneNumberInformationTitle)
        changePhoneNumberInformationTitle.leadingAnchor.constraint(equalTo: labelsContainer.leadingAnchor).isActive = true
        changePhoneNumberInformationTitle.trailingAnchor.constraint(equalTo: labelsContainer.trailingAnchor).isActive = true
        changePhoneNumberInformationTitle.topAnchor.constraint(equalTo: resendSMSCodeInformationTitle.bottomAnchor, constant: 12).isActive = true
        changePhoneNumberInformationTitle.bottomAnchor.constraint(equalTo: labelsContainer.bottomAnchor).isActive = true
        
        smsCodeInputStackView.addArrangedSubview(smsCodeInputInformationCard)
        smsCodeInputStackView.addArrangedSubview(labelsContainer)
        smsCodeInputStackView.addArrangedSubview(spacerView)
        
        addSubview(smsCodeInputStackView)
        
        smsCodeInputStackView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        smsCodeInputStackView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        smsCodeInputStackView.topAnchor.constraint(equalTo: smsCodeInputTextField.bottomAnchor, constant: 24).isActive = true
        
        smsCodeInputInformationCard.addSubview(smsCodeInputInformationIcon)
        smsCodeInputInformationIcon.leadingAnchor.constraint(equalTo: smsCodeInputInformationCard.leadingAnchor, constant: 16).isActive = true
        smsCodeInputInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        smsCodeInputInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        smsCodeInputInformationIcon.centerYAnchor.constraint(equalTo: smsCodeInputInformationCard.centerYAnchor).isActive = true
        
        smsCodeInputInformationCard.addSubview(smsCodeInputInformationTitle)
        smsCodeInputInformationTitle.leadingAnchor.constraint(equalTo: smsCodeInputInformationIcon.trailingAnchor, constant: 8).isActive = true
        smsCodeInputInformationTitle.topAnchor.constraint(equalTo: smsCodeInputInformationCard.topAnchor, constant: 12).isActive = true
        smsCodeInputInformationTitle.bottomAnchor.constraint(equalTo: smsCodeInputInformationCard.bottomAnchor, constant: -12).isActive = true
        smsCodeInputInformationTitle.trailingAnchor.constraint(equalTo: smsCodeInputInformationCard.trailingAnchor, constant: -16).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueDisabledButton)
        continueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
