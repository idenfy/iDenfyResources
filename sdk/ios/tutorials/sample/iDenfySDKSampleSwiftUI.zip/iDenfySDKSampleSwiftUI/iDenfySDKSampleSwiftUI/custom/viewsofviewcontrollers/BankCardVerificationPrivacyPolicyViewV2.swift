//
//  BankCardVerificationPrivacyPolicyViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 04/11/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class BankCardVerificationPrivacyPolicyViewV2: UIView, BankCardVerificationPrivacyPolicyViewableV2 {
    open weak var delegate: BankCardVerificationPrivacyPolicyViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()

    public var contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var privacyPolicyTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCommonInformationTitleTextColor
        return label
    }()

    public var privacyPolicyDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCommonInformationDescriptionTextColor
        return label
    }()

    public var dataProtectionStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.backgroundColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardBackgroundColor
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.clipsToBounds = true
        stack.layer.cornerRadius = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardBorderRadius
        return stack
    }()

    public var dataProtectionContentView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 16
        stack.isLayoutMarginsRelativeArrangement = true
        stack.layoutMargins = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        stack.isHidden = false
        return stack
    }()

    public var item1Icon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_lock", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemIconColor
        return imageView
    }()

    public var item1Title: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()

    public var item2Icon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_access", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemIconColor
        return imageView
    }()

    public var item2Title: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()

    public var item3Icon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_block_share", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemIconColor
        return imageView
    }()

    public var item3Title: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()

    public var item4Icon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_security", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemIconColor
        return imageView
    }()

    public var item4Title: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()

    public var privacyPolicyText: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        uilabel.textAlignment = .center
        uilabel.isUserInteractionEnabled = true
        return uilabel
    }()

    public var privacyPolicyAgreeButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.loopMode = .loop
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyAgreeButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyBankCardVerificationPrivacyPolicyViewUISettingsV2.idenfyBankCardVerificationPrivacyPolicyViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupScrollView()
        setupCenterView()
        setupDataProtectionCard()
        setupPrivacyPolicyTexts()
        setupButtonActions()
    }

    private func setupButtonActions() {
        privacyPolicyAgreeButton.addTarget(self, action: #selector(agreeButtonPressed), for: .touchUpInside)
        privacyPolicyText.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(privacyPolicyTextViewPressed)))
    }

    @objc func privacyPolicyTextViewPressed() {
        delegate?.privacyPolicyTextViewPressed()
    }

    @objc func agreeButtonPressed() {
        delegate?.agreeButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupScrollView() {
        addSubview(scrollView)
        scrollView.topAnchor.constraint(equalTo: toolbar.bottomAnchor).isActive = true
        scrollView.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: privacyPolicyAgreeButton.topAnchor, constant: -8).isActive = true

        scrollView.addSubview(contentView)
        contentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }

    open func setupCenterView() {
        contentView.addSubview(privacyPolicyTitle)
        privacyPolicyTitle.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true
        privacyPolicyTitle.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        privacyPolicyTitle.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 24).isActive = true

        contentView.addSubview(privacyPolicyDescription)
        privacyPolicyDescription.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true
        privacyPolicyDescription.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        privacyPolicyDescription.topAnchor.constraint(equalTo: privacyPolicyTitle.bottomAnchor, constant: 24).isActive = true
    }

    open func setupDataProtectionCard() {
        contentView.addSubview(dataProtectionStackView)
        dataProtectionStackView.topAnchor.constraint(equalTo: privacyPolicyDescription.bottomAnchor, constant: 24).isActive = true
        dataProtectionStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        dataProtectionStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true
        
        dataProtectionStackView.addArrangedSubview(dataProtectionContentView)

        dataProtectionContentView.addArrangedSubview(createRow(icon: item1Icon, label: item1Title))
        dataProtectionContentView.addArrangedSubview(createRow(icon: item2Icon, label: item2Title))
        dataProtectionContentView.addArrangedSubview(createRow(icon: item3Icon, label: item3Title))
        dataProtectionContentView.addArrangedSubview(createRow(icon: item4Icon, label: item4Title))
    }

    private func setupPrivacyPolicyTexts() {
        contentView.addSubview(privacyPolicyText)
        privacyPolicyText.topAnchor.constraint(equalTo: dataProtectionStackView.bottomAnchor, constant: 24).isActive = true
        privacyPolicyText.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        privacyPolicyText.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true
        privacyPolicyText.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -24).isActive = true
    }

    open func setupContinueButton() {
        addSubview(privacyPolicyAgreeButton)
        privacyPolicyAgreeButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        privacyPolicyAgreeButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        privacyPolicyAgreeButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -16).isActive = true
        privacyPolicyAgreeButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(loadingSpinner)
        loadingSpinner.centerYAnchor.constraint(equalTo: privacyPolicyAgreeButton.centerYAnchor).isActive = true
        loadingSpinner.leadingAnchor.constraint(equalTo: privacyPolicyAgreeButton.safeLeftAnchor, constant: 16).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    private func createRow(icon: UIImageView, label: UILabel) -> UIStackView {
        let row = UIStackView(arrangedSubviews: [icon, label])
        row.axis = .horizontal
        row.spacing = 8
        row.alignment = .center
        icon.widthAnchor.constraint(equalToConstant: 22).isActive = true
        icon.heightAnchor.constraint(equalToConstant: 22).isActive = true
        return row
    }

    open func applyGradients() {
        privacyPolicyAgreeButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
