//
//  BankCardUploadReviewViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class BankCardUploadReviewViewV2: UIView, BankCardUploadReviewViewableV2 {
    open weak var delegate: BankCardUploadReviewViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var bankCardUploadReviewTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewTitleTextColor
        return label
    }()

    public var webViewContainer: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .clear
        view.clipsToBounds = true
        return view
    }()

    public var pdfFileIconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_camera_onboarding_other_document_image", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysOriginal)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var pdfFileNameLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewDescriptionTextColor
        return label
    }()

    private var pdfFallbackStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.isHidden = true
        return stack
    }()

    private func createQuestionCard() -> UIView {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewQuestionCardBackgroundColor
        view.layer.cornerRadius = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewQuestionCardCornerRadius
        return view
    }

    private func createQuestionIcon() -> UIImageView {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewQuestionCardIconColor
        return imageView
    }

    private func createQuestionLabel() -> UILabel {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewQuestionCardFont
        label.textAlignment = .natural
        label.textColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewQuestionCardTitleColor
        return label
    }

    public lazy var questionCard1: UIView = createQuestionCard()
    public lazy var questionCard1Icon: UIImageView = createQuestionIcon()
    public lazy var questionCard1Title: UILabel = createQuestionLabel()

    public lazy var questionCard2: UIView = createQuestionCard()
    public lazy var questionCard2Icon: UIImageView = createQuestionIcon()
    public lazy var questionCard2Title: UILabel = createQuestionLabel()

    public lazy var questionCard3: UIView = createQuestionCard()
    public lazy var questionCard3Icon: UIImageView = createQuestionIcon()
    public lazy var questionCard3Title: UILabel = createQuestionLabel()

    public var confirmEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewNextButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var retakeButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewRetakeButtonBackgroundColor
        button.setTitleColor(IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewRetakeButtonTextColor, for: .normal)
        button.layer.borderColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewRetakeButtonBorderColor.cgColor
        button.layer.borderWidth = IdenfyButtonsUISettingsV2.idenfyChooseAnotherPhotoButtonCornerRadius
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var confirmButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewConfirmButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyBankCardUploadReviewViewUISettingsV2.idenfyBankCardUploadReviewViewBackgroundColor
        setupToolbar()
        setupButtons()
        setupPdfPreview()
        setupTitle()
        setupQuestionCards()
        setupButtonActions()
    }

    private func setupButtonActions() {
        confirmEnabledButton.addTarget(self, action: #selector(confirmButtonAction), for: .touchUpInside)
        retakeButton.addTarget(self, action: #selector(retakeButtonAction), for: .touchUpInside)
    }

    @objc func confirmButtonAction() { delegate?.confirmButtonPressed() }
    @objc func retakeButtonAction() { delegate?.retakeButtonPressed() }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTitle() {
        addSubview(bankCardUploadReviewTitle)
        bankCardUploadReviewTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        bankCardUploadReviewTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        bankCardUploadReviewTitle.topAnchor.constraint(equalTo: webViewContainer.bottomAnchor, constant: 16).isActive = true

    }

    open func setupButtons() {
        addSubview(retakeButton)
        retakeButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        retakeButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        retakeButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        retakeButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(confirmEnabledButton)
        confirmEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        confirmEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        confirmEnabledButton.bottomAnchor.constraint(equalTo: retakeButton.topAnchor, constant: -16).isActive = true
        confirmEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(confirmButtonSpinner)
        confirmButtonSpinner.centerYAnchor.constraint(equalTo: confirmEnabledButton.centerYAnchor).isActive = true
        confirmButtonSpinner.leadingAnchor.constraint(equalTo: confirmEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        confirmButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        confirmButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func setupPdfPreview() {
        addSubview(webViewContainer)
        webViewContainer.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        webViewContainer.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        webViewContainer.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 16).isActive = true
        webViewContainer.heightAnchor.constraint(equalTo: webViewContainer.widthAnchor, multiplier: 9.0/16.0).isActive = true

        pdfFileIconImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        pdfFileIconImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        pdfFallbackStack.addArrangedSubview(pdfFileIconImageView)
        pdfFallbackStack.addArrangedSubview(pdfFileNameLabel)
        webViewContainer.addSubview(pdfFallbackStack)
        pdfFallbackStack.centerXAnchor.constraint(equalTo: webViewContainer.centerXAnchor).isActive = true
        pdfFallbackStack.centerYAnchor.constraint(equalTo: webViewContainer.centerYAnchor).isActive = true
    }

    /// Show the filename fallback (for PDFs with no preview).
    open func showPdfFallback(fileName: String) {
        pdfFileNameLabel.text = fileName
        pdfFallbackStack.isHidden = false
    }

    open func setupQuestionCards() {
        addSubview(questionCard1)
        addSubview(questionCard2)
        addSubview(questionCard3)

        // Card 1
        questionCard1.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        questionCard1.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        questionCard1.topAnchor.constraint(equalTo: bankCardUploadReviewTitle.bottomAnchor, constant: 16).isActive = true
        questionCard1.heightAnchor.constraint(greaterThanOrEqualToConstant: 50).isActive = true

        questionCard1.addSubview(questionCard1Icon)
        questionCard1Icon.leadingAnchor.constraint(equalTo: questionCard1.safeLeftAnchor, constant: 16).isActive = true
        questionCard1Icon.topAnchor.constraint(equalTo: questionCard1.safeTopAnchor).isActive = true
        questionCard1Icon.bottomAnchor.constraint(equalTo: questionCard1.safeBottomAnchor).isActive = true

        questionCard1.addSubview(questionCard1Title)
        questionCard1Title.leadingAnchor.constraint(equalTo: questionCard1.safeLeftAnchor, constant: 50).isActive = true
        questionCard1Title.trailingAnchor.constraint(equalTo: questionCard1.safeRightAnchor, constant: -24).isActive = true
        questionCard1Title.topAnchor.constraint(equalTo: questionCard1.safeTopAnchor, constant: 8).isActive = true
        questionCard1Title.bottomAnchor.constraint(equalTo: questionCard1.safeBottomAnchor, constant: -8).isActive = true

        // Card 2
        questionCard2.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        questionCard2.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        questionCard2.topAnchor.constraint(equalTo: questionCard1.bottomAnchor, constant: 8).isActive = true
        questionCard2.heightAnchor.constraint(greaterThanOrEqualToConstant: 50).isActive = true

        questionCard2.addSubview(questionCard2Icon)
        questionCard2Icon.leadingAnchor.constraint(equalTo: questionCard2.safeLeftAnchor, constant: 16).isActive = true
        questionCard2Icon.topAnchor.constraint(equalTo: questionCard2.safeTopAnchor).isActive = true
        questionCard2Icon.bottomAnchor.constraint(equalTo: questionCard2.safeBottomAnchor).isActive = true

        questionCard2.addSubview(questionCard2Title)
        questionCard2Title.leadingAnchor.constraint(equalTo: questionCard2.safeLeftAnchor, constant: 50).isActive = true
        questionCard2Title.trailingAnchor.constraint(equalTo: questionCard2.safeRightAnchor, constant: -24).isActive = true
        questionCard2Title.topAnchor.constraint(equalTo: questionCard2.safeTopAnchor, constant: 8).isActive = true
        questionCard2Title.bottomAnchor.constraint(equalTo: questionCard2.safeBottomAnchor, constant: -8).isActive = true

        // Card 3
        questionCard3.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        questionCard3.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        questionCard3.topAnchor.constraint(equalTo: questionCard2.bottomAnchor, constant: 8).isActive = true
        questionCard3.heightAnchor.constraint(greaterThanOrEqualToConstant: 50).isActive = true

        questionCard3.addSubview(questionCard3Icon)
        questionCard3Icon.leadingAnchor.constraint(equalTo: questionCard3.safeLeftAnchor, constant: 16).isActive = true
        questionCard3Icon.topAnchor.constraint(equalTo: questionCard3.safeTopAnchor).isActive = true
        questionCard3Icon.bottomAnchor.constraint(equalTo: questionCard3.safeBottomAnchor).isActive = true

        questionCard3.addSubview(questionCard3Title)
        questionCard3Title.leadingAnchor.constraint(equalTo: questionCard3.safeLeftAnchor, constant: 50).isActive = true
        questionCard3Title.trailingAnchor.constraint(equalTo: questionCard3.safeRightAnchor, constant: -24).isActive = true
        questionCard3Title.topAnchor.constraint(equalTo: questionCard3.safeTopAnchor, constant: 8).isActive = true
        questionCard3Title.bottomAnchor.constraint(equalTo: questionCard3.safeBottomAnchor, constant: -8).isActive = true
    }

    open func applyGradients() {
        confirmEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
