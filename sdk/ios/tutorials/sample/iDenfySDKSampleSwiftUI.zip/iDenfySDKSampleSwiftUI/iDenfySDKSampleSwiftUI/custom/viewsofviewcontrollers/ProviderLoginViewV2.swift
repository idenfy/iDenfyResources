//
//  ProviderLoginViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-05-04.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol ProviderLogingViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
    func providerPasswordVisibilityButtonPressed()
}

public protocol ProviderLoginViewableV2: UIView {
    var delegate: ProviderLogingViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var providerLoginTitle: UILabel { get }
    var providerLoginDescription: UILabel { get }
    var providerUsernameHintLabel: UILabel { get }
    var providerPasswordHintLabel: UILabel { get }
    var providerUsernameInputView: UITextField { get }
    var providerPasswordInputView: UITextField { get }
    var providerPasswordVisibilityButton: UIButton { get }
    var continueButton: UIButton { get }
    var continueButtonSpinner: LottieAnimationView { get }
    
    func applyGradients()
}

@objc open class ProviderLogingViewV2: UIView, ProviderLoginViewableV2 {
    open weak var delegate: ProviderLogingViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var providerLoginTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewTitleTextColor
        return label
    }()

    public var providerLoginDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewDescriptionTextColor
        return label
    }()
    
    public var providerUsernameHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameHintFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameHintTextColor
        return label
    }()
    
    public var providerPasswordHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordHintFont
        label.textAlignment = .idenfyNatural
        label.isHidden = true
        label.textColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordHintTextColor
        return label
    }()
    
    public var providerUsernameInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.textContentType = .givenName
        textField.font = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputViewFont
        textField.textColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputViewTextColor
        textField.backgroundColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputViewBackgroundColor
        textField.returnKeyType = .next
        textField.layer.cornerRadius = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputViewCorderRadius
        textField.layer.borderWidth = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputBorderWidth
        textField.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(42)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        return textField
    }()
    
    public var providerUsernameIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyCommonColors.idenfySecondColorV2
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_username).withRenderingMode(.alwaysTemplate)
        imageView.alpha = 0.5
        return imageView
    }()
    
    public var providerPasswordInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.textContentType = .password
        textField.font = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordInputViewFont
        textField.textColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordInputViewTextColor
        textField.returnKeyType = .done
        textField.isSecureTextEntry = true
        textField.backgroundColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordInputViewBackgroundColor
        textField.layer.cornerRadius = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordInputViewCorderRadius
        textField.layer.borderWidth = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordInputBorderWidth
        textField.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewPasswordInputBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CALayer.idenfyDirectionalTranslation(42)
        textField.isUserInteractionEnabled = true
        textField.tag = 1
        return textField
    }()
    
    public var providerPasswordIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyCommonColors.idenfySecondColorV2
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_password).withRenderingMode(.alwaysTemplate)
        imageView.alpha = 0.5
        return imageView
    }()
    
    public var providerPasswordVisibilityButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(IdenfyViewUtils.getImage("idenfy_ic_password_visible"), for: .normal)
        button.isHidden = true
        button.isUserInteractionEnabled = true
        return button
    }()

    public var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewContinueButtonTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupTopTitle()
        setupCenterTextFields()
        setupButtonActions()
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
        providerPasswordVisibilityButton.addTarget(self, action: #selector(passwordVisibilityButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }
    
    @objc func passwordVisibilityButtonPressed() {
        delegate?.providerPasswordVisibilityButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(providerLoginTitle)
        providerLoginTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        providerLoginTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        providerLoginTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(providerLoginDescription)
        providerLoginDescription.widthAnchor.constraint(equalTo: providerLoginTitle.widthAnchor, multiplier: 0.8).isActive = true
        providerLoginDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        providerLoginDescription.topAnchor.constraint(equalTo: providerLoginTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupContinueButton() {
        addSubview(continueButton)
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: continueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func setupCenterTextFields() {
        
        addSubview(providerUsernameInputView)
        providerUsernameInputView.bottomAnchor.constraint(equalTo: centerYAnchor, constant: -60).isActive = true
        providerUsernameInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        providerUsernameInputView.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 24).isActive = true
        providerUsernameInputView.trailingAnchor.constraint(equalTo: continueButton.trailingAnchor, constant: -24).isActive = true
        
        addSubview(providerUsernameIcon)
        providerUsernameIcon.leadingAnchor.constraint(equalTo: providerUsernameInputView.leadingAnchor, constant: 16).isActive = true
        providerUsernameIcon.centerYAnchor.constraint(equalTo: providerUsernameInputView.centerYAnchor).isActive = true
        
        addSubview(providerPasswordInputView)
        providerPasswordInputView.topAnchor.constraint(equalTo: providerUsernameInputView.bottomAnchor, constant: 16).isActive = true
        providerPasswordInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        providerPasswordInputView.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 24).isActive = true
        providerPasswordInputView.trailingAnchor.constraint(equalTo: continueButton.trailingAnchor, constant: -24).isActive = true
        
        addSubview(providerPasswordIcon)
        providerPasswordIcon.leadingAnchor.constraint(equalTo: providerPasswordInputView.leadingAnchor, constant: 16).isActive = true
        providerPasswordIcon.centerYAnchor.constraint(equalTo: providerPasswordInputView.centerYAnchor).isActive = true
        
        addSubview(providerUsernameHintLabel)
        providerUsernameHintLabel.topAnchor.constraint(equalTo: providerUsernameInputView.topAnchor, constant: 2).isActive = true
        providerUsernameHintLabel.leadingAnchor.constraint(equalTo: providerUsernameInputView.safeLeftAnchor, constant: 10).isActive = true
        providerUsernameHintLabel.trailingAnchor.constraint(equalTo: providerUsernameInputView.safeRightAnchor).isActive = true
        
        addSubview(providerPasswordHintLabel)
        providerPasswordHintLabel.topAnchor.constraint(equalTo: providerPasswordInputView.topAnchor, constant: 2).isActive = true
        providerPasswordHintLabel.leadingAnchor.constraint(equalTo: providerPasswordInputView.safeLeftAnchor, constant: 10).isActive = true
        providerPasswordHintLabel.trailingAnchor.constraint(equalTo: providerPasswordInputView.safeRightAnchor).isActive = true
        
        addSubview(providerPasswordVisibilityButton)
        providerPasswordVisibilityButton.centerYAnchor.constraint(equalTo: providerPasswordInputView.centerYAnchor).isActive = true
        providerPasswordVisibilityButton.heightAnchor.constraint(equalToConstant: 25).isActive = true
        providerPasswordVisibilityButton.widthAnchor.constraint(equalTo: providerPasswordVisibilityButton.heightAnchor, multiplier: 1).isActive = true
        providerPasswordVisibilityButton.trailingAnchor.constraint(equalTo: providerPasswordInputView.safeRightAnchor, constant: -16).isActive = true
    }
    
    open func applyGradients() {
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
