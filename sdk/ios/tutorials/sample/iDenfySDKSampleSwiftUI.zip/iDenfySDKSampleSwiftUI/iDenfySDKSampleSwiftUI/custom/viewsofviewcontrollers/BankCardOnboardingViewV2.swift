//
//  BankCardOnboardingViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2026-06-22.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import UIKit
import Lottie

public protocol BankCardOnboardingViewButtonActionsDelegate: AnyObject {
    func continueButtonPressed()
    func captureOptionTapped()
    func uploadOptionTapped()
}

public protocol BankCardOnboardingViewableV2: UIView {
    var delegate: BankCardOnboardingViewButtonActionsDelegate? { get set }
    var toolbar: IdenfyToolbarV2WithLanguageSelection { get }
    var bankCardOnboardingTitle: UILabel { get }
    var bankCardOnboardingDescription: UILabel { get }
    var captureOptionCard: UIView { get }
    var captureOptionTitle: UILabel { get }
    var captureOptionDescription: UILabel { get }
    var captureOptionIcon: UIImageView { get }
    var uploadOptionCard: UIView { get }
    var uploadOptionTitle: UILabel { get }
    var uploadOptionDescription: UILabel { get }
    var uploadOptionIcon: UIImageView { get }
    var flipIconImageView: UIImageView { get }
    var continueEnabledButton: UIButton { get }
    var continueDisabledButton: UIButton { get }
    var continueButtonSpinner: LottieAnimationView { get }
    var privacyNoteLabel: UILabel { get }

    func applyGradients()
}

@objc open class BankCardOnboardingViewV2: UIView, BankCardOnboardingViewableV2 {
    open weak var delegate: BankCardOnboardingViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var bankCardOnboardingTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewTitleTextColor
        return label
    }()

    public var bankCardOnboardingDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewDescriptionTextColor
        return label
    }()

    public var captureOptionCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardBackgroundColor
        view.layer.borderColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardBorderColor.cgColor
        view.layer.borderWidth = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardBorderWidth
        view.layer.cornerRadius = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardCornerRadius
        view.isUserInteractionEnabled = true
        return view
    }()

    public var captureOptionIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_custom_drawable_camera_preview_session_take_photo_icon_v2).withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardIconTintColor
        return imageView
    }()

    public var captureOptionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardTitleFont
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardTitleTextColor
        return label
    }()

    public var captureOptionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardDescriptionFont
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardDescriptionTextColor
        return label
    }()

    public var uploadOptionCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardBackgroundColor
        view.layer.borderColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardBorderColor.cgColor
        view.layer.borderWidth = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardBorderWidth
        view.layer.cornerRadius = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardCornerRadius
        view.isUserInteractionEnabled = true
        return view
    }()

    public var uploadOptionIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_camera_onboarding_other_document_image).withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardIconTintColor
        return imageView
    }()

    public var uploadOptionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardTitleFont
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardTitleTextColor
        return label
    }()

    public var uploadOptionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardDescriptionFont
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewCardDescriptionTextColor
        return label
    }()

    public var flipIconImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_documents_type_selection_bank_card_v2)
        imageView.isHidden = true
        return imageView
    }()

    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isHidden = true
        return button
    }()

    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.setTitleColor(IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        return button
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_country_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewContinueButtonLoadingSpinnerTintColor)
        return lottieView
    }()

    public var privacyNoteLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewPrivacyNoteFont
        label.textAlignment = .center
        label.textColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewPrivacyNoteTextColor
        return label
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyBankCardOnboardingViewUISettingsV2.idenfyBankCardOnboardingViewBackgroundColor
        setupToolbar()
        setupTitle()
        setupOptionCards()
        setupFlipIcon()
        setupContinueButton()
        setupPrivacyNote()
        setupButtonActions()
    }

    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonAction), for: .touchUpInside)
        captureOptionCard.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(captureOptionAction)))
        uploadOptionCard.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(uploadOptionAction)))
    }

    @objc func continueButtonAction() { delegate?.continueButtonPressed() }
    @objc func captureOptionAction() { delegate?.captureOptionTapped() }
    @objc func uploadOptionAction() { delegate?.uploadOptionTapped() }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTitle() {
        addSubview(bankCardOnboardingTitle)
        bankCardOnboardingTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        bankCardOnboardingTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        bankCardOnboardingTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(bankCardOnboardingDescription)
        bankCardOnboardingDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        bankCardOnboardingDescription.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        bankCardOnboardingDescription.topAnchor.constraint(equalTo: bankCardOnboardingTitle.bottomAnchor, constant: 16).isActive = true
    }

    private lazy var optionsStackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [captureOptionCard, uploadOptionCard, privacyNoteLabel])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 12
        stackView.alignment = .fill
        return stackView
    }()

    open func setupOptionCards() {
        captureOptionCard.heightAnchor.constraint(greaterThanOrEqualToConstant: 72).isActive = true

        captureOptionCard.addSubview(captureOptionIcon)
        captureOptionIcon.leadingAnchor.constraint(equalTo: captureOptionCard.leadingAnchor, constant: 16).isActive = true
        captureOptionIcon.topAnchor.constraint(equalTo: captureOptionCard.topAnchor, constant: 16).isActive = true
        captureOptionIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        captureOptionIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true

        captureOptionCard.addSubview(captureOptionTitle)
        captureOptionTitle.topAnchor.constraint(equalTo: captureOptionCard.topAnchor, constant: 16).isActive = true
        captureOptionTitle.leadingAnchor.constraint(equalTo: captureOptionIcon.trailingAnchor, constant: 12).isActive = true
        captureOptionTitle.trailingAnchor.constraint(equalTo: captureOptionCard.trailingAnchor, constant: -16).isActive = true

        captureOptionCard.addSubview(captureOptionDescription)
        captureOptionDescription.topAnchor.constraint(equalTo: captureOptionTitle.bottomAnchor, constant: 8).isActive = true
        captureOptionDescription.leadingAnchor.constraint(equalTo: captureOptionIcon.trailingAnchor, constant: 12).isActive = true
        captureOptionDescription.trailingAnchor.constraint(equalTo: captureOptionCard.trailingAnchor, constant: -16).isActive = true
        captureOptionDescription.bottomAnchor.constraint(equalTo: captureOptionCard.bottomAnchor, constant: -16).isActive = true

        uploadOptionCard.heightAnchor.constraint(greaterThanOrEqualToConstant: 72).isActive = true

        uploadOptionCard.addSubview(uploadOptionIcon)
        uploadOptionIcon.leadingAnchor.constraint(equalTo: uploadOptionCard.leadingAnchor, constant: 16).isActive = true
        uploadOptionIcon.topAnchor.constraint(equalTo: uploadOptionCard.topAnchor, constant: 16).isActive = true
        uploadOptionIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        uploadOptionIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true

        uploadOptionCard.addSubview(uploadOptionTitle)
        uploadOptionTitle.topAnchor.constraint(equalTo: uploadOptionCard.topAnchor, constant: 16).isActive = true
        uploadOptionTitle.leadingAnchor.constraint(equalTo: uploadOptionIcon.trailingAnchor, constant: 12).isActive = true
        uploadOptionTitle.trailingAnchor.constraint(equalTo: uploadOptionCard.trailingAnchor, constant: -16).isActive = true

        uploadOptionCard.addSubview(uploadOptionDescription)
        uploadOptionDescription.topAnchor.constraint(equalTo: uploadOptionTitle.bottomAnchor, constant: 8).isActive = true
        uploadOptionDescription.leadingAnchor.constraint(equalTo: uploadOptionIcon.trailingAnchor, constant: 12).isActive = true
        uploadOptionDescription.trailingAnchor.constraint(equalTo: uploadOptionCard.trailingAnchor, constant: -16).isActive = true
        uploadOptionDescription.bottomAnchor.constraint(equalTo: uploadOptionCard.bottomAnchor, constant: -16).isActive = true

        addSubview(optionsStackView)
        optionsStackView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        optionsStackView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        optionsStackView.topAnchor.constraint(equalTo: bankCardOnboardingDescription.bottomAnchor, constant: 24).isActive = true
    }

    open func setupFlipIcon() {
        addSubview(flipIconImageView)
        flipIconImageView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        flipIconImageView.topAnchor.constraint(equalTo: bankCardOnboardingDescription.bottomAnchor, constant: 48).isActive = true
        flipIconImageView.widthAnchor.constraint(equalToConstant: 180).isActive = true
        flipIconImageView.heightAnchor.constraint(equalToConstant: 180).isActive = true
    }

    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueDisabledButton)
        continueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func setupPrivacyNote() {
        // privacyNoteLabel is managed by optionsStackView — no additional constraints needed
    }

    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
