//
//  MFACaptchaViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2022-04-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit
import AVFoundation
import Lottie

@objc open class MFACaptchaViewV2: UIView, MFACaptchaViewableV2 {
    open weak var delegate: MFACaptchaViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var mfaCaptchaTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewTitleTextColor
        return label
    }()

    public var mfaCaptchaDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewDescriptionTextColor
        return label
    }()
    
    public var mfaCaptchaHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewHintFont
        label.textAlignment = .left
        label.isHidden = true
        label.textColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewHintTextColor
        return label
    }()
    
    public var mfaCaptchaInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewInputViewFont
        textField.textAlignment = .left
        textField.textColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewInputViewTextColor
        textField.backgroundColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewInputViewBackgroundColor
        textField.returnKeyType = .done
        textField.layer.cornerRadius = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewInputViewCorderRadius
        textField.layer.borderWidth = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewInputViewBorderWidth
        textField.layer.borderColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewInputBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        return textField
    }()
    
    public var mfaCaptchaImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var mfaContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyMFACaptchaViewUISettingsV2.idenfyMFACaptchaViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupTopTitle()
        setupCenterTextFields()
        setupButtonActions()
    }

    private func setupButtonActions() {
        mfaContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(mfaCaptchaTitle)
        mfaCaptchaTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        mfaCaptchaTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        mfaCaptchaTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(mfaCaptchaDescription)
        mfaCaptchaDescription.widthAnchor.constraint(equalTo: mfaCaptchaTitle.widthAnchor, multiplier: 0.8).isActive = true
        mfaCaptchaDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        mfaCaptchaDescription.topAnchor.constraint(equalTo: mfaCaptchaTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupContinueButton() {
        addSubview(mfaContinueButton)
        mfaContinueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        mfaContinueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        mfaContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        mfaContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: mfaContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leftAnchor.constraint(equalTo: mfaContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func setupCenterTextFields() {
        addSubview(mfaCaptchaImageView)
        mfaCaptchaImageView.topAnchor.constraint(equalTo: mfaCaptchaDescription.bottomAnchor, constant: 32).isActive = true
        mfaCaptchaImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        mfaCaptchaImageView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        
        addSubview(mfaCaptchaInputView)
        mfaCaptchaInputView.topAnchor.constraint(equalTo: mfaCaptchaImageView.bottomAnchor, constant: 16).isActive = true
        mfaCaptchaInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        mfaCaptchaInputView.leftAnchor.constraint(equalTo: mfaContinueButton.leftAnchor, constant: 24).isActive = true
        mfaCaptchaInputView.rightAnchor.constraint(equalTo: mfaContinueButton.rightAnchor, constant: -24).isActive = true
        
        addSubview(mfaCaptchaHintLabel)
        mfaCaptchaHintLabel.topAnchor.constraint(equalTo: mfaCaptchaInputView.topAnchor, constant: 2).isActive = true
        mfaCaptchaHintLabel.leftAnchor.constraint(equalTo: mfaCaptchaInputView.safeLeftAnchor, constant: 10).isActive = true
        mfaCaptchaHintLabel.rightAnchor.constraint(equalTo: mfaCaptchaInputView.safeRightAnchor).isActive = true
    }
    
    open func applyGradients() {
        mfaContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}


