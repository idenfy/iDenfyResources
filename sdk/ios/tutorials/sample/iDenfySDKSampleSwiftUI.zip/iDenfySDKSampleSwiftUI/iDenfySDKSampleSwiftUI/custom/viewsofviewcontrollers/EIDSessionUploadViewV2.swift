//
//  EIDSessionUploadViewV2.swift
//  testing
//
//  Created by iDenfy on 2026-05-20.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class EIDSessionUploadViewV2: UIView, EIDSessionUploadViewableV2 {
    open weak var delegate: EIDSessionUploadViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var eidSessionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewTitleFont
        label.textAlignment = .center
        label.textColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewTitleTextColor
        return label
    }()

    public var eidSessionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewDescriptionFont
        label.textAlignment = .center
        label.textColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewDescriptionTextColor
        return label
    }()

    public var uploadQRCodeLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadLabelFont
        label.textAlignment = .natural
        label.textColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewDescriptionTextColor
        return label
    }()

    public var uploadAreaView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadAreaBackgroundColor
        view.layer.cornerRadius = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadAreaCornerRadius
        view.layer.borderWidth = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadAreaBorderWidth
        view.layer.borderColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadAreaBorderColor.cgColor
        view.layer.masksToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()

    public var uploadIconImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_confirmation_upload_photo", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadIconTintColor
        return imageView
    }()

    public var clickToUploadLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewClickToUploadFont
        label.textAlignment = .center
        label.textColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewClickToUploadTextColor
        return label
    }()

    public var fileSizeHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadHintFont
        label.textAlignment = .center
        label.textColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadHintTextColor
        return label
    }()

    public var imagePreviewView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.isHidden = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()

    public var uploadContentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 8
        return stackView
    }()

    public var errorCardView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        view.layer.cornerRadius = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadAreaCornerRadius
        view.layer.borderWidth = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewUploadAreaBorderWidth
        view.layer.borderColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewErrorCardBorderColor.cgColor
        view.backgroundColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewErrorCardBackgroundColor
        return view
    }()

    public var errorCardIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_information_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewErrorCardIconTintColor
        return imageView
    }()

    public var errorCardLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewErrorCardTextFont
        label.textAlignment = .natural
        label.textColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewErrorCardTextColor
        return label
    }()

    public var eidSessionContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var eidSessionContinueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()

    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = EIDSessionUploadViewUISettingsV2.idenfyEIDSessionUploadViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupUploadQRCodeLabel()
        setupUploadArea()
        setupErrorCard()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        eidSessionContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(uploadAreaTapped))
        uploadAreaView.addGestureRecognizer(tapGesture)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    @objc func uploadAreaTapped() {
        delegate?.uploadAreaTapped()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(eidSessionTitle)
        eidSessionTitle.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        eidSessionTitle.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        eidSessionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(eidSessionDescription)
        eidSessionDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        eidSessionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        eidSessionDescription.topAnchor.constraint(equalTo: eidSessionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupUploadQRCodeLabel() {
        addSubview(uploadQRCodeLabel)
        uploadQRCodeLabel.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        uploadQRCodeLabel.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        uploadQRCodeLabel.topAnchor.constraint(equalTo: eidSessionDescription.bottomAnchor, constant: 24).isActive = true
    }

    open func setupUploadArea() {
        addSubview(uploadAreaView)
        uploadAreaView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        uploadAreaView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        uploadAreaView.topAnchor.constraint(equalTo: uploadQRCodeLabel.bottomAnchor, constant: 16).isActive = true

        imagePreviewView.widthAnchor.constraint(equalToConstant: 80).isActive = true
        imagePreviewView.heightAnchor.constraint(equalToConstant: 80).isActive = true
        uploadIconImageView.widthAnchor.constraint(equalToConstant: 22).isActive = true
        uploadIconImageView.heightAnchor.constraint(equalToConstant: 22).isActive = true

        uploadContentStackView.addArrangedSubview(imagePreviewView)
        uploadContentStackView.addArrangedSubview(uploadIconImageView)
        uploadContentStackView.addArrangedSubview(clickToUploadLabel)
        uploadContentStackView.addArrangedSubview(fileSizeHintLabel)

        uploadAreaView.addSubview(uploadContentStackView)
        uploadContentStackView.leadingAnchor.constraint(equalTo: uploadAreaView.leadingAnchor, constant: 24).isActive = true
        uploadContentStackView.trailingAnchor.constraint(equalTo: uploadAreaView.trailingAnchor, constant: -24).isActive = true
        uploadContentStackView.topAnchor.constraint(equalTo: uploadAreaView.topAnchor, constant: 24).isActive = true
        uploadContentStackView.bottomAnchor.constraint(equalTo: uploadAreaView.bottomAnchor, constant: -24).isActive = true
    }

    open func setupErrorCard() {
        addSubview(errorCardView)
        errorCardView.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        errorCardView.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        errorCardView.topAnchor.constraint(equalTo: uploadAreaView.bottomAnchor, constant: 8).isActive = true

        errorCardView.addSubview(errorCardIcon)
        errorCardIcon.leadingAnchor.constraint(equalTo: errorCardView.leadingAnchor, constant: 16).isActive = true
        errorCardIcon.centerYAnchor.constraint(equalTo: errorCardView.centerYAnchor).isActive = true
        errorCardIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        errorCardIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true

        errorCardView.addSubview(errorCardLabel)
        errorCardLabel.leadingAnchor.constraint(equalTo: errorCardIcon.trailingAnchor, constant: 8).isActive = true
        errorCardLabel.trailingAnchor.constraint(equalTo: errorCardView.trailingAnchor, constant: -16).isActive = true
        errorCardLabel.topAnchor.constraint(equalTo: errorCardView.topAnchor, constant: 12).isActive = true
        errorCardLabel.bottomAnchor.constraint(equalTo: errorCardView.bottomAnchor, constant: -12).isActive = true
    }

    open func setupContinueButton() {
        addSubview(eidSessionContinueButton)
        eidSessionContinueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(eidSessionContinueDisabledButton)
        eidSessionContinueDisabledButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueDisabledButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: eidSessionContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leadingAnchor.constraint(equalTo: eidSessionContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func applyGradients() {
        eidSessionContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
