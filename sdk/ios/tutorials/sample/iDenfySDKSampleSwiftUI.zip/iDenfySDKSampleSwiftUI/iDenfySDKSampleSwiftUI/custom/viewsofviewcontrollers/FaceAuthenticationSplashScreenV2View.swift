//
//  FaceAuthenticationSplashScreenV2View.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-10-28.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import Lottie
import UIKit

public protocol FaceAuthenticationSplashScreenV2Viewable: UIView {
    var splashScreenTitle: UILabel { get }
}

@objc open class FaceAuthenticationSplashScreenV2View: UIView, FaceAuthenticationSplashScreenV2Viewable {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
        backgroundColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewBackgroundColor
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyLogo: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_splash_screen_logo)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = IdenfyViewUtils.getResourcePath(name: ConstsIdenfyOtherResources.idenfy_custom_file_loader, type: ResourceType.json) {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.applyColorTint(IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewSpinnerTintColor)
        return lottieView
    }()

    public var splashScreenTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewTitleTextColor
        label.numberOfLines = 0
        label.font = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewTitleFont
        label.textAlignment = .center
        return label
    }()
    
    public var splashScreenDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionTextColor
        label.numberOfLines = 0
        label.font = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionFont
        label.textAlignment = .center
        return label
    }()
    
    public var idenfyImageViewPowered: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = IdenfyViewUtils.getImage(ConstsIdenfyImages.idenfy_ic_powered_by_idenfy_v2)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var bottomStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .horizontal
        stackView.distribution = .fill
        stackView.alignment = .center
        stackView.spacing = 4
        stackView.semanticContentAttribute = .forceLeftToRight
        return stackView
    }()

    open func setupConstraints() {
        setupViews()
    }

    @objc open func setupViews() {
        addSubview(splashScreenTitle)
        splashScreenTitle.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        splashScreenTitle.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        splashScreenTitle.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        
        addSubview(idenfyLogo)
        idenfyLogo.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        idenfyLogo.bottomAnchor.constraint(equalTo: splashScreenTitle.topAnchor, constant: -12).isActive = true
        idenfyLogo.heightAnchor.constraint(equalToConstant: IdenfySplashScreenViewUISettingsV2.idenfySplashScreenLogoSize).isActive = true
        
        addSubview(loadingSpinner)
        loadingSpinner.topAnchor.constraint(equalTo: splashScreenTitle.bottomAnchor, constant: 40).isActive = true
        loadingSpinner.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 53).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 53).isActive = true

        bottomStackView.addArrangedSubview(splashScreenDescription)
        bottomStackView.addArrangedSubview(idenfyImageViewPowered)

        addSubview(bottomStackView)
        bottomStackView.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -16).isActive = true
        bottomStackView.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor).isActive = true

        idenfyImageViewPowered.widthAnchor.constraint(equalToConstant: 35).isActive = true
        idenfyImageViewPowered.heightAnchor.constraint(equalToConstant: 120).isActive = true
        idenfyImageViewPowered.transform = CGAffineTransform(translationX: 0, y: 2)
    }
}
