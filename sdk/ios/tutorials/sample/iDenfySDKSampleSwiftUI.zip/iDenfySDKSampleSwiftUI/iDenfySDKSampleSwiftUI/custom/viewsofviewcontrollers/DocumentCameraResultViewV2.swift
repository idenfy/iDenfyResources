//
//  DocumentCameraResultViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class DocumentCameraResultViewV2: UIView, CameraResultViewableV2 {
    open weak var delegate: FileResultViewV2ButtonActionsDelegate?

    override public required init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var photoResultTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewTitleColor
        return label
    }()

    public var poweredByIdenfyCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white
        view.layer.cornerRadius = CGFloat(4)
        view.layer.borderWidth = CGFloat(1)
        view.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.1).cgColor
        view.isHidden = true
        return view
    }()

    public var poweredByIdenfyTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPoweredByIdenfyTitleColor
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPoweredByIdenfyTitleFont
        return label
    }()

    public var photoResultDetailsCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardSecond: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardCornerRadius
        return view
    }()

    public var photoResultDetailsCardQuestionMark: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var photoResultDetailsCardQuestionMarkSecond: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var photoResultDetailsCardTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public var photoResultDetailsCardTitleSecond: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleFont
        label.textAlignment = .idenfyNatural
        label.textColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor
        return label
    }()

    public var fileResultImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewPhotoCornerRadius
        return imageView
    }()
    
    public var photoResultDetailsSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_animation_photo_result_loading_indicator", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.alpha = 0.6
        lottieView.isHidden = true
        return lottieView
    }()

    public var continueButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    public var chooseAnotherFileButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.masksToBounds = true
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.borderWidth = IdenfyButtonsUISettingsV2.idenfyChooseAnotherPhotoButtonCornerRadius
        button.layer.borderColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonBorderColor.cgColor
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewBackgroundColor
        setupToolbar()
        setupButtons()
        setupSpinner()
        setupButtonActions()
        setupImageView()
        setupTitle()
        setupDocumentDetailCards()
        setupPoweredByIdenfyCard()
    }

    private func setupButtonActions() {
        continueButton.addTarget(self, action: #selector(confirmPhotoButtonPressed), for: .touchUpInside)
        chooseAnotherFileButton.addTarget(self, action: #selector(retakePhotoButtonPressed), for: .touchUpInside)
    }

    @objc func confirmPhotoButtonPressed() {
        delegate?.confirmButtonPressedAction()
    }

    @objc func retakePhotoButtonPressed() {
        delegate?.retakeButtonPressedAction()
    }
    
    private func setupSpinner() {
        addSubview(photoResultDetailsSpinner)
        photoResultDetailsSpinner.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -24).isActive = true
        photoResultDetailsSpinner.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        photoResultDetailsSpinner.heightAnchor.constraint(equalToConstant: 150).isActive = true
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupButtons() {
        addSubview(chooseAnotherFileButton)
        chooseAnotherFileButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        chooseAnotherFileButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        chooseAnotherFileButton.heightAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(continueButton)
        continueButton.bottomAnchor.constraint(equalTo: chooseAnotherFileButton.topAnchor, constant: -16).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    private func setupTitle() {
        addSubview(photoResultTitle)
        photoResultTitle.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        photoResultTitle.topAnchor.constraint(equalTo: fileResultImageView.bottomAnchor, constant: 12).isActive = true
    }

    private func setupDocumentDetailCards() {
        addSubview(photoResultDetailsCard)
        photoResultDetailsCard.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        photoResultDetailsCard.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        photoResultDetailsCard.topAnchor.constraint(equalTo: photoResultTitle.bottomAnchor, constant: 12).isActive = true
        photoResultDetailsCard.heightAnchor.constraint(equalToConstant: 50).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardQuestionMark)
        photoResultDetailsCardQuestionMark.leadingAnchor.constraint(equalTo: photoResultDetailsCard.safeLeftAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMark.topAnchor.constraint(equalTo: photoResultDetailsCard.safeTopAnchor).isActive = true
        photoResultDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: photoResultDetailsCard.safeBottomAnchor).isActive = true

        photoResultDetailsCard.addSubview(photoResultDetailsCardTitle)
        photoResultDetailsCardTitle.leadingAnchor.constraint(equalTo: photoResultDetailsCard.safeLeftAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitle.trailingAnchor.constraint(equalTo: photoResultDetailsCard.safeRightAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitle.topAnchor.constraint(equalTo: photoResultDetailsCard.safeTopAnchor).isActive = true
        photoResultDetailsCardTitle.bottomAnchor.constraint(equalTo: photoResultDetailsCard.safeBottomAnchor).isActive = true

        addSubview(photoResultDetailsCardSecond)
        photoResultDetailsCardSecond.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        photoResultDetailsCardSecond.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        photoResultDetailsCardSecond.topAnchor.constraint(equalTo: photoResultDetailsCard.bottomAnchor, constant: 16).isActive = true
        photoResultDetailsCardSecond.heightAnchor.constraint(equalToConstant: 50).isActive = true
        let bottomConstraint = photoResultDetailsCardSecond.bottomAnchor.constraint(equalTo: continueButton.topAnchor, constant: -16)
        bottomConstraint.priority = .fittingSizeLevel
        bottomConstraint.isActive = true

        photoResultDetailsCardSecond.addSubview(photoResultDetailsCardQuestionMarkSecond)
        photoResultDetailsCardQuestionMarkSecond.leadingAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeLeftAnchor, constant: 16).isActive = true
        photoResultDetailsCardQuestionMarkSecond.topAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeTopAnchor).isActive = true
        photoResultDetailsCardQuestionMarkSecond.bottomAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeBottomAnchor).isActive = true

        photoResultDetailsCardSecond.addSubview(photoResultDetailsCardTitleSecond)
        photoResultDetailsCardTitleSecond.leadingAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeLeftAnchor, constant: 50).isActive = true
        photoResultDetailsCardTitleSecond.trailingAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeRightAnchor, constant: -24).isActive = true
        photoResultDetailsCardTitleSecond.topAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeTopAnchor).isActive = true
        photoResultDetailsCardTitleSecond.bottomAnchor.constraint(equalTo: photoResultDetailsCardSecond.safeBottomAnchor).isActive = true
    }

    private func setupImageView() {
        addSubview(fileResultImageView)
        fileResultImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        fileResultImageView.topAnchor.constraint(equalTo: toolbar.topAnchor, constant: 54).isActive = true

        let height = fileResultImageView.heightAnchor.constraint(equalToConstant: 0)
        height.identifier = "photoHeight"
        height.isActive = true

        let width = fileResultImageView.widthAnchor.constraint(equalToConstant: 0)
        width.identifier = "photoWidth"
        width.isActive = true
    }

    private func setupPoweredByIdenfyCard() {
        addSubview(poweredByIdenfyCard)
        poweredByIdenfyCard.topAnchor.constraint(equalTo: fileResultImageView.topAnchor, constant: -15).isActive = true
        poweredByIdenfyCard.heightAnchor.constraint(equalToConstant: 30).isActive = true
        poweredByIdenfyCard.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true

        poweredByIdenfyCard.addSubview(poweredByIdenfyTitle)
        poweredByIdenfyTitle.leadingAnchor.constraint(equalTo: poweredByIdenfyCard.safeLeftAnchor, constant: 16).isActive = true
        poweredByIdenfyTitle.trailingAnchor.constraint(equalTo: poweredByIdenfyCard.safeRightAnchor, constant: -16).isActive = true
        poweredByIdenfyTitle.topAnchor.constraint(equalTo: poweredByIdenfyCard.safeTopAnchor, constant: 8).isActive = true
        poweredByIdenfyTitle.bottomAnchor.constraint(equalTo: poweredByIdenfyCard.safeBottomAnchor, constant: -8).isActive = true
    }
    
    open func applyGradients() {
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
