//
//  SplashScreenV2View.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class SplashScreenV2View: UIView, SplashScreenV2Viewable {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
        backgroundColor = IdenfyCommonColors.idenfyMainColorV2
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var splashScreenTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionTextColor
        label.numberOfLines = 0
        label.font = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionFont
        label.textAlignment = .center
        return label
    }()

    open func setupConstraints() {
        setupViews()
    }

    @objc open func setupViews() {
        addSubview(splashScreenTitle)
        splashScreenTitle.topAnchor.constraint(equalTo: topAnchor).isActive = true
        splashScreenTitle.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        splashScreenTitle.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        splashScreenTitle.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
    }
}
