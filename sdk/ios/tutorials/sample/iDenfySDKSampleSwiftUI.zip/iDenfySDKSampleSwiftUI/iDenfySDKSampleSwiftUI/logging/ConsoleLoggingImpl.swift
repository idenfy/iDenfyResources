//
//  ConsoleLoggingImpl.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation

class ConsoleLoggingImpl {
    func log(event: String, message: String, token _: String) {
        print("FromIdenfySDK", event, " - ", message)
    }
}
