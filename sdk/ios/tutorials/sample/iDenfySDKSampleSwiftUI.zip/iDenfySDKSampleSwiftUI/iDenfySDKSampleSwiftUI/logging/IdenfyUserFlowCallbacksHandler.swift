//
//  IdenfyUserFlowCallbacksHandler.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation
import iDenfySDK

@objc public class IdenfyUserFlowCallbacksHandler: NSObject, IdenfyUserFlowHandler {
    public func onPhotoUploaded(photo: String, step: String) {
        print("IdenfyUserFlowHandler - onPhotoUploaded \(step)")
    }
    
    public func onDocumentSelected(documentType: String) {
        print("IdenfyUserFlowHandler - onDocumentSelected \(documentType)")
    }
    
    public func onCountrySelected(issuingCountryCode: String) {
        print("IdenfyUserFlowHandler - onCountrySelected \(issuingCountryCode)")
    }
    
    public func onProcessingStarted(processingStarted: Bool) {
        print("IdenfyUserFlowHandler - onProcessingStarted \(processingStarted)")
    }
}
