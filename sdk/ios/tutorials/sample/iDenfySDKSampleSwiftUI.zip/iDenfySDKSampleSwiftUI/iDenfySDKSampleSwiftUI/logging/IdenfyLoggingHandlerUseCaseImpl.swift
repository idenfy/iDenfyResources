//
//  IdenfyLoggingHandlerUseCaseImpl.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation
import iDenfySDK

class IdenfyLoggingHandlerUseCaseImpl: IdenfyLoggingHandlerUseCase {
    private var consoleLogging: ConsoleLoggingImpl!

    init(_ consoleLogging: ConsoleLoggingImpl) {
        self.consoleLogging = consoleLogging
    }

    func logEvent(event: String, message: String, token: String) {
        #if DEBUG
            consoleLogging.log(event: event, message: message, token: token)
        #endif
    }
}
