//
//  BankCardVerificationContentView.swift
//  iDenfySDKSampleSwiftUI
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct BankCardVerificationContentView: View {

    @StateObject var viewModel = BankCardVerificationViewModel()

    var body: some View {
        ActivityIndicatorView(authTokenState: $viewModel.authTokenState) {
            VStack(alignment: .center, content: {
                IdenfyToolbarUIView(backButtonHidden: false)
                    .frame(height: 60)
                    .padding(.bottom, 80)
                Text("BANK_CARD_VERIFICATION_TITLE")
                    .foregroundColor(Color.black)
                    .bold()
                    .font(.title2)
                Spacer()
                TextField("", text: $viewModel.expectedName, prompt: Text("EXPECTED_NAME_PROMPT").foregroundColor(Color.black.opacity(0.4)))
                    .textFieldStyle(.plain)
                    .frame(height: 56)
                    .padding(EdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8))
                    .overlay(RoundedRectangle(cornerRadius: 4)
                        .stroke(Color.black.opacity(0.6), lineWidth: 1))
                    .background(Color.white)
                    .foregroundColor(Color.black)
                    .padding(EdgeInsets(top: 0, leading: 32, bottom: 8, trailing: 32))
                TextField("", text: $viewModel.expectedLastFour, prompt: Text("EXPECTED_LAST_FOUR_PROMPT").foregroundColor(Color.black.opacity(0.4)))
                    .textFieldStyle(.plain)
                    .frame(height: 56)
                    .padding(EdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8))
                    .overlay(RoundedRectangle(cornerRadius: 4)
                        .stroke(Color.black.opacity(0.6), lineWidth: 1))
                    .background(Color.white)
                    .foregroundColor(Color.black)
                    .padding(EdgeInsets(top: 0, leading: 32, bottom: 8, trailing: 32))
                Spacer()
                Spacer()
                Button {
                    viewModel.fetchBankCardVerificationToken()
                } label: {
                    Text("CONTINUE_BUTTON_MESSAGE")
                        .frame(maxWidth: .infinity, minHeight: 42)
                        .bold()
                        .font(.subheadline)
                }.buttonStyle(.plain)
                    .background(LinearGradient(gradient: Gradient(colors: [Color(IdenfyCommonColors.idenfyGradientColor1V2), Color(IdenfyCommonColors.idenfyGradientColor2V2)]), startPoint: .leading, endPoint: .trailing))
                    .foregroundColor(Color.white)
                    .cornerRadius(4)
                    .opacity(viewModel.expectedName.isEmpty ? 0.4 : 1)
                    .padding(EdgeInsets(top: 0, leading: 32, bottom: 16, trailing: 32))
                    .disabled(viewModel.expectedName.isEmpty)
            })
            .background(Color.white)
            .fullScreenCover(isPresented: $viewModel.isIdenfySDKPresented, content: { [authTokenState = viewModel.authTokenState] in
                switch authTokenState {
                case .SuccessBankCardVerification(authToken: let authToken):
                    iDenfySDKBankCardVerificationUIViewController(authToken)
                        .ignoresSafeArea()
                default:
                    EmptyView().opacity(0)
                }
            })
        }.modifier(DismissingKeyboard())
    }
}
