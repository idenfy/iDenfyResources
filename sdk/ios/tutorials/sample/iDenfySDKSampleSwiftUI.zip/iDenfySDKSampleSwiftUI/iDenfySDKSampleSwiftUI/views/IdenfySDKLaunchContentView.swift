//
//  ContentView.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 23/01/2024.
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct IdenfySDKLaunchContentView: View {

    @StateObject var viewModel = MainViewModel()
    @State var shouldNavigateToFaceAuth = false
    @State var shouldNavigateToRequestUpdate = false

    var body: some View {
        NavigationStack {
            ActivityIndicatorView(authTokenState: $viewModel.authTokenState) {
                VStack(alignment: .center, content: {
                    IdenfyToolbarUIView(backButtonHidden: true)
                    Spacer()
                    ScrollView {
                        VStack(alignment: .center, spacing: 24, content: {
                            Text("START_SCREEN_TITLE")
                                .foregroundColor(Color.black)
                                .bold()
                                .font(.title2)
                                .multilineTextAlignment(.center)
                            Text("START_SCREEN_DESCRIPTION")
                                .foregroundColor(Color.black.opacity(0.6))
                                .font(.subheadline)
                                .multilineTextAlignment(.center)
                                .padding(EdgeInsets(top: 0, leading: 32, bottom: 8, trailing: 32))
                            // Identification
                            VStack(alignment: .center, spacing: 12) {
                                Image(ImageResource(name: "idenfy_ic_identification", bundle: Bundle.main))
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .onTapGesture {
                                        viewModel.fetchIdentificationToken()
                                    }
                                Text("IDENTIFICATION_UI_MESSAGE")
                                    .foregroundColor(Color.black)
                                    .bold()
                                    .font(.subheadline)
                                    .multilineTextAlignment(.center)
                                Divider()
                                    .frame(width: 200)
                                    .overlay(Color.black.opacity(0.3))
                            }

                            // Face Authentication
                            VStack(alignment: .center, spacing: 12) {
                                Image(ImageResource(name: "idenfy_ic_face_authentication_start_image", bundle: Bundle.main))
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .onTapGesture {
                                        self.shouldNavigateToFaceAuth = true
                                    }
                                Text("FACE_AUTHENTICATION_MESSAGE")
                                    .foregroundColor(Color.black)
                                    .bold()
                                    .font(.subheadline)
                                    .multilineTextAlignment(.center)
                                Divider()
                                    .frame(width: 200)
                                    .overlay(Color.black.opacity(0.3))
                            }

                            // Request Update
                            VStack(alignment: .center, spacing: 12) {
                                Image(ImageResource(name: "idenfy_ic_identification", bundle: Bundle.main))
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .onTapGesture {
                                        self.shouldNavigateToRequestUpdate = true
                                    }
                                Text("REQUEST_UPDATE_MESSAGE")
                                    .foregroundColor(Color.black)
                                    .bold()
                                    .font(.subheadline)
                                    .multilineTextAlignment(.center)
                                Divider()
                                    .frame(width: 200)
                                    .overlay(Color.black.opacity(0.3))
                            }
                        })
                        .padding(.top, 32)
                    }
                    Spacer()
                })
                .background(Color.white)
                .fullScreenCover(isPresented: $viewModel.isIdenfySDKPresented, content: { [authTokenState = viewModel.authTokenState] in
                    switch authTokenState {
                    case .Success(let authToken):
                        iDenfySDKUIViewController(authToken.authToken!)
                            .ignoresSafeArea()
                    default:
                        EmptyView().opacity(0)
                    }
                }).navigationDestination(isPresented: $shouldNavigateToFaceAuth) {
                    FaceAuthSDKLaunchContentView()
                        .toolbar(.hidden, for: .automatic)
                }.navigationDestination(isPresented: $shouldNavigateToRequestUpdate) {
                    RequestUpdateContentView()
                        .toolbar(.hidden, for: .automatic)
                }
            }
        }
    }
}

#Preview {
    IdenfySDKLaunchContentView()
}
