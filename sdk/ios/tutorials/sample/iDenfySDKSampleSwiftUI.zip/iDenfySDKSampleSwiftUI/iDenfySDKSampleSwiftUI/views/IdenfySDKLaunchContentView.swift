//
//  ContentView.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 23/01/2024.
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct IdenfySDKLaunchContentView: View {
    
    @StateObject var viewModel = MainViewModel()
    @State var shouldNavigateToFaceAuth = false
    
    var body: some View {
        NavigationStack {
            ActivityIndicatorView(authTokenState: $viewModel.authTokenState) {
                VStack(alignment: .center, content: {
                    IdenfyToolbarUIView()
                        .frame(height: 60)
                    Spacer()
                    VStack(alignment: .center, content: {
                        HStack(alignment: .center, content: {
                            VStack(alignment: .center, content: {
                                Image(ImageResource(name: "idenfy_ic_identification", bundle: Bundle.main))
                                    .onTapGesture {
                                        viewModel.fetchIdentificationToken()
                                    }
                                    .padding(.bottom, 16)
                                Text("IDENTIFICATION_UI_MESSAGE")
                                    .foregroundColor(Color.black)
                                    .bold()
                                    .font(.subheadline)
                                    .padding(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                                    .multilineTextAlignment(.center)
                            }).frame(minWidth: 0, maxWidth: .infinity)
                            Divider()
                                .overlay(Color.black)
                                .frame(maxHeight: 250)
                            VStack(alignment: .center, content: {
                                Image(ImageResource(name: "idenfy_ic_face_authentication_start_image", bundle: Bundle.main))
                                    .onTapGesture {
                                        self.shouldNavigateToFaceAuth = true
                                    }
                                    .padding(EdgeInsets(top: 0, leading: 12, bottom: 16, trailing: 0))
                                Text("FACE_AUTHENTICATION_MESSAGE")
                                    .foregroundColor(Color.black)
                                    .bold()
                                    .font(.subheadline)
                                    .padding(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                                    .multilineTextAlignment(.center)
                            }).frame(minWidth: 0, maxWidth: .infinity)
                        })
                    })
                    .padding(.bottom, 50)
                    Spacer()
                })
                .background(Color.white)
                .fullScreenCover(isPresented: $viewModel.isIdenfySDKPresented, content: { [authTokenState = viewModel.authTokenState] in
                    switch authTokenState {
                    case .Success(let authToken):
                        iDenfySDKUIViewController(authToken.authToken!)
                            .ignoresSafeArea()
                    default:
                        EmptyView().opacity(0)
                    }
                }).navigationDestination(isPresented: $shouldNavigateToFaceAuth) {
                    FaceAuthSDKLaunchContentView()
                        .toolbar(.hidden, for: .automatic)
                }
            }
        }
    }
}

#Preview {
    IdenfySDKLaunchContentView()
}
