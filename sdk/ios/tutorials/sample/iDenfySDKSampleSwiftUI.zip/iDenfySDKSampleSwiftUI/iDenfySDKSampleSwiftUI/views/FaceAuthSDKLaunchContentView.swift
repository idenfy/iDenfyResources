//
//  FaceAuthSDKLaunchContentView.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 25/01/2024.
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct FaceAuthSDKLaunchContentView: View {
    
    @StateObject var viewModel = MainViewModel()
    
    @State private var scanRef: String = ""
    
    var body: some View {
        ActivityIndicatorView(authTokenState: $viewModel.authTokenState) {
            VStack(alignment: .center, content: {
                IdenfyToolbarUIView(backButtonHidden: false)
                    .frame(height: 60)
                    .padding(.bottom, 80)
                Text("SCAN_REF_TITLE")
                    .foregroundColor(Color.black)
                    .bold()
                    .font(.title2)
                Spacer()
                TextField("", text: $scanRef, prompt: Text("SCAN_REF_PROMPT").foregroundColor(Color.black.opacity(0.4)))
                    .textFieldStyle(.plain)
                    .frame(height: 56)
                    .padding(EdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8))
                    .overlay(RoundedRectangle(cornerRadius: 4)
                        .stroke(Color.black.opacity(0.6), lineWidth: 1))
                    .background(Color.white)
                    .foregroundColor(Color.black)
                    .padding(EdgeInsets(top: 0, leading: 32, bottom: 0, trailing: 32))
                Spacer()
                Spacer()
                Button {
                    viewModel.checkForFaceAuthToken(scanRef)
                    scanRef = ""
                } label: {
                    Text("CONTINUE_BUTTON_MESSAGE")
                        .frame(maxWidth: .infinity, minHeight: 42)
                        .bold()
                        .font(.subheadline)
                }.buttonStyle(.plain)
                    .background(LinearGradient(gradient: Gradient(colors: [Color(IdenfyCommonColors.idenfyGradientColor1V2), Color(IdenfyCommonColors.idenfyGradientColor2V2)]), startPoint: .leading, endPoint: .trailing))
                    .foregroundColor(Color.white)
                    .cornerRadius(4)
                    .opacity(scanRef.isEmpty ? 0.4 : 1)
                    .padding(EdgeInsets(top: 0, leading: 32, bottom: 16, trailing: 32))
                    .disabled(scanRef.isEmpty)
            })
            .background(Color.white)
            .fullScreenCover(isPresented: $viewModel.isIdenfySDKPresented, content: { [authTokenState = viewModel.authTokenState] in
                switch authTokenState {
                case .SuccessFaceAuth(authToken: let authToken):
                    iDenfySDKFaceAuthUIViewController(authToken)
                        .ignoresSafeArea()
                default:
                    EmptyView().opacity(0)
                }
            })
        }.modifier(DismissingKeyboard())
    }
}
