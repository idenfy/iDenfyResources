//
//  IdenfyToolbarUIView.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import SwiftUI
import idenfyviews

struct IdenfyToolbarUIView: UIViewRepresentable {
    
    func makeUIView(context: Context) -> IdenfyToolbarV2Default {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.backButton.isHidden = true
        return toolbar
    }
    
    func updateUIView(_ uiView: IdenfyToolbarV2Default, context: Context) {
    }
}
