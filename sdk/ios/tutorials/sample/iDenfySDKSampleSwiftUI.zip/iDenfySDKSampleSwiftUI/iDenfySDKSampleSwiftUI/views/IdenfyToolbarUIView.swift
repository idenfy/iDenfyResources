//
//  IdenfyToolbarUIView.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import SwiftUI

struct IdenfyToolbarUIView: View {
    
    @State private var backButtonHidden: Bool
    @Environment(\.dismiss) var dismiss
    
    init(backButtonHidden: Bool) {
        _backButtonHidden = State(initialValue: backButtonHidden)
    }
    
    var body: some View {
        ZStack(alignment: .center, content: {
            Rectangle()
                .frame(height: 60)
                .backgroundStyle(Color.white)
                .shadow(color: .gray.opacity(0.6), radius: 1, x: 0, y: 1)
            if !backButtonHidden {
                HStack {
                    Image(ImageResource(name: "idenfy_ic_navigation_back_v2", bundle: Bundle(identifier: "com.idenfy.idenfyviews")!))
                        .padding(.all, 16)
                        .onTapGesture {
                            dismiss()
                        }
                    Spacer()
                }
            }
            HStack {
                Image(ImageResource(name: "idenfy_ic_idenfy_logo_vector_v2", bundle: Bundle(identifier: "com.idenfy.idenfyviews")!))
                    .frame(width: 70.5, height: 26)
            }
        })
    }
}
