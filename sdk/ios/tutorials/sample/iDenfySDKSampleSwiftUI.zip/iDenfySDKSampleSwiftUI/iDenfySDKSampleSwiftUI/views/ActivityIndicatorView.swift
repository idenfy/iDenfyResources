//
//  LoadingView.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import SwiftUI
import idenfyviews

struct ActivityIndicatorView<Content>: View where Content: View {
    
    @Binding var authTokenState: IdenfyAuthTokenState
    var content: () -> Content
    
    var body: some View {
        switch authTokenState {
        case .Loading:
            GeometryReader { geometry in
                ZStack(alignment: .center) {
                    self.content()
                        .disabled(true)
                        .blur(radius: 3)
                    VStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, content: {
                        Text("LOADING_MESSAGE")
                            .font(.title3)
                            .multilineTextAlignment(.center)
                            .bold()
                            .foregroundColor(Color.black)
                            .padding(.bottom, 16)
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: Color(IdenfyCommonColors.idenfyMainColorV2)))
                            .scaleEffect(1.5, anchor: .center)
                    })
                    .frame(width: geometry.size.width / 1.7,
                           height: geometry.size.height / 4)
                    .background(Color.white)
                    .foregroundColor(Color.primary)
                    .cornerRadius(10)
                    .clipped()
                    .shadow(color: Color.gray, radius: 5, x: 0, y: 0)
                }
            }
        case .AuthTokenCouldNotBeReceived(let error):
            GeometryReader { geometry in
                ZStack(alignment: .center) {
                    self.content()
                        .disabled(true)
                        .blur(radius: 3)
                    VStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, content: {
                        Text(error)
                            .multilineTextAlignment(.center)
                            .font(.title3)
                            .bold()
                            .foregroundColor(Color.black)
                            .padding(.bottom, 16)
                        Image(ImageResource(name: "idenfy_ic_results_view_step_spinner_status_error_v2",
                                            bundle: Bundle(identifier: "com.idenfy.idenfyviews")!))
                    })
                    .frame(width: geometry.size.width / 1.7,
                           height: geometry.size.height / 4)
                    .background(Color.white)
                    .foregroundColor(Color.primary)
                    .cornerRadius(10)
                    .clipped()
                    .shadow(color: Color.gray, radius: 5, x: 0, y: 0)
                }
            }
        default:
            GeometryReader { geometry in
                ZStack(alignment: .center) {
                    self.content()
                        .disabled(false)
                        .blur(radius: 0)
                }
            }
        }
    }
}
