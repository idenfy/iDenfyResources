//
//  MainViewModel.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation
import iDenfySDK

@MainActor class MainViewModel: ObservableObject {
    
    @Published var authTokenState = IdenfyAuthTokenState.NotStarted
    @Published var isIdenfySDKPresented: Bool = false
    
    // Usecases
    private var getIdenfyAuthTokenUseCase = GetIdenfyAuthTokenUseCase()
    private var checkFaceAuthenticationTypeUseCase = CheckFaceAuthenticationTypeUseCase()
    private var fetchFaceAuthenticationTokenUseCase = FetchFaceAuthenticationTokenUseCase()
    
    /**
     Fetch identify verification token
     */
    func fetchIdentificationToken() {
        if authTokenState == IdenfyAuthTokenState.Loading {
            return
        }
        
        authTokenState = IdenfyAuthTokenState.Loading
        let authTokenRequestBody = AuthTokenBody(clientId: Consts.clientId)
        getIdenfyAuthTokenUseCase.execute(authTokenBody: authTokenRequestBody, success: { [weak self] token in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.authTokenState = IdenfyAuthTokenState.Success(authToken: token)
                self.isIdenfySDKPresented = true
            }
        }, failure: { [weak self] error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: error.message)
                self.isIdenfySDKPresented = false
                self.resetState()
            }
        })
    }
    
    /**
     Check face authentication state, if user can be authenticated by face
     */
    func checkForFaceAuthToken(_ scanRef: String) {
        if authTokenState == IdenfyAuthTokenState.Loading {
            return
        }
        
        authTokenState = IdenfyAuthTokenState.Loading
        checkFaceAuthenticationTypeUseCase.execute(scanRef: scanRef, success: { [weak self] response in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch response.type {
                case .authentication:
                    //The user can authenticate by face
                    self.fetchFaceAuthenticationToken(scanRef, response.type!)
                default:
                    //The user must perform an identification
                    self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: "Please perform an identification first!")
                    break
                }
            }
            
        }, failure: { [weak self] error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: error.message)
                self.isIdenfySDKPresented = false
                self.resetState()
            }
        })
    }
    
    /**
     Fetch face authentication token
     */
    private func fetchFaceAuthenticationToken(_ scanRef: String, _ type: FaceAuthenticationType) {
        fetchFaceAuthenticationTokenUseCase.execute(scanRef, type, success: { [weak self] response in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.authTokenState = IdenfyAuthTokenState.SuccessFaceAuth(authToken: response.token)
                self.isIdenfySDKPresented = true
            }
        }, failure: { [weak self] error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: error.message)
                self.isIdenfySDKPresented = false
                self.resetState()
            }
        })
    }
    
    /**
     Reset state after an error has occurred
     */
    private func resetState() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: { [weak self] in
            guard let self = self else { return }
            self.authTokenState = IdenfyAuthTokenState.NotStarted
        })
    }
    
}
