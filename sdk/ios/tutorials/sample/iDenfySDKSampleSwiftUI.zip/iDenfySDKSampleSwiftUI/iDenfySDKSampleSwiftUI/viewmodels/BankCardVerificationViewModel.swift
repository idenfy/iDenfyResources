//
//  BankCardVerificationViewModel.swift
//  iDenfySDKSampleSwiftUI
//

import Foundation
import iDenfySDK

@MainActor class BankCardVerificationViewModel: ObservableObject {

    @Published var expectedName: String = ""
    @Published var expectedLastFour: String = ""
    @Published var authTokenState = IdenfyAuthTokenState.NotStarted
    @Published var isIdenfySDKPresented: Bool = false

    private var getBankCardVerificationTokenUseCase = GetBankCardVerificationTokenUseCase()

    func fetchBankCardVerificationToken() {
        if authTokenState == IdenfyAuthTokenState.Loading {
            return
        }

        guard !expectedName.isEmpty else { return }

        authTokenState = IdenfyAuthTokenState.Loading

        getBankCardVerificationTokenUseCase.execute(
            expectedName: expectedName,
            expectedLastFour: expectedLastFour.isEmpty ? nil : expectedLastFour,
            success: { [weak self] response in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    if let token = response.tokenString {
                        self.authTokenState = IdenfyAuthTokenState.SuccessBankCardVerification(authToken: token)
                        self.isIdenfySDKPresented = true
                    } else {
                        self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: "Token not received")
                        self.isIdenfySDKPresented = false
                        self.resetState()
                    }
                }
            },
            failure: { [weak self] error in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: error.message)
                    self.isIdenfySDKPresented = false
                    self.resetState()
                }
            }
        )
    }

    private func resetState() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            guard let self = self else { return }
            self.authTokenState = IdenfyAuthTokenState.NotStarted
        }
    }
}
