//
//  RequestUpdateViewModel.swift
//  iDenfySDKSampleSwiftUI
//

import Foundation
import iDenfySDK

@MainActor class RequestUpdateViewModel: ObservableObject {

    @Published var scanRef: String = ""
    @Published var questionnaireId: String = ""
    @Published var additionalStepRequired: Bool = true
    @Published var authTokenState = IdenfyAuthTokenState.NotStarted
    @Published var isIdenfySDKPresented: Bool = false

    func callRequestUpdate() {
        if authTokenState == IdenfyAuthTokenState.Loading {
            return
        }

        guard !scanRef.isEmpty else { return }

        authTokenState = IdenfyAuthTokenState.Loading

        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret
        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let urlString = Consts.baseURL
        let url = URL(string: urlString)!
        let uploadingRequest = url.appendingPathComponent("kyc/identifications/\(scanRef)/request-information/")
        var request = APIHelper.getRequestBody(_type: "POST", _url: uploadingRequest)
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")

        var json: [String: Any] = [:]
        if !questionnaireId.isEmpty {
            json["questionnaire"] = questionnaireId
        }
        json["additionalStepUploadRequired"] = additionalStepRequired

        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        request.httpBody = jsonData

        let session = URLSession.shared

        let task = session.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }

            guard let data = data else {
                DispatchQueue.main.async {
                    self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: error?.localizedDescription ?? "Unknown error")
                    self.isIdenfySDKPresented = false
                    self.resetState()
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode >= 200, httpResponse.statusCode < 300 {
                    do {
                        let response = try JSONDecoder().decode(Throwable<RequestInformationUpdateResponse>.self, from: data)
                        if let token = response.value?.tokenString {
                            DispatchQueue.main.async {
                                self.authTokenState = IdenfyAuthTokenState.SuccessRequestUpdate(authToken: token)
                                self.isIdenfySDKPresented = true
                            }
                        } else {
                            DispatchQueue.main.async {
                                self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: "Token not received")
                                self.isIdenfySDKPresented = false
                                self.resetState()
                            }
                        }
                    } catch {
                        DispatchQueue.main.async {
                            self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: "IDENFY_SERVER_ERROR_MESSAGE".localized())
                            self.isIdenfySDKPresented = false
                            self.resetState()
                        }
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    do {
                        let idenfyError = try JSONDecoder().decode(Throwable<ErrorResponse>.self, from: data)
                        DispatchQueue.main.async {
                            self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: idenfyError.value?.message ?? "Unknown error")
                            self.isIdenfySDKPresented = false
                            self.resetState()
                        }
                    } catch {
                        DispatchQueue.main.async {
                            self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: "IDENFY_SERVER_ERROR_MESSAGE".localized())
                            self.isIdenfySDKPresented = false
                            self.resetState()
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.authTokenState = IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: "IDENFY_SERVER_ERROR_MESSAGE".localized())
                        self.isIdenfySDKPresented = false
                        self.resetState()
                    }
                }
            }
        }
        task.resume()
    }

    private func resetState() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            guard let self = self else { return }
            self.authTokenState = IdenfyAuthTokenState.NotStarted
        }
    }
}
