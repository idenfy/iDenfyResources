//
//  iDenfySDKSampleSwiftUIApp.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 23/01/2024.
//

import SwiftUI

@main
struct iDenfySDKSampleSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            IdenfySDKLaunchContentView()
        }
    }
}
