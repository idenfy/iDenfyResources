//
//  iDenfySDKRequestUpdateUIViewController.swift
//  iDenfySDKSampleSwiftUI
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct iDenfySDKRequestUpdateUIViewController: UIViewControllerRepresentable {

    let authToken: String

    init(_ token: String) {
        self.authToken = token
    }

    func makeUIViewController(context: Context) -> IdenfySDKNavigationController {
        switch Consts.sdkInitFlow {
        case .Default:
            return initializeIdenfySDKDefault(authToken: authToken)
        case .WithCustomColors:
            return initializeIdenfySDKWithCustomColors(authToken: authToken)
        case .WithCustomImplementedViews:
            return initializeIdenfySDKCustom(authToken: authToken)
        }
    }

    func updateUIViewController(_ viewController: IdenfySDKNavigationController, context: Context) {
        //update Content
    }

    private func initializeIdenfySDKDefault(authToken: String) -> IdenfySDKNavigationController {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)

        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }

    private func initializeIdenfySDKWithCustomColors(authToken: String) -> IdenfySDKNavigationController {
        let mainColor = Color.init(hexString: "9DB3B1")
        let secondaryColor = Color.init(hexString: "0C0C0B")
        let backgroundColor = Color.init(hexString: "F1F1F1")

        CustomUISettings.apply(mainColor: mainColor, secondaryColor: secondaryColor, backgroundColor: backgroundColor)

        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()

        idenfyUISettingsV2.idenfyLivenessUISettingsV2.livenessOverlayBrandingImageTintColor = mainColor

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)

        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }

    private func initializeIdenfySDKCustom(authToken: String) -> IdenfySDKNavigationController {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withSplashScreenV2View(SplashScreenV2View())
            .withQuestionnaireView(QuestionnaireViewV2())
            .withTextQuestionCellView(TextQuestionCell.self)
            .withEmailQuestionCellView(EmailQuestionCell.self)
            .withFloatQuestionCellView(FloatQuestionCell.self)
            .withIntegerQuestionCellView(IntegerQuestionCell.self)
            .withPasswordQuestionCellView(PasswordQuestionCell.self)
            .withTelQuestionCellView(TelQuestionCell.self)
            .withUrlQuestionCellView(UrlQuestionCell.self)
            .withTextAreaQuestionCellView(TextAreaQuestionCell.self)
            .withSelectQuestionCellView(SelectQuestionCell.self)
            .withSelectMultiQuestionCellView(SelectMultiQuestionCell.self)
            .withCheckBoxQuestionCellView(CheckBoxQuestionCell.self)
            .withFileQuestionCellView(FileQuestionCell.self)
            .withMultiFileQuestionCellView(MultiFileQuestionCell.self)
            .withRadioQuestionCellView(RadioQuestionCell.self)
            .withDateQuestionCellView(DateQuestionCell.self)
            .withTimeQuestionCellView(TimeQuestionCell.self)
            .withDateTimeQuestionCellView(DateTimeQuestionCell.self)
            .withCountryQuestionCellView(CountryQuestionCell.self)
            .withMultiCountryQuestionCellView(MultiCountryQuestionCell.self)
            .withLanguageSelectionView(LanguageSelectionViewV2())
            .withLanguageCellView(LanguageCell.self)
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withCameraOnBoardingInstructionDescriptionsCellView(InstructionDescriptionsCellV2.self)
            .withCameraPermissionView(CameraPermissionViewV2())
            .withUploadPhotoView(UploadPhotoViewV2())
            .withDocumentCameraView(DocumentCameraViewV2())
            .withCameraWithRectangleResultViewV2(DocumentCameraResultViewV2())
            .withPdfResultView(PdfResultViewV2())
            .withFaceCameraView(FaceCameraViewV2())
            .withCameraWithoutRectangleResultViewV2(FaceCameraResultViewV2())
            .withIdentificationSuspectedResultsView(IdentificationSuspectedResultsViewV2())
            .withAdditionalSupportView(AdditionalSupportViewV2())
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2, idenfyViewsV2: idenfyViewsV2)
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())

        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }

    private func handleSDKResults(_ idenfyController: IdenfyController) {
        idenfyController.handleIdenfyCallbacksForRequestUpdate(requestUpdateResult: {
            requestUpdateResult
            in
            print("Request Update - Status: \(requestUpdateResult.rawValue)")
            switch requestUpdateResult {
            case .EXPIRED:
                break
            case .COMPLETED:
                break
            @unknown default:
                break
            }
        })
    }
}
