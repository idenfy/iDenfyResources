//
//  iDenfySDKUIViewController.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 25/01/2024.
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct iDenfySDKUIViewController: UIViewControllerRepresentable {
    
    let authToken: String
    
    init(_ token: String) {
        self.authToken = token
    }
    
    func makeUIViewController(context: Context) -> IdenfySDKNavigationController {
        switch Consts.sdkInitFlow {
        case .Default:
            return initializeIdenfySDKDefault(authToken: authToken)
        case .WithCustomColors:
            return initializeIdenfySDKWithCustomColors(authToken: authToken)
        case .WithCustomImplementedViews:
            return initializeIdenfySDKCustom(authToken: authToken)
        }
    }
    
    func updateUIViewController(_ viewController: IdenfySDKNavigationController, context: Context) {
        //update Content
    }
    
    private func initializeIdenfySDKDefault(authToken: String) -> IdenfySDKNavigationController {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()
        
        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()
        
        let idenfyController = IdenfyController.shared
        let consoleLogging = ConsoleLoggingImpl()
        idenfyController.setIdenfyLoggingHandler(idenfyLoggingHandler: IdenfyLoggingHandlerUseCaseImpl(consoleLogging))
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func initializeIdenfySDKWithCustomColors(authToken: String) -> IdenfySDKNavigationController {
        let mainColor = Color.init(hexString: "9DB3B1")
        let secondaryColor = Color.init(hexString: "0C0C0B")
        let backgroundColor = Color.init(hexString: "F1F1F1")
        
        CustomUISettings.apply(mainColor: mainColor, secondaryColor: secondaryColor, backgroundColor: backgroundColor)
        
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()
        
        idenfyUISettingsV2.idenfyLivenessUISettingsV2.livenessOverlayBrandingImageTintColor = mainColor
        
        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()
        
        let idenfyController = IdenfyController.shared
        let consoleLogging = ConsoleLoggingImpl()
        idenfyController.setIdenfyLoggingHandler(idenfyLoggingHandler: IdenfyLoggingHandlerUseCaseImpl(consoleLogging))
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func initializeIdenfySDKCustom(authToken: String) -> IdenfySDKNavigationController {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()
        
        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()
        
        //Using custom views for additional customization
        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withSplashScreenV2View(SplashScreenV2View())
            .withPrivacyPolicyView(PrivacyPolicyViewV2())
            .withQuestionnaireView(QuestionnaireViewV2())
            .withTextQuestionCellView(TextQuestionCell.self)
            .withEmailQuestionCellView(EmailQuestionCell.self)
            .withFloatQuestionCellView(FloatQuestionCell.self)
            .withIntegerQuestionCellView(IntegerQuestionCell.self)
            .withPasswordQuestionCellView(PasswordQuestionCell.self)
            .withTelQuestionCellView(TelQuestionCell.self)
            .withUrlQuestionCellView(UrlQuestionCell.self)
            .withTextAreaQuestionCellView(TextAreaQuestionCell.self)
            .withSelectQuestionCellView(SelectQuestionCell.self)
            .withSelectMultiQuestionCellView(SelectMultiQuestionCell.self)
            .withCheckBoxQuestionCellView(CheckBoxQuestionCell.self)
            .withFileQuestionCellView(FileQuestionCell.self)
            .withRadioQuestionCellView(RadioQuestionCell.self)
            .withDateQuestionCellView(DateQuestionCell.self)
            .withTimeQuestionCellView(TimeQuestionCell.self)
            .withDateTimeQuestionCellView(DateTimeQuestionCell.self)
            .withCountryQuestionCellView(CountryQuestionCell.self)
            .withMultiCountryQuestionCellView(MultiCountryQuestionCell.self)
            .withProviderSelectionView(ProviderSelectionViewV2())
            .withProviderCellView(ProviderCell.self)
            .withProviderLoginView(ProviderLoginViewV2())
            .withMFAMethodSelectionView(MFAMethodSelectionViewV2())
            .withMFAGeneralView(MFAGeneralViewV2())
            .withMFACaptchaView(MFACaptchaViewV2())
            .withNFCRequiredView(NFCRequiredViewV2())
            .withCountryAndDocumentSelectionView(CountryAndDocumentSelectionView())
            .withIssuedCountryView(IssuedCountryViewV2())
            .withCountrySelectionView(CountrySelectionViewV2())
            .withCountryCellView(CountryCell.self)
            .withLanguageSelectionView(LanguageSelectionViewV2())
            .withLanguageCellView(LanguageCell.self)
            .withDocumentSelectionView(DocumentSelectionViewV2())
            .withDocumentCellView(DocumentCell.self)
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withCameraOnBoardingInstructionDescriptionsCellView(InstructionDescriptionsCellV2.self)
            .withCameraPermissionView(CameraPermissionViewV2())
            .withUploadPhotoView(UploadPhotoViewV2())
            .withDocumentCameraView(DocumentCameraViewV2())
            .withCameraWithRectangleResultViewV2(DocumentCameraResultViewV2())
            .withPdfResultView(PdfResultViewV2())
            .withFaceCameraView(FaceCameraViewV2())
            .withCameraWithoutRectangleResultViewV2(FaceCameraResultViewV2())
            .withNFCReadingView(NFCReadingViewV2())
            .withNFCReadingTimeOutView(NFCReadingTimeOutViewV2())
            .withIdentificationResultsView(IdentificationResultsViewV2())
            .withIdentificationResultsStepCellView(ResultsStepCell.self)
            .withIdentificationSuccessResultsView(IdentificationSuccessResultsViewV2())
            .withIdentificationSuspectedResultsView(IdentificationSuspectedResultsViewV2())
            .withManualReviewingStatusWaitingView(ManualReviewingStatusWaitingViewV2())
            .withManualReviewingStatusFailedView(ManualReviewingStatusFailedViewV2())
            .withManualReviewingStatusApprovedView(ManualReviewingStatusApprovedViewV2())
            .withAdditionalSupportView(AdditionalSupportViewV2())
            .withFaceAuthenticationSplashScreenV2View(FaceAuthenticationSplashScreenV2View())
            .withFaceAuthenticationResultsViewV2(FaceAuthenticationResultsViewV2())
            .withBankVerificationViewV2(BankVerificationViewV2())
            .withBankSelectionCellViewV2(BankCell.self)
            .build()
        
        let idenfyController = IdenfyController.shared
        let consoleLogging = ConsoleLoggingImpl()
        idenfyController.setIdenfyLoggingHandler(idenfyLoggingHandler: IdenfyLoggingHandlerUseCaseImpl(consoleLogging))
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2, idenfyViewsV2: idenfyViewsV2)
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func handleSDKResults(_ idenfyController: IdenfyController) {
        idenfyController.getIdenfyResultWithDismiss(idenfyIdentificationResult: {
            idenfyIdentificationResult
            in
            print("Auto: \(idenfyIdentificationResult.autoIdentificationStatus.rawValue), Manual: \(idenfyIdentificationResult.manualIdentificationStatus.rawValue)")
            switch idenfyIdentificationResult.autoIdentificationStatus {
            case .APPROVED:
                // The user completed an identification flow and the identification status, provided by an automated platform, is APPROVED.
                break
            case .FAILED:
                // The user completed an identification flow and the identification status, provided by an automated platform, is FAILED.
                break
            case .UNVERIFIED:
                // The user did not complete an identification flow and the identification status, provided by an automated platform, is UNVERIFIED.
                break
            @unknown default:
                break
            }
            
            switch idenfyIdentificationResult.manualIdentificationStatus {
            case .APPROVED:
                // The user completed an identification flow and was verified manually while waiting for the manual verification results in the iDenfy SDK. The identification status, provided by a manual review, is APPROVED.
                break
            case .FAILED:
                // The user completed an identification flow and was verified manually while waiting for the manual verification results in the iDenfy SDK. The identification status, provided by a manual review, is FAILED.
                break
                
            case .WAITING:
                // The user completed an identification flow and started waiting for the manual verification results in the iDenfy SDK. Then he/she decided to stop waiting and pressed a "BACK TO ACCOUNT" button. The manual identification review is still ongoing.
                break
                
            case .INACTIVE:
                // The user was only verified by an automated platform, not by a manual reviewer. The identification performed by the user can still be verified by the manual review if your system uses the manual verification service.
                break
            @unknown default:
                break
            }
            
        })
    }
}
