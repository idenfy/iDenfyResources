//
//  iDenfySDKBankCardVerificationUIViewController.swift
//  iDenfySDKSampleSwiftUI
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct iDenfySDKBankCardVerificationUIViewController: UIViewControllerRepresentable {

    let authToken: String

    init(_ token: String) {
        self.authToken = token
    }

    func makeUIViewController(context: Context) -> IdenfySDKNavigationController {
        switch Consts.sdkInitFlow {
        case .Default:
            return initializeBankCardVerificationDefault(authToken: authToken)
        case .WithCustomColors:
            return initializeBankCardVerificationWithCustomColors(authToken: authToken)
        case .WithCustomImplementedViews:
            return initializeBankCardVerificationDefault(authToken: authToken)
        }
    }

    func updateUIViewController(_ viewController: IdenfySDKNavigationController, context: Context) {
        //update Content
    }

    private func initializeBankCardVerificationDefault(authToken: String) -> IdenfySDKNavigationController {
        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())

        let bankCardVerificationInitialization = BankCardVerificationInitialization(bankCardVerificationToken: authToken)
        idenfyController.initializeBankCardVerification(bankCardVerificationInitialization: bankCardVerificationInitialization)

        handleBankCardVerificationResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }

    private func initializeBankCardVerificationWithCustomColors(authToken: String) -> IdenfySDKNavigationController {
        let mainColor = Color.init(hexString: "6AA82F")
        let secondaryColor = Color.init(hexString: "000000")
        let backgroundColor = Color.init(hexString: "FFFFFF")

        CustomUISettings.apply(mainColor: mainColor, secondaryColor: secondaryColor, backgroundColor: backgroundColor)

        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())

        let bankCardVerificationInitialization = BankCardVerificationInitialization(bankCardVerificationToken: authToken)
        idenfyController.initializeBankCardVerification(bankCardVerificationInitialization: bankCardVerificationInitialization)

        handleBankCardVerificationResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }

    private func handleBankCardVerificationResults(_ idenfyController: IdenfyController) {
        idenfyController.handleIdenfyCallbacksForBankCardVerification(bankCardVerificationResult: {
            bankCardVerificationResult
            in
            print("BCV Status: \(bankCardVerificationResult.bankCardVerificationStatus.rawValue)")
            switch bankCardVerificationResult.bankCardVerificationStatus {
            case .SUCCESS:
                break
            case .FAILED:
                break
            case .EXIT:
                break
            @unknown default:
                break
            }
        })
    }
}
