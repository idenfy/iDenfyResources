//
//  iDenfySDKFaceAuthUIViewController.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct iDenfySDKFaceAuthUIViewController: UIViewControllerRepresentable {
    
    let authenticationToken: String
    
    init(_ token: String) {
        self.authenticationToken = token
    }
    
    func makeUIViewController(context: Context) -> IdenfySDKNavigationController {
        switch Consts.sdkInitFlow {
        case .Default:
            return startFaceAuthentication(authenticationToken)
        case .CustomWithImplementedViews:
            return startFaceAuthenticationWithCustomViews(authenticationToken)
        }
    }
    
    func updateUIViewController(_ viewController: IdenfySDKNavigationController, context: Context) {
        //update Content
    }
    
    private func startFaceAuthentication(_ authenticationToken: String) -> IdenfySDKNavigationController {
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func startFaceAuthenticationWithCustomViews(_ authenticationToken: String) -> IdenfySDKNavigationController {
        //Changing UI with main colors
        IdenfyCommonColors.idenfyMainColorV2 = Color.init(hexString: "A50000")
        IdenfyCommonColors.idenfyMainDarkerColorV2 = Color.init(hexString: "820000")
        IdenfyCommonColors.idenfyBackgroundColorV2 = Color.init(hexString: "1A1A1A")
        IdenfyCommonColors.idenfyGradientColor1V2 = Color.init(hexString: "A50000")
        IdenfyCommonColors.idenfyGradientColor2V2 = Color.init(hexString: "820000")
        IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart = Color.init(hexString: "A50000")
        IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd = Color.init(hexString: "820000")
        IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2 = IdenfyCommonColors.idenfyErrorLightRedColorV2
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarBackIconTintColor = Color.init(hexString: "A50000")
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarLogoIconTintColor = Color.init(hexString: "A50000")
        IdenfyDrawerUISettingsV2.idenfyDrawerBackButtonTintColor = .white
        IdenfyCommonColors.idenfySecondColorV2 = .white
        IdenfyCommonColors.idenfyWhite = .black
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarBackgroundColor = Color.init(hexString: "1A1A1A")
        IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionTextColor = .white
        IdenfyDrawerUISettingsV2.idenfyDrawerTitleTextColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = .white.withAlphaComponent(0.6)
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionSwitchLensButtonTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionFaceOvalColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionTakePhotoButtonFocusedTintColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionToggleFlashButtonTintColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessioninstructionDialogButtonTintColor = .white
        IdenfyLoadingHUDUISettingsV2.idenfyLoadingHUDTitleColor = .white
        IdenfyLoadingHUDUISettingsV2.idenfyLoadingHUDDescriptionColor = .white
        
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        
        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withFaceAuthenticationSplashScreenV2View(FaceAuthenticationSplashScreenV2View())
            .build()
        
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization, idenfyViewsV2: idenfyViewsV2)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func handleSDKResults(_ idenfyController: IdenfyController) {
        idenfyController.handleIdenfyCallbacksForFaceAuthentication(faceAuthenticationResult: { faceAuthenticationResult in
            print("FaceAuthenticationStatus: ", faceAuthenticationResult.faceAuthenticationStatus.rawValue)
            switch faceAuthenticationResult.faceAuthenticationStatus {
            case .SUCCESS:
                // The user completed authentication flow, was successfully authenticated
                break
            case .FAILED:
                // The user completed authentication flow, was not successfully authenticated
                break
            case .EXIT:
                // The user did not complete authentication flow
                break
            @unknown default:
                break
            }
        })
    }
}

