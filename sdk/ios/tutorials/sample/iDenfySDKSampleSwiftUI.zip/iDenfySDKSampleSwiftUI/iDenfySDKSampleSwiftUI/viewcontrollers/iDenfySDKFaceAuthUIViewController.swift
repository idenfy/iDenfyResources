//
//  iDenfySDKFaceAuthUIViewController.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import SwiftUI
import iDenfySDK
import idenfyviews

struct iDenfySDKFaceAuthUIViewController: UIViewControllerRepresentable {
    
    let authenticationToken: String
    
    init(_ token: String) {
        self.authenticationToken = token
    }
    
    func makeUIViewController(context: Context) -> IdenfySDKNavigationController {
        switch Consts.sdkInitFlow {
        case .Default:
            return startFaceAuthentication(authenticationToken)
        case .WithCustomColors:
            return startFaceAuhtenticationWithCustomColors(authenticationToken)
        case .WithCustomImplementedViews:
            return startFaceAuthenticationWithCustomViews(authenticationToken)
        }
    }
    
    func updateUIViewController(_ viewController: IdenfySDKNavigationController, context: Context) {
        //update Content
    }
    
    private func startFaceAuthentication(_ authenticationToken: String) -> IdenfySDKNavigationController {
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func startFaceAuhtenticationWithCustomColors(_ authenticationToken: String) -> IdenfySDKNavigationController {
        let mainColor = Color.init(hexString: "6AA82F")
        let secondaryColor = Color.init(hexString: "000000")
        let backgroundColor = Color.init(hexString: "FFFFFF")
        
        CustomUISettings.apply(mainColor: mainColor, secondaryColor: secondaryColor, backgroundColor: backgroundColor)
        
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func startFaceAuthenticationWithCustomViews(_ authenticationToken: String) -> IdenfySDKNavigationController {
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        
        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withFaceAuthenticationSplashScreenV2View(FaceAuthenticationSplashScreenV2View())
            .build()
        
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization, idenfyViewsV2: idenfyViewsV2)
        
        handleSDKResults(idenfyController)
        return idenfyController.instantiateNavigationController()
    }
    
    private func handleSDKResults(_ idenfyController: IdenfyController) {
        idenfyController.handleIdenfyCallbacksForFaceAuthentication(faceAuthenticationResult: { faceAuthenticationResult in
            print("FaceAuthenticationStatus: ", faceAuthenticationResult.faceAuthenticationStatus.rawValue)
            switch faceAuthenticationResult.faceAuthenticationStatus {
            case .SUCCESS:
                // The user completed authentication flow, was successfully authenticated
                break
            case .FAILED:
                // The user completed authentication flow, was not successfully authenticated
                break
            case .EXIT:
                // The user did not complete authentication flow
                break
            @unknown default:
                break
            }
        })
    }
}

