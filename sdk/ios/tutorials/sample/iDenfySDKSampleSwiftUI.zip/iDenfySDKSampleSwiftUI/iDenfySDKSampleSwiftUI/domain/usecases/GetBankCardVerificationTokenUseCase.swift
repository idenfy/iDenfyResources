//
//  GetBankCardVerificationTokenUseCase.swift
//  iDenfySDKSampleSwiftUI
//

import Foundation

class GetBankCardVerificationTokenUseCase {

    func execute(expectedName: String, expectedLastFour: String?, success: @escaping (BankCardVerificationTokenResponse) -> Void, failure: @escaping (ErrorResponse) -> Void) {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret
        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let urlString = Consts.baseURL
        let url = URL(string: urlString)!
        let uploadingRequest = url.appendingPathComponent("bank-card/tokens/")
        var request = APIHelper.getRequestBody(_type: "POST", _url: uploadingRequest)
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")

        var json: [String: Any] = [:]
        json["expectedName"] = expectedName
        json["sessionLength"] = 600
        if let lastFour = expectedLastFour, !lastFour.isEmpty {
            json["expectedLastFour"] = lastFour
        }

        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        request.httpBody = jsonData

        let session = URLSession.shared

        let task = session.dataTask(with: request) { data, response, error in
            guard let data = data else {
                failure(ErrorResponse(message: error?.localizedDescription ?? "Unknown error"))
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode >= 200, httpResponse.statusCode < 300 {
                    do {
                        let response = try JSONDecoder().decode(Throwable<BankCardVerificationTokenResponse>.self, from: data)
                        if let value = response.value {
                            success(value)
                        } else {
                            failure(ErrorResponse(message: "Token not received"))
                        }
                    } catch {
                        failure(ErrorResponse(message: "IDENFY_SERVER_ERROR_MESSAGE".localized()))
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    do {
                        let idenfyError = try JSONDecoder().decode(Throwable<ErrorResponse>.self, from: data)
                        failure(idenfyError.value ?? ErrorResponse(message: "Unknown error"))
                    } catch {
                        failure(ErrorResponse(message: "IDENFY_SERVER_ERROR_MESSAGE".localized()))
                    }
                } else {
                    failure(ErrorResponse(message: "IDENFY_SERVER_ERROR_MESSAGE".localized()))
                }
            }
        }
        task.resume()
    }
}
