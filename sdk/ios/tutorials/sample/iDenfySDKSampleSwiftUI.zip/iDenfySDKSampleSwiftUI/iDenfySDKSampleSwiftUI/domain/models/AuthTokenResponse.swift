//
//  AuthTokenResponse.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

struct AuthTokenResponse: Codable {
    let authToken: String?
}
