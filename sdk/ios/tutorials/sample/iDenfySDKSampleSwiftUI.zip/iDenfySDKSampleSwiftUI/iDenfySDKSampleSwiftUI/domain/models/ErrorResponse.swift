//
//  ErrorResponse.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

@objc public class ErrorResponse: NSObject,
    Codable {
    public var message: String
    public var identifier: String?
    public var severity: String?

    init(message: String) {
        self.message = message
    }
}
