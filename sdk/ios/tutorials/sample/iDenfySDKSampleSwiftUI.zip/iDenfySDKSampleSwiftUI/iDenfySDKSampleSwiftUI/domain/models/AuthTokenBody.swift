//
//  AuthTokenBody.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

struct AuthTokenBody: Codable {
    let clientId: String
    var firstName: String? = nil
    var lastName: String? = nil
    var country: String? = nil
}
