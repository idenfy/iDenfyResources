//
//  CheckFaceAuthenticationTypeUseCase.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation

class CheckFaceAuthenticationTypeUseCase {
    
    func execute(scanRef: String, success: @escaping (FaceAuthenticationTypeResponse) -> Void,
                 failure: @escaping (ErrorResponse) -> Void) {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret

        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let config = URLSessionConfiguration.default
        config.isDiscretionary = true
        config.shouldUseExtendedBackgroundIdleMode = true
        
        let session = URLSession(configuration: config)
        
        let urlString = Consts.baseURL
        
        let endpoint = "identification/facial-auth/\(scanRef)/check-status/?method=FACE_MATCHING"
        let url = URL(string: urlString + endpoint)!
        var request = APIHelper.getRequestBody(_type: "GET", _url: url)
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        
        let task = session.dataTask(with: request, completionHandler: { data, response, _ in

            guard let data = data else {
                let idefyError = ErrorResponse(message:
                    "IDENFY_SERVER_ERROR_MESSAGE".localized())
                failure(idefyError)
                return
            }

            let outputStr = String(data: data, encoding: String.Encoding.utf8) as String?
            debugPrint(outputStr ?? "")
            print(data.debugDescription)

            if let httpResponse = response as? HTTPURLResponse {
                debugPrint(httpResponse)

                if httpResponse.statusCode == 200 {
                    do {
                        let idenfyErrror = try JSONDecoder().decode(Throwable<FaceAuthenticationTypeResponse>.self, from: data)
                        success(idenfyErrror.value!)
                    } catch {
                        let idefyError = ErrorResponse(message:
                            "IDENFY_SERVER_ERROR_MESSAGE".localized())
                        failure(idefyError)
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    let idefyError = ErrorResponse(message:
                        "IDENFY_SERVER_ERROR_MESSAGE".localized())
                    failure(idefyError)
                } else {
                    let idefyError = ErrorResponse(message:
                        "IDENFY_SERVER_ERROR_MESSAGE".localized())
                    failure(idefyError)
                }
            }
        })
        task.resume()
    }
}
