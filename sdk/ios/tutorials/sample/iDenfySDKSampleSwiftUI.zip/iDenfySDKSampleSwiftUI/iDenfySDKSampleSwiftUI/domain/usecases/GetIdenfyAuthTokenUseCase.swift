//
//  GetIdenfyAuthTokenUseCase.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

class GetIdenfyAuthTokenUseCase {

    func execute(authTokenBody: AuthTokenBody, success _success: @escaping (AuthTokenResponse) -> Void,
                 failure _failure: @escaping (ErrorResponse) -> Void) {
        let success: (AuthTokenResponse) -> Void = { AuthToken in
            DispatchQueue.main.async {
                _success(AuthToken)
            }
        }
        let failure: (ErrorResponse) -> Void = { error in
            DispatchQueue.main.async {
                _failure(error)
            }
        }
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret

        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let urlString = Consts.baseURL

        let url = URL(string: urlString)!
        let uploadingRequest = url.appendingPathComponent("api/v2/token")
        var request = APIHelper.getRequestBody(_type: "POST", _url: uploadingRequest)

        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        var json: [String: Any] = [:]

        json.updateValue(authTokenBody.clientId, forKey: "clientId")

        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        request.httpBody = jsonData

        let session = URLSession.shared

        let task = session.dataTask(with: request, completionHandler: { data, response, error in

            guard let data = data else {
                let idefyError = ErrorResponse(message:
                    error.debugDescription)

                failure(idefyError)
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode >= 200, httpResponse.statusCode < 300 {
                    do {
                        let response = try JSONDecoder().decode(Throwable<AuthTokenResponse>.self, from: data)
                        success(response.value!)
                    } catch {
                        let idefyError = ErrorResponse(message:
                            "IDENFY_SERVER_ERROR_MESSAGE".localized())

                        failure(idefyError)
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    do {
                        let idenfyErrror = try JSONDecoder().decode(Throwable<ErrorResponse>.self, from: data)

                        failure(idenfyErrror.value!)
                    } catch {
                        let idefyError = ErrorResponse(message:
                            "IDENFY_SERVER_ERROR_MESSAGE".localized())
                        failure(idefyError)
                    }
                } else {
                    let idefyError = ErrorResponse(message: "IDENFY_SERVER_ERROR_MESSAGE".localized())
                    failure(idefyError)
                }
            }
           })
        task.resume()
    }
}
