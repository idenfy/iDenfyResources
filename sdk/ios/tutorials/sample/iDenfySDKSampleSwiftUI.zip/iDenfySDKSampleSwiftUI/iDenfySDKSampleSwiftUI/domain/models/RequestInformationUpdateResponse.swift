//
//  RequestInformationUpdateResponse.swift
//  iDenfySDKSampleSwiftUI
//

import Foundation

struct RequestInformationUpdateResponse: Codable {
    let tokenString: String?
}
