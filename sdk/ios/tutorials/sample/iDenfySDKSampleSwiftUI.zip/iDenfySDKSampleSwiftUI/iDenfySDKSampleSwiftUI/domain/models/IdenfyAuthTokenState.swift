//
//  IdenfyAuthTokenState.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

enum IdenfyAuthTokenState: Equatable {
    case NotStarted
    case Loading
    case AuthTokenCouldNotBeReceived(error: String)
    case Success(authToken: AuthTokenResponse)
    case SuccessFaceAuth(authToken: String)
    
    static func == (lhs: IdenfyAuthTokenState, rhs: IdenfyAuthTokenState) -> Bool {
        switch (lhs, rhs) {
        case (.NotStarted, .NotStarted):
            return true
        case (.Loading, .Loading):
            return true
        case (.AuthTokenCouldNotBeReceived, .AuthTokenCouldNotBeReceived):
            return true
        case (.Success(authToken: let tokenLhs), .Success(authToken: let tokenRhs)):
            return tokenLhs.authToken == tokenRhs.authToken
        case (.SuccessFaceAuth(authToken: let tokenLhs), .SuccessFaceAuth(authToken: let tokenRhs)):
            return tokenLhs == tokenRhs
        default:
            return false
        }
    }
}
