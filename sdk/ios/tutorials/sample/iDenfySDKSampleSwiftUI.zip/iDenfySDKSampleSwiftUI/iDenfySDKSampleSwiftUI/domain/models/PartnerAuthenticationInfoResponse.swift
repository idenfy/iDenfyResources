//
//  PartnerAuthenticationInfoResponse.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation

struct PartnerAuthenticationInfoResponse: Codable {
    let token: String
}
