//
//  FaceAuthenticationTypeResponse.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation
import iDenfySDK

struct FaceAuthenticationTypeResponse: Codable {
    let type: FaceAuthenticationType?
}
