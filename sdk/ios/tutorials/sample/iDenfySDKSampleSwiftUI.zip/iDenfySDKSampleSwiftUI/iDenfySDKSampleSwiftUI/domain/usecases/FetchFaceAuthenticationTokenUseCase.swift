//
//  FetchFaceAuthenticationTokenUseCase.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 09/02/2024.
//

import Foundation
import iDenfySDK

class FetchFaceAuthenticationTokenUseCase {
    
    func execute(_ scanRef: String, _ type: FaceAuthenticationType, success: @escaping (PartnerAuthenticationInfoResponse) -> Void,
                 failure: @escaping (ErrorResponse) -> Void) {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret

        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let config = URLSessionConfiguration.default
        config.isDiscretionary = true
        config.shouldUseExtendedBackgroundIdleMode = true
        let session = URLSession(configuration: config)
        
        let urlString = Consts.baseURL
        
        let url = URL(string: urlString)!
        let uploadingRequest = url.appendingPathComponent("partner/authentication-info")
        var request = APIHelper.getRequestBody(_type: "POST", _url: uploadingRequest)

        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        var json: [String: Any] = [:]
        json.updateValue(scanRef, forKey: "scanRef")
        json.updateValue(type.rawValue, forKey: "type")
        json.updateValue("FACE_MATCHING", forKey: "method")
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        request.httpBody = jsonData

        let task = session.dataTask(with: request, completionHandler: { data, response, _ in

            guard let data = data else {
                let idefyError = ErrorResponse(message:
                    "IDENFY_SERVER_ERROR_MESSAGE".localized())
                failure(idefyError)
                return
            }

            let outputStr = String(data: data, encoding: String.Encoding.utf8) as String?
            debugPrint(outputStr ?? "")
            print(data.debugDescription)

            if let httpResponse = response as? HTTPURLResponse {
                debugPrint(httpResponse)

                if httpResponse.statusCode == 200 {
                    do {
                        let idenfyErrror = try JSONDecoder().decode(Throwable<PartnerAuthenticationInfoResponse>.self, from: data)
                        success(idenfyErrror.value!)
                    } catch {
                        let idefyError = ErrorResponse(message:
                            "IDENFY_SERVER_ERROR_MESSAGE".localized())
                        failure(idefyError)
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    let idefyError = ErrorResponse(message:
                        "IDENFY_SERVER_ERROR_MESSAGE".localized())
                    failure(idefyError)
                } else {
                    let idefyError = ErrorResponse(message:
                        "IDENFY_SERVER_ERROR_MESSAGE".localized())
                    failure(idefyError)
                }
            }
        })
        task.resume()
    }
}
