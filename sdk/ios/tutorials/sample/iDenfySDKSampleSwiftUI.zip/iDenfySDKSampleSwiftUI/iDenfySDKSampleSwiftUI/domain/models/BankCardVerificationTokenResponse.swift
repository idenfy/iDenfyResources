//
//  BankCardVerificationTokenResponse.swift
//  iDenfySDKSampleSwiftUI
//

import Foundation

struct BankCardVerificationTokenResponse: Decodable {
    let tokenString: String?
}
