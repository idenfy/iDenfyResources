//
//  Throwable.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

extension Throwable {
    public var value: T? {
        switch self {
        case let .success(value):
            return value
        case .failure:
            return nil
        }
    }
}

public enum Throwable<T: Decodable>: Decodable {
    case failure(Error)
    case success(T)

    public init(from decoder: Decoder) throws {
        do {
            let decoded = try T(from: decoder)
            self = .success(decoded)
        } catch {
            self = .failure(error)
        }
    }
}
