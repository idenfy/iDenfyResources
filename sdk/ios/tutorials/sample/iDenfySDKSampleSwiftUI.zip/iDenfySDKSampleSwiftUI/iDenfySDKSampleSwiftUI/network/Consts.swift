//
//  Consts.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

/**
  More about generating token: https://documentation.idenfy.com/KYC/GeneratingIdentificationToken
 */
struct Consts {
    static let baseURL = "https://ivs.idenfy.com/"
    static let apiKey = "ZLn6KwSVCfl"
    static let apiSecret = "mQUHKNz0ZKEyzQAe3OBn"
    static let clientId = "IdenfySampleClientID"
    static let sdkInitFlow: SDKInitFlow = SDKInitFlow.Default
}

enum SDKInitFlow {
    case Default
    case WithCustomImplementedViews
    case WithCustomColors
}

