//
//  Consts.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

/**
  More about generating token: https://documentation.idenfy.com/API/GeneratingIdentificationToken
 */
struct Consts {
    static let baseURL = "https://ivs.idenfy.com/"
    static let apiKey = "PUT_YOUR_IDENFY_API_KEY_HERE"
    static let apiSecret = "PUT_YOUR_IDENFY_API_SECRET_HERE"
    static let clientId = "IdenfySampleClientID"
    static let sdkInitFlow: SDKInitFlow = SDKInitFlow.Default
}

enum SDKInitFlow {
    case Default
    case CustomWithImplementedViews
}
