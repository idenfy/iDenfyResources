//
//  APIHelper.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation

class APIHelper {

    static func getRequestBody(_type: String, _url: URL) -> URLRequest {
        var request = URLRequest(url: _url)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 300

        request.httpMethod = _type
        return request
    }
}
