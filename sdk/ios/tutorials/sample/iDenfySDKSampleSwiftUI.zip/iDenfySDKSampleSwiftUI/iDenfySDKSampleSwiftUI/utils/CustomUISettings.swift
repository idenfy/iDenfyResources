//
//  CustomUISettings.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 19/03/2026.
//  Copyright © 2026 Viktor Vostrikov. All rights reserved.
//

import Foundation
import iDenfySDK
import idenfyviews
import IdenfyLiveness

@MainActor class CustomUISettings {
    
    static func apply(mainColor: UIColor, secondaryColor: UIColor, backgroundColor: UIColor) {
        // Changing custom font
//        ConstsIdenfyFonts.customFontBoldFileName = "Custom-Bold.ttf"
//        ConstsIdenfyFonts.customFontSemiBoldFileName = "Custom-SemiBold.ttf"
//        ConstsIdenfyFonts.customFontRegularFileName = "Custom-Regular.ttf"
        
        // Changing UI with main colors
        IdenfyCommonColors.idenfyMainColorV2 = mainColor
        IdenfyCommonColors.idenfyMainDarkerColorV2 = mainColor
        IdenfyCommonColors.idenfyGradientColor1V2 = mainColor
        IdenfyCommonColors.idenfyGradientColor2V2 = mainColor
        IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart = mainColor
        IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd = mainColor
        
        // Text color
        IdenfyCommonColors.idenfySecondColorV2 = secondaryColor
        
        // Background color
        IdenfyCommonColors.idenfyBackgroundColorV2 = backgroundColor
        
        // Country Document Selection colors
        IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedTextColor = secondaryColor
        IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedBorderColor = secondaryColor
        IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedBackgroundColor = mainColor
        
        // Toolbar & logo colors
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarBackIconTintColor = secondaryColor
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarLogoIconTintColor = secondaryColor
        IdenfyToolbarUISettingsV2.idenfyLanguageSelectionToolbarCloseIconTintColor = secondaryColor
        IdenfyToolbarUISettingsV2.idenfyCameraPreviewSessionToolbarBackIconTintColor = secondaryColor
        IdenfyToolbarUISettingsV2.idenfyLanguageSelectionToolbarLanguageSelectionIconTintColor = secondaryColor
        // To change toolbar logo size
        // IdenfyToolbarUISettingsV2.idenfyLogoHeight = 90.0
        // IdenfyToolbarUISettingsV2.idenfyLogoWidth = 100.0
        
        // Camera button colors
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = mainColor
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = mainColor
        
        // Photo result cards color
        IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewRetakePhotoButtonTextColor = secondaryColor
        IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewContinueButtonTextColor = secondaryColor
        IdenfyPhotoResultViewUISettingsV2.idenfyPhotoResultViewDetailsCardTitleColor = secondaryColor
        
        // Continue button text
        IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewBeginIdentificationButtonTextColor = secondaryColor
        IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonEnabledTextColor = secondaryColor
        IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonDisabledTextColor = secondaryColor
        IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingEnabledContinueButtonTextColor = secondaryColor
        IdenfyStaticCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonTextColor = secondaryColor
        IdenfyManualReviewingStatusFailedViewUISettingsV2.idenfyManualReviewingStatusFailedContinueButtonTextColor = secondaryColor
        IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingStopWaitingButtonTextColor = secondaryColor
        IdenfyManualReviewingStatusApprovedViewUISettingsV2.idenfyManualReviewingStatusApprovedContinueButtonTextColor = secondaryColor
        IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewContinueButtonTextColor = secondaryColor
        IdenfyIdentificationResultsViewUISettingsV2.idenfyIdentificationResultsViewRetakeButtonTextColor = secondaryColor
        IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewContinueButtonTextColor = secondaryColor
        IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyAgreeButtonTextColor = secondaryColor
        IdenfyGlareAndBlurAlertUISettigsV2.idenfyGlareAndBlurAlertCommonInformationTitleTextColor = secondaryColor
        IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewContinueButtonEnabledTextColor = secondaryColor
        IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewContinueButtonDisabledTextColor = secondaryColor
        
        // Camera & drawer
        IdenfyDrawerUISettingsV2.idenfyDrawerBackButtonTintColor = .white
        IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionTextColor = .white
        IdenfyDrawerUISettingsV2.idenfyDrawerTitleTextColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = .white.withAlphaComponent(0.6)
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionSwitchLensButtonTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionFaceOvalColor = .white
        
        // Loading HUD text
        IdenfyLoadingHUDUISettingsV2.idenfyLoadingHUDTitleColor = .white
        IdenfyLoadingHUDUISettingsV2.idenfyLoadingHUDDescriptionColor = .white
        
        // Identification results spinners
        IdenfyIdentificationResultsViewUISettingsV2.idenfyIdentificationResultsViewDocumentStepLoadingSpinnerAccentColor = mainColor
        
        // Selected cells text color
        IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewCellHighlightedTextColor = secondaryColor
        IdenfyCountrySelectionViewUISettingsV2.idenfyCountrySelectionViewCountryTableViewCellHighlightedTextColor = secondaryColor
        IdenfyManualReviewingStatusWaitingViewUISettingsV2.idenfyManualReviewingStatusWaitingCompletedStepTitleColor = secondaryColor
    }
}
