//
//  Extensions.swift
//  iDenfySDKSampleSwiftUI
//
//  Created by Viktas Juškys on 24/01/2024.
//

import Foundation
import SwiftUI

extension UIImageView {
    func setImageColor(_ color: UIColor?) {
        guard let unwrappedColor = color else { return }
        let templateImage = image?.withRenderingMode(.alwaysTemplate)
        image = templateImage
        tintColor = unwrappedColor
    }
}

extension String {
    func localized(_: String? = nil) -> String {
        let appBundle = Bundle.main
        let localizedString = NSLocalizedString(self, tableName: nil, bundle: appBundle, value: "", comment: "")
        return localizedString
    }
}

extension Binding {
    func map<NewValue>(_ transform: @escaping (Value) -> NewValue) -> Binding<NewValue> {
        Binding<NewValue>(get: { transform(wrappedValue) }, set: { _ in })
    }
}

struct DismissingKeyboard: ViewModifier {
    func body(content: Content) -> some View {
        content
            .onTapGesture {
                let keyWindow = UIApplication.shared.connectedScenes
                        .filter({$0.activationState == .foregroundActive})
                        .map({$0 as? UIWindowScene})
                        .compactMap({$0})
                        .first?.windows
                        .filter({$0.isKeyWindow}).first
                keyWindow?.endEditing(true)
        }
    }
}
