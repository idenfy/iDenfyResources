//
//  PartnerAuthenticationInfoResponse.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 2022-07-05.
//  Copyright © 2022 Viktor Vostrikov. All rights reserved.
//

import Foundation

struct PartnerAuthenticationInfoResponse: Codable {
    let token: String
}
