//
//  FaceAuthenticationTypeResponse.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 2022-08-22.
//  Copyright © 2022 Viktor Vostrikov. All rights reserved.
//

import Foundation
import iDenfySDK

struct FaceAuthenticationTypeResponse: Codable {
    let type: FaceAuthenticationType?
}
