//
//  AuthTokenBody.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import Foundation
struct AuthTokenBody: Codable {
    let clientId: String
    var firstName: String? = nil
    var lastName: String? = nil
    var country: String? = nil
}
