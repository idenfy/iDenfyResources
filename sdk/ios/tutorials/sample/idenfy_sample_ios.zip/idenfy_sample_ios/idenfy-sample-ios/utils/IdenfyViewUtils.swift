//
//  IdenfyViewsUtils.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import Foundation
import UIKit

class IdenfyViewUtils {
    static let identifier = "com.idenfy.idenfyviews"

    static func getImage(_ name: String) -> UIImage {
        var image: UIImage?

        if let imageFromAssets = UIImage(named: name, in: Bundle.main, compatibleWith: nil) {
            image = imageFromAssets
        } else {
            image = UIImage(named: name, in: Bundle(identifier: identifier
            ), compatibleWith: nil)
        }
        return image!
    }
}
