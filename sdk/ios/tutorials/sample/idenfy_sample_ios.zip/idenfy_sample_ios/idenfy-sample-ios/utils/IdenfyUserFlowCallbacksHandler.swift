//
//  IdenfyUserFlowCallbacksHandler.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 2023-07-25.
//  Copyright © 2023 Viktor Vostrikov. All rights reserved.
//

import Foundation
import iDenfySDK

@objc public class IdenfyUserFlowCallbacksHandler: NSObject, IdenfyUserFlowHandler {
    public func onPhotoUploaded(photo: String, step: String) {
        print("IdenfyUserFlowHandler - onPhotoUploaded \(step)")
    }
    
    public func onDocumentSelected(documentType: String) {
        print("IdenfyUserFlowHandler - onDocumentSelected \(documentType)")
    }
    
    public func onCountrySelected(issuingCountryCode: String) {
        print("IdenfyUserFlowHandler - onCountrySelected \(issuingCountryCode)")
    }
    
    public func onProcessingStarted(processingStarted: Bool) {
        print("IdenfyUserFlowHandler - onProcessingStarted \(processingStarted)")
    }
}


