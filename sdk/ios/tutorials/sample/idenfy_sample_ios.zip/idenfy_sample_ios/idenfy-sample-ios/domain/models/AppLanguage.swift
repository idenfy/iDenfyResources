//
//  AppLanguage.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import Foundation
class AppLanguage {
    var languageEnum: String = "en"
    init(_ languageEnum: String) {
        self.languageEnum = languageEnum
    }
}
