//
//  ConsoleLoggingImpl.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 04/01/2024.
//  Copyright © 2024 Viktor Vostrikov. All rights reserved.
//

import Foundation

class ConsoleLoggingImpl {
    func log(event: String, message: String, token _: String) {
        print("FromIdenfySDK", event, " - ", message)
    }
}
