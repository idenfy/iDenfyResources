//
//  IdenfyLoggingHandlerUseCaseImpl.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 04/01/2024.
//  Copyright © 2024 Viktor Vostrikov. All rights reserved.
//

import Foundation
import iDenfySDK

class IdenfyLoggingHandlerUseCaseImpl: IdenfyLoggingHandlerUseCase {
    private var consoleLogging: ConsoleLoggingImpl!

    init(_ consoleLogging: ConsoleLoggingImpl) {
        self.consoleLogging = consoleLogging
    }

    func logEvent(event: String, message: String, token: String) {
        #if DEBUG
            consoleLogging.log(event: event, message: message, token: token)
        #endif
    }
}
