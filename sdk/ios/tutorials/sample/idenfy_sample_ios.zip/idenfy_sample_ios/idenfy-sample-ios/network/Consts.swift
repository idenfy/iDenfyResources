//
//  Consts.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import Foundation
import iDenfySDK

/**
  More about generating token: https://documentation.idenfy.com/API/GeneratingIdentificationToken
 */
struct Consts {
    static let baseURL = "https://ivs.idenfy.com/"
    static let apiKey = "OyWqikGREwC"
    static let apiSecret = "hKjhGOXRCOAyteUEW0gj"
    static let clientId = "IdenfySampleClientID"
    static let sdkInitFlow: SDKInitFlow = SDKInitFlow.Default
}

enum SDKInitFlow {
    case Default
    case CustomWithImplementedViews
}
