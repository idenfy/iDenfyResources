//
//  Consts.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import Foundation
import iDenfySDK

/**
  More about generating token: https://documentation.idenfy.com/KYC/GeneratingIdentificationToken
 */
struct Consts {
    static let baseURL = "https://ivs.idenfy.com/"
    static let apiKey = "PUT_YOUR_IDENFY_API_KEY_HERE"
    static let apiSecret = "PUT_YOUR_IDENFY_API_SECRET_HERE"
    static let clientId = "IdenfySampleClientID"
    static let sdkInitFlow: SDKInitFlow = SDKInitFlow.Default
}

enum SDKInitFlow {
    case Default
    case CustomWithImplementedViews
}
