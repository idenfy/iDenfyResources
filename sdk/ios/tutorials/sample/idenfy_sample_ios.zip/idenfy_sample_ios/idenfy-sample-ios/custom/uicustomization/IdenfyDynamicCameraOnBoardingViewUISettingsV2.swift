//
//  IdenfyCameraOnBoardingViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-12-01.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyDynamicCameraOnBoardingViewUISettingsV2: NSObject {
    // CameraOnBoardingViewViewV2 Colors

    @objc public static var idenfyCameraOnBoardingViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyCameraOnBoardingCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCameraOnBoardingCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCameraOnBoardingEnabledContinueButtonTextColor = IdenfyCommonColors.idenfyWhite
    @objc public static var idenfyCameraOnBoardingDisabledContinueButtonTextColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5)
    @objc public static var idenfyCameraOnBoardingDisabledContinueButtonBackgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.2)
    @objc public static var idenfyCameraOnBoardingViewProgressBarFillColor = IdenfyCommonColors.idenfyMainColorV2
    @objc public static var idenfyCameraOnBoardingViewProgressBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyCameraOnBoardingDetailsCardBackgroundColor = IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2
    @objc public static var idenfyCameraOnBoardingDetailsCardTitleColor = IdenfyCommonColors.idenfyMainColorV2

    // CameraOnBoardingViewViewV2 Fonts

    @objc public static var idenfyCameraOnBoardingCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyCameraOnBoardingCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
    @objc public static var idenfyCameraOnBoardingDetailsCardTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 12)
    
    // CameraOnBoardingViewViewV2 Style
    @objc public static var idenfyCameraOnBoardingDetailsCardCornerRadius = CGFloat(4)
}
