//
//  IdenfyNFCReadingTimeOutViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2021-04-06.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyNFCReadingTimeOutViewUISettingsV2: NSObject {
    // NFCRReadingTimeOutViewV2 Colors

    @objc public static var idenfyNFCReadingTimeOutViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyNFCReadingTimeOutCommonInformationTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyNFCReadingTimeOutCommonInformationDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyNFCReadingTimeOutContinueButtonTextColor = IdenfyCommonColors.idenfyWhite

    // NFCReadingTimeOutViewV2 Fonts

    @objc public static var idenfyNFCReadingTimeOutCommonInformationTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyNFCRReadingTimeOutCommonInformationDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 15)
}
