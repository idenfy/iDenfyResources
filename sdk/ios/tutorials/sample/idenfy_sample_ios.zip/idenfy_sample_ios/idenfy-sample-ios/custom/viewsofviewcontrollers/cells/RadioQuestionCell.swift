//
//  RadioQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2022-09-26.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class RadioQuestionCell: UITableViewCell, RadioQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var radioStackView: UIStackView = {
        let stack = UIStackView(frame: .zero)
        stack.axis = .vertical
        stack.distribution = .fill
        stack.alignment = UIStackView.Alignment.leading
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    public var radioContentStackView: UIStackView = {
        let stack = UIStackView(frame: .zero)
        stack.axis = .horizontal
        stack.distribution = .fill
        stack.spacing = 16
        stack.alignment = UIStackView.Alignment.center
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    public var radioButton: IdenfyRadioButton = {
        let button = IdenfyRadioButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isUserInteractionEnabled = true
        button.imageEdgeInsets = UIEdgeInsets(top: 6, left: 6, bottom: 6, right: 6)
        return button
    }()
    
    public var radioDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyRadioQuestionCellViewRadioButtonDescriptionFont
        label.textAlignment = .left
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyRadioQuestionCellViewRadioButtonDescriptionTextColor
        return label
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: .zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(radioStackView)
        radioStackView.leftAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        radioStackView.rightAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        radioStackView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        radioStackView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        
        radioContentStackView.addArrangedSubview(radioButton)
        radioContentStackView.addArrangedSubview(radioDescription)
    }
}


