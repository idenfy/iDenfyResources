//
//  DocumentSelectionViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import Lottie
import idenfyviews

@objc open class DocumentSelectionViewV2: UIView, DocumentSelectionViewableV2 {
    open weak var delegate: DocumentSelectionViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var documentSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewTitleTextColor
        return label
    }()

    public var documentSelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDescriptionTextColor
        return label
    }()

    public var emptyArea: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .clear
        return view
    }()

    public var documentTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.bounces = false
        tableView.isScrollEnabled = true
        tableView.allowsMultipleSelection = false
        tableView.allowsSelectionDuringEditing = false
        tableView.allowsMultipleSelectionDuringEditing = false
        tableView.backgroundColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewBackgroundColor
        tableView.showsVerticalScrollIndicator = false
        tableView.layer.cornerRadius = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewCornerRadius
        tableView.layer.borderWidth = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewBorderWidth
        tableView.layer.borderColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewBorderColor.cgColor
        return tableView
    }()
    
    public var continueDisabledButton: UIButton? = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonDisabledBackgroundColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton? = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewContinueButtonEnabledTextColor, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
//        if let path = IdenfyViewUtils.getResourcePath(name: "idenfy_custom_country_loader", type: ResourceType.json) {
//            lottieView.animation = Animation.filepath(path)
//        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.loopMode = .loop
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupDocumentTableView()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton?.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    private func setupTopTitle() {
        addSubview(documentSelectionTitle)
        documentSelectionTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        documentSelectionTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        documentSelectionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(documentSelectionDescription)
        documentSelectionDescription.widthAnchor.constraint(equalTo: documentSelectionTitle.widthAnchor, multiplier: 0.8).isActive = true
        documentSelectionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        documentSelectionDescription.topAnchor.constraint(equalTo: documentSelectionTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupContinueButton() {
        guard let unwrappedEnabledContinueButton = continueEnabledButton else { return }
        guard let unwrappedDisabledContinueButton = continueDisabledButton else { return }
        addSubview(unwrappedEnabledContinueButton)
        unwrappedEnabledContinueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        unwrappedEnabledContinueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        unwrappedEnabledContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        unwrappedEnabledContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(unwrappedDisabledContinueButton)
        unwrappedDisabledContinueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        unwrappedDisabledContinueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        unwrappedDisabledContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        unwrappedDisabledContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: unwrappedEnabledContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leftAnchor.constraint(equalTo: unwrappedEnabledContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }

    open func setupDocumentTableView() {
        addSubview(emptyArea)
        emptyArea.topAnchor.constraint(equalTo: documentSelectionDescription.bottomAnchor, constant: 32).isActive = true
        if let unwrappedEnabledButton = continueEnabledButton {
            emptyArea.bottomAnchor.constraint(equalTo: unwrappedEnabledButton.topAnchor, constant: -16).isActive = true
        } else {
            emptyArea.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16).isActive = true
        }
        emptyArea.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        emptyArea.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true

        addSubview(documentTableView)
        documentTableView.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        documentTableView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -24).isActive = true
        documentTableView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        documentTableView.topAnchor.constraint(equalTo: emptyArea.safeTopAnchor).isActive = true
        let bottom = documentTableView.bottomAnchor.constraint(equalTo: emptyArea.safeBottomAnchor)
        bottom.priority = UILayoutPriority.fittingSizeLevel
        bottom.isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton?.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}


@objc open class DocumentCell: UITableViewCell, DocumentCellViewable {
    public var documentTypeData: DocumentTypeData! {
        didSet {
            switch documentTypeData.documentTypeEnum {
            case .ID_CARD:
                documentImageView.image = UIImage(named: "idenfy_ic_documents_type_selection_id_card_v2", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
            default:
                documentImageView.image = UIImage(named: "idenfy_ic_documents_type_selection_passport_v2", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
            }
        }
    }

    public var hasBorder = false

    public var documentLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTypeFont
        label.text = "document"
        label.textAlignment = .left
        label.textColor = IdenfyDocumentSelectionViewUISettingsV2.idenfyDocumentSelectionViewDocumentTableViewCellTitleTextColor
        return label
    }()

    public var documentImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.isOpaque = true
        return imageView
    }()
    
    public var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
//        if let path = IdenfyViewUtils.getResourcePath(name: "idenfy_custom_country_loader", type: ResourceType.json) {
//            lottieView.animation = Animation.filepath(path)
//        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.loopMode = .loop
        lottieView.isHidden = true
        return lottieView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    open func setupView() {
        addSubview(documentImageView)
        documentImageView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        documentImageView.topAnchor.constraint(equalTo: safeTopAnchor, constant: 4).isActive = true
        documentImageView.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -4).isActive = true
        documentImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        documentImageView.widthAnchor.constraint(equalToConstant: 42).isActive = true

        addSubview(documentLabel)
        documentLabel.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        documentLabel.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -(frame.width * 0.3)).isActive = true
        documentLabel.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        documentLabel.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        documentLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
    }
}
