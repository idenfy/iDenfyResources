//
//  CountryAndDocumentSelectionView.swift
//  testing
//
//  Created by Viktas Juškys on 18/02/2026.
//  Copyright © 2026 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class CountryAndDocumentSelectionView: UIView, CountryAndDocumentSelectionViewable {
    open weak var delegate: CountryAndDocumentSelectionViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    private var scrollView: UIScrollView = {
        let scrollView = UIScrollView(frame: .zero)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.alwaysBounceVertical = false
        return scrollView
    }()

    private var contentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var countryAndDocumentSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewTitleTextColor
        return label
    }()
    
    public var countryAndDocumentSelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewDescriptionTextColor
        return label
    }()
    
    public var countrySelectionInputView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBackgroundColor
        view.layer.cornerRadius = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionCornerRadius
        view.layer.borderWidth = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBorderWidth
        view.layer.borderColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBorderColor.cgColor
        view.layer.masksToBounds = true
        view.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        view.isUserInteractionEnabled = true
        return view
    }()
    
    public var countrySelectionFlagImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.isOpaque = true
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewCountryFlagBorderWidth
        imageView.layer.borderColor = UIColor.black.cgColor
        return imageView
    }()
    
    public var countrySelectionUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionFont
        label.textAlignment = .left
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionTextColor
        return label
    }()
    
    public var countrySelectionCancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isOpaque = true
        button.isHidden = true
        button.isUserInteractionEnabled = true
        button.imageEdgeInsets = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 5)
        button.tintColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionTextColor
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        return button
    }()
    
    public var countrySelectionArrowIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionTextColor
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    private var documentSelectionStackView: UIStackView = {
        let stackView = UIStackView(frame: .zero)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 8
        stackView.alignment = .fill
        stackView.distribution = .fill
        return stackView
    }()

    public var verificationMethodTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewVerificationMethodTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewDocumentSelectionTitleTextColor
        return label
    }()
    
    public var digitalIdTableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.allowsMultipleSelection = false
        tableView.isScrollEnabled = false
        tableView.contentInset = UIEdgeInsets.zero
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.sectionHeaderHeight = 0
        tableView.sectionFooterHeight = 0
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: CGFloat.leastNormalMagnitude))
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: CGFloat.leastNormalMagnitude))
        return tableView
    }()
    
    public var documentSelectionTitleContainer: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var documentSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewPhysicalDocumentTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewDocumentSelectionTitleTextColor
        return label
    }()

    private var documentSelectionLeftLine: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBorderColor
        return view
    }()

    private var documentSelectionRightLine: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBorderColor
        return view
    }()
    
    public var documentTableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.allowsMultipleSelection = false
        tableView.isScrollEnabled = false
        tableView.contentInset = UIEdgeInsets.zero
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.sectionHeaderHeight = 0
        tableView.sectionFooterHeight = 0
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: CGFloat.leastNormalMagnitude))
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: CGFloat.leastNormalMagnitude))
        return tableView
    }()
    
    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewContinueButtonDisabledBackgroundColor
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewContinueButtonEnabledTextColor, for: .normal)
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        lottieView.applyColorTint(IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewCountryLoadingSpinnerTintColor)
        return lottieView
    }()
    
    open func setupConstraints() {
        backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupScrollView()
        setupTopTitle()
        setupCountrySelectionPicker()
        setupDocumentSelection()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }
    
    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }
    
    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    private func setupScrollView() {
        addSubview(scrollView)
        scrollView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        scrollView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: toolbar.bottomAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: continueEnabledButton.topAnchor, constant: -16).isActive = true

        scrollView.addSubview(contentView)
        contentView.leftAnchor.constraint(equalTo: scrollView.leftAnchor).isActive = true
        contentView.rightAnchor.constraint(equalTo: scrollView.rightAnchor).isActive = true
        contentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }
    
    open func setupTopTitle() {
        contentView.addSubview(countryAndDocumentSelectionTitle)
        countryAndDocumentSelectionTitle.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        countryAndDocumentSelectionTitle.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        countryAndDocumentSelectionTitle.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 24).isActive = true

        contentView.addSubview(countryAndDocumentSelectionDescription)
        countryAndDocumentSelectionDescription.widthAnchor.constraint(equalTo: countryAndDocumentSelectionTitle.widthAnchor, multiplier: 0.8).isActive = true
        countryAndDocumentSelectionDescription.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        countryAndDocumentSelectionDescription.topAnchor.constraint(equalTo: countryAndDocumentSelectionTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupCountrySelectionPicker() {
        contentView.addSubview(countrySelectionInputView)
        countrySelectionInputView.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 32).isActive = true
        countrySelectionInputView.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -32).isActive = true
        countrySelectionInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        countrySelectionInputView.topAnchor.constraint(equalTo: countryAndDocumentSelectionDescription.bottomAnchor, constant: 32).isActive = true

        contentView.addSubview(countrySelectionFlagImageView)
        countrySelectionFlagImageView.leftAnchor.constraint(equalTo: countrySelectionInputView.leftAnchor, constant: 12).isActive = true
        countrySelectionFlagImageView.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true
        countrySelectionFlagImageView.heightAnchor.constraint(equalToConstant: 25).isActive = true
        countrySelectionFlagImageView.widthAnchor.constraint(equalToConstant: 35).isActive = true

        contentView.addSubview(countrySelectionUILabel)
        countrySelectionUILabel.leftAnchor.constraint(equalTo: countrySelectionInputView.leftAnchor, constant: 16).isActive = true
        countrySelectionUILabel.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true
        countrySelectionUILabel.rightAnchor.constraint(equalTo: countrySelectionInputView.rightAnchor, constant: -16).isActive = true

        contentView.addSubview(countrySelectionCancelButton)
        countrySelectionCancelButton.heightAnchor.constraint(equalToConstant: 20).isActive = true
        countrySelectionCancelButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        countrySelectionCancelButton.rightAnchor.constraint(equalTo: countrySelectionInputView.rightAnchor, constant: -16).isActive = true
        countrySelectionCancelButton.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true

        contentView.addSubview(countrySelectionArrowIcon)
        countrySelectionArrowIcon.heightAnchor.constraint(equalToConstant: 25).isActive = true
        countrySelectionArrowIcon.widthAnchor.constraint(equalToConstant: 25).isActive = true
        countrySelectionArrowIcon.rightAnchor.constraint(equalTo: countrySelectionInputView.rightAnchor, constant: -16).isActive = true
        countrySelectionArrowIcon.centerYAnchor.constraint(equalTo: countrySelectionInputView.centerYAnchor).isActive = true
    }
    
    open func setupDocumentSelection() {
        contentView.addSubview(documentSelectionStackView)
        documentSelectionStackView.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 32).isActive = true
        documentSelectionStackView.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -32).isActive = true
        documentSelectionStackView.topAnchor.constraint(equalTo: countrySelectionInputView.bottomAnchor, constant: 24).isActive = true
        documentSelectionStackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true

        documentSelectionStackView.addArrangedSubview(verificationMethodTitle)
        documentSelectionStackView.addArrangedSubview(digitalIdTableView)
        documentSelectionStackView.addArrangedSubview(documentSelectionTitleContainer)
        documentSelectionStackView.addArrangedSubview(documentTableView)

        setupDocumentSelectionTitleWithLines()

        let heightConstraintDigital = digitalIdTableView.heightAnchor.constraint(greaterThanOrEqualToConstant: 56)
        heightConstraintDigital.priority = .defaultLow
        heightConstraintDigital.isActive = true

        let heightConstraint = documentTableView.heightAnchor.constraint(greaterThanOrEqualToConstant: 56)
        heightConstraint.priority = .defaultLow
        heightConstraint.isActive = true
    }

    private func setupDocumentSelectionTitleWithLines() {
        documentSelectionTitleContainer.addSubview(documentSelectionLeftLine)
        documentSelectionTitleContainer.addSubview(documentSelectionTitle)
        documentSelectionTitleContainer.addSubview(documentSelectionRightLine)

        documentSelectionLeftLine.leftAnchor.constraint(equalTo: documentSelectionTitleContainer.leftAnchor).isActive = true
        documentSelectionLeftLine.centerYAnchor.constraint(equalTo: documentSelectionTitle.centerYAnchor).isActive = true
        documentSelectionLeftLine.heightAnchor.constraint(equalToConstant: 1).isActive = true
        documentSelectionLeftLine.rightAnchor.constraint(equalTo: documentSelectionTitle.leftAnchor, constant: -8).isActive = true

        documentSelectionTitle.centerXAnchor.constraint(equalTo: documentSelectionTitleContainer.centerXAnchor).isActive = true
        documentSelectionTitle.topAnchor.constraint(equalTo: documentSelectionTitleContainer.topAnchor).isActive = true
        documentSelectionTitle.bottomAnchor.constraint(equalTo: documentSelectionTitleContainer.bottomAnchor).isActive = true

        documentSelectionRightLine.rightAnchor.constraint(equalTo: documentSelectionTitleContainer.rightAnchor).isActive = true
        documentSelectionRightLine.centerYAnchor.constraint(equalTo: documentSelectionTitle.centerYAnchor).isActive = true
        documentSelectionRightLine.heightAnchor.constraint(equalToConstant: 1).isActive = true
        documentSelectionRightLine.leftAnchor.constraint(equalTo: documentSelectionTitle.rightAnchor, constant: 8).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueDisabledButton)
        continueDisabledButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leftAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

@objc open class DocumentTypeWithCountryCell: UITableViewCell, DocumentTypeWithCountryCellViewable {

    public let leftContainerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBackgroundColor
        view.layer.borderColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBorderColor.cgColor
        view.layer.borderWidth = 1
        view.layer.cornerRadius = 4
        view.layer.masksToBounds = true
        return view
    }()

    public let rightContainerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBackgroundColor
        view.layer.borderColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionBorderColor.cgColor
        view.layer.borderWidth = 1
        view.layer.cornerRadius = 4
        view.layer.masksToBounds = true
        return view
    }()

    private let leftStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .horizontal
        stackView.spacing = 8
        stackView.alignment = .center
        stackView.distribution = .fill
        return stackView
    }()

    private let rightStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .horizontal
        stackView.spacing = 8
        stackView.alignment = .center
        stackView.distribution = .fill
        return stackView
    }()

    public let leftIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public let rightIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public let leftLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionFont
        label.textAlignment = .left
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionTextColor
        return label
    }()

    public let rightLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionFont
        label.textAlignment = .left
        label.textColor = IdenfyCountryAndDocumentSelectionViewUISettingsV2.idenfyCountryAndDocumentSelectionViewItemSelectionTextColor
        return label
    }()

    public var documentLabel: UILabel {
        return leftLabel
    }

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }

    open func setupView() {
        backgroundColor = .clear

        contentView.addSubview(leftContainerView)
        leftContainerView.leftAnchor.constraint(equalTo: contentView.leftAnchor).isActive = true
        leftContainerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6).isActive = true
        leftContainerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -6).isActive = true
        leftContainerView.widthAnchor.constraint(equalTo: contentView.widthAnchor, multiplier: 0.48).isActive = true

        contentView.addSubview(rightContainerView)
        rightContainerView.rightAnchor.constraint(equalTo: contentView.rightAnchor).isActive = true
        rightContainerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6).isActive = true
        rightContainerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -6).isActive = true
        rightContainerView.widthAnchor.constraint(equalTo: contentView.widthAnchor, multiplier: 0.48).isActive = true

        // Setup left container with stack view
        leftContainerView.addSubview(leftStackView)
        leftStackView.leftAnchor.constraint(equalTo: leftContainerView.leftAnchor, constant: 12).isActive = true
        leftStackView.rightAnchor.constraint(equalTo: leftContainerView.rightAnchor, constant: -12).isActive = true
        leftStackView.topAnchor.constraint(equalTo: leftContainerView.topAnchor, constant: 8).isActive = true
        leftStackView.bottomAnchor.constraint(equalTo: leftContainerView.bottomAnchor, constant: -8).isActive = true

        let leftHeightConstraint = leftStackView.heightAnchor.constraint(greaterThanOrEqualToConstant: 34)
        leftHeightConstraint.priority = .defaultHigh
        leftHeightConstraint.isActive = true

        // Add icon and label to left stack view
        leftStackView.addArrangedSubview(leftIcon)
        leftStackView.addArrangedSubview(leftLabel)

        leftIcon.widthAnchor.constraint(equalToConstant: 24).isActive = true
        leftIcon.heightAnchor.constraint(equalToConstant: 24).isActive = true

        // Setup right container with stack view
        rightContainerView.addSubview(rightStackView)
        rightStackView.leftAnchor.constraint(equalTo: rightContainerView.leftAnchor, constant: 12).isActive = true
        rightStackView.rightAnchor.constraint(equalTo: rightContainerView.rightAnchor, constant: -12).isActive = true
        rightStackView.topAnchor.constraint(equalTo: rightContainerView.topAnchor, constant: 8).isActive = true
        rightStackView.bottomAnchor.constraint(equalTo: rightContainerView.bottomAnchor, constant: -8).isActive = true

        let rightHeightConstraint = rightStackView.heightAnchor.constraint(greaterThanOrEqualToConstant: 34)
        rightHeightConstraint.priority = .defaultHigh
        rightHeightConstraint.isActive = true

        // Add icon and label to right stack view
        rightStackView.addArrangedSubview(rightIcon)
        rightStackView.addArrangedSubview(rightLabel)

        rightIcon.widthAnchor.constraint(equalToConstant: 24).isActive = true
        rightIcon.heightAnchor.constraint(equalToConstant: 24).isActive = true
    }
}
