//
//  EIDSessionViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 17/06/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class EIDSessionViewV2: UIView, EIDSessionViewableV2 {
    open weak var delegate: EIDSessionViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var eidSessionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = EIDSessionViewUISettingsV2.idenfyEIDSessionViewTitleFont
        label.textAlignment = .center
        label.textColor = EIDSessionViewUISettingsV2.idenfyEIDSessionViewTitleTextColor
        return label
    }()

    public var eidSessionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = EIDSessionViewUISettingsV2.idenfyEIDSessionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = EIDSessionViewUISettingsV2.idenfyEIDSessionViewDescriptionTextColor
        return label
    }()

    public var eidSessionQRCodeImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        return imageView
    }()

    public var eidSessionContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = EIDSessionViewUISettingsV2.idenfyEIDSessionViewContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    open func setupConstraints() {
        backgroundColor = EIDSessionViewUISettingsV2.idenfyEIDSessionViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupCenterImageView()
        setupButtonActions()
    }

    private func setupButtonActions() {
        eidSessionContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(eidSessionTitle)
        eidSessionTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        eidSessionTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        eidSessionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(eidSessionDescription)
        eidSessionDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        eidSessionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        eidSessionDescription.topAnchor.constraint(equalTo: eidSessionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(eidSessionQRCodeImageView)
        eidSessionQRCodeImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        eidSessionQRCodeImageView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.6).isActive = true
        eidSessionQRCodeImageView.heightAnchor.constraint(equalTo: eidSessionQRCodeImageView.widthAnchor, constant: 1).isActive = true
        eidSessionQRCodeImageView.topAnchor.constraint(equalTo: eidSessionDescription.bottomAnchor, constant: 32).isActive = true
    }

    open func setupContinueButton() {
        addSubview(eidSessionContinueButton)
        eidSessionContinueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        eidSessionContinueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        eidSessionContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        eidSessionContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        eidSessionContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
