//
//  IdentificationSuspectedResultsViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2022-02-21.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit

@objc open class IdentificationSuspectedResultsViewV2: UIView, IdentificationSuspectedResultsViewableV2 {
    public weak var delegate: IdentificationSuspectedResultsViewButtonActionsDelegate?

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public var idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isUserInteractionEnabled = true
        label.font = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_identification_suspected", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyUIButtonIdentificationSuspectedResultsContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyIdentificationSuspectedResultsViewUISettingsV2.idenfyIdentificationSuspectedResultsViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupCenterImageView()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        idenfyUIButtonIdentificationSuspectedResultsContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle)
        idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription)
        idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelIdentificationSuspectedResultsCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon)

        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUILabelIdentificationSuspectedResultsCommonInformationDescription.bottomAnchor, constant: 60).isActive = true
        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.widthAnchor.constraint(equalToConstant: 150).isActive = true
        idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.heightAnchor.constraint(equalTo: idenfyUIImageViewIdentificationSuspectedResultsCommonInformationIcon.widthAnchor, multiplier: 1).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIButtonIdentificationSuspectedResultsContinue)
        idenfyUIButtonIdentificationSuspectedResultsContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIButtonIdentificationSuspectedResultsContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIButtonIdentificationSuspectedResultsContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIButtonIdentificationSuspectedResultsContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIButtonIdentificationSuspectedResultsContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}


