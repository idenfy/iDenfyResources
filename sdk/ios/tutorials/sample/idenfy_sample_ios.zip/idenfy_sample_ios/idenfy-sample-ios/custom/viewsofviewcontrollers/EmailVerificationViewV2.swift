//
//  EmailVerificationViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 19/05/2025.
//  Copyright © 2025 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class EmailVerificationViewV2: UIView, EmailVerificationViewableV2 {
    open weak var delegate: EmailVerificationViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var emailVerificationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewTitleTextColor
        return label
    }()

    public var emailVerificationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewDescriptionTextColor
        return label
    }()
    
    public var emailInputContentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    public var emailInputImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_email_verification", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysOriginal)
        return imageView
    }()
    
    public var emailInputInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor
        return view
    }()
    
    public var emailInputInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardTitleTextColor
        return label
    }()
    
    public var emailInputInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_information_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var emailInputInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionFont
        label.textAlignment = .left
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardDescriptionTextColor
        return label
    }()
    
    public var emailInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldFont
        textField.textAlignment = .left
        textField.keyboardType = .emailAddress
        textField.textContentType = .emailAddress
        textField.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldTextColor
        textField.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBackgroundColor
        textField.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldCornerRadius
        textField.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderWidth
        textField.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        return textField
    }()
    
    public var errorMessage: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageFont
        label.textAlignment = .left
        label.isHidden = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputTextFieldErrorMessageTextColor
        return label
    }()
    
    public var emailInputStatusInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusBackgroundColor
        return view
    }()
    
    public var emailInputStatusInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor
        return label
    }()
    
    public var emailInputStatusInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardRetryStatusIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_information_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var emailCodeInputStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    public var emailCodeInputTextField: PinCodeInputTextField = {
        let pinField = PinCodeInputTextField()
        pinField.translatesAutoresizingMaskIntoConstraints = false
        pinField.isOpaque = true
        pinField.underlineWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineWidth
        pinField.underlineHSpacing = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHSpacing
        pinField.underlineVMargin = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineVMargin
        pinField.fontSize = 32
        pinField.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldFont!
        pinField.underlineHeight = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputTextFieldUnderlineHeight
        pinField.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldTextColor
        pinField.underlineColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUnderlineColor
        pinField.updatedUnderlineColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputTextFieldUpdatedUnderlineColor
        pinField.isUserInteractionEnabled = true
        pinField.isHidden = true
        return pinField
    }()
    
    public var emailCodeInputInformationCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardCornerRadius
        view.layer.borderWidth = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderWidth
        view.layer.borderColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBorderColor.cgColor
        view.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneInputInformationCardBackgroundColor
        return view
    }()
    
    public var emailCodeInputInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailSMSCodeInputInformationTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationTitleTextColor
        return label
    }()
    
    public var emailCodeInputInformationIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewEmailPhoneCodeInputInformationIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_failed_checkmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()
    
    public var resendEmailCodeInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewResendEmailSMSCodeInformationTitleTextColor
        return label
    }()
    
    public var changeEmailAddressInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleFont
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        label.textColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewChangeEmailAddressPhoneNumberInformationTitleTextColor
        return label
    }()
    
    public var continueDisabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonDisabledTextColor, for: .normal)
        button.backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonDisabledBackgroundColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        button.isHidden = false
        return button
    }()
    
    public var continueEnabledButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewContinueButtonEnabledTextColor, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyEmailSMSVerificationViewUISettingsV2.idenfyEmailSMSVerificationViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupEmailSelectionContentView()
        setupContinueButton()
        setupEmailCodeInputView()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        continueEnabledButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    private func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(emailVerificationTitle)
        emailVerificationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        emailVerificationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        emailVerificationTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(emailVerificationDescription)
        emailVerificationDescription.widthAnchor.constraint(equalTo: emailVerificationTitle.widthAnchor, multiplier: 0.8).isActive = true
        emailVerificationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        emailVerificationDescription.topAnchor.constraint(equalTo: emailVerificationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupEmailSelectionContentView() {
        addSubview(emailInputContentView)
        emailInputContentView.leftAnchor.constraint(equalTo: leftAnchor, constant: 32).isActive = true
        emailInputContentView.rightAnchor.constraint(equalTo: rightAnchor, constant: -32).isActive = true
        emailInputContentView.topAnchor.constraint(equalTo: emailVerificationDescription.bottomAnchor).isActive = true
        
        emailInputContentView.addSubview(emailInputImageView)
        emailInputImageView.topAnchor.constraint(equalTo: emailInputContentView.topAnchor, constant: 24).isActive = true
        emailInputImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        emailInputImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        emailInputImageView.centerXAnchor.constraint(equalTo: emailInputContentView.centerXAnchor).isActive = true
        
        emailInputContentView.addSubview(emailInputInformationCard)
        emailInputInformationCard.topAnchor.constraint(equalTo: emailInputImageView.bottomAnchor, constant: 24).isActive = true
        emailInputInformationCard.leftAnchor.constraint(equalTo: emailInputContentView.leftAnchor).isActive = true
        emailInputInformationCard.rightAnchor.constraint(equalTo: emailInputContentView.rightAnchor).isActive = true
        
        emailInputInformationCard.addSubview(emailInputInformationIcon)
        emailInputInformationIcon.leftAnchor.constraint(equalTo: emailInputInformationCard.leftAnchor, constant: 16).isActive = true
        emailInputInformationIcon.heightAnchor.constraint(equalToConstant: 18).isActive = true
        emailInputInformationIcon.widthAnchor.constraint(equalToConstant: 18).isActive = true
        emailInputInformationIcon.topAnchor.constraint(equalTo: emailInputInformationCard.topAnchor, constant: 12).isActive = true
        
        emailInputInformationCard.addSubview(emailInputInformationTitle)
        emailInputInformationTitle.leftAnchor.constraint(equalTo: emailInputInformationIcon.rightAnchor, constant: 8).isActive = true
        emailInputInformationTitle.topAnchor.constraint(equalTo: emailInputInformationIcon.topAnchor).isActive = true
        emailInputInformationTitle.rightAnchor.constraint(equalTo: emailInputInformationCard.rightAnchor, constant: -8).isActive = true
        
        emailInputInformationCard.addSubview(emailInputInformationDescription)
        emailInputInformationDescription.topAnchor.constraint(equalTo: emailInputInformationTitle.bottomAnchor, constant: 12).isActive = true
        emailInputInformationDescription.leftAnchor.constraint(equalTo: emailInputInformationTitle.leftAnchor).isActive = true
        emailInputInformationDescription.rightAnchor.constraint(equalTo: emailInputInformationCard.rightAnchor, constant: -16).isActive = true
        emailInputInformationDescription.bottomAnchor.constraint(equalTo: emailInputInformationCard.bottomAnchor, constant: -12).isActive = true
        
        emailInputContentView.addSubview(emailInputView)
        emailInputView.leftAnchor.constraint(equalTo: emailInputContentView.leftAnchor).isActive = true
        emailInputView.rightAnchor.constraint(equalTo: emailInputContentView.rightAnchor).isActive = true
        emailInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        emailInputView.topAnchor.constraint(equalTo: emailInputInformationCard.bottomAnchor, constant: 16).isActive = true
        emailInputView.bottomAnchor.constraint(equalTo: emailInputContentView.bottomAnchor).isActive = true
        
        emailInputContentView.addSubview(errorMessage)
        errorMessage.topAnchor.constraint(equalTo: emailInputView.topAnchor, constant: 2).isActive = true
        errorMessage.leftAnchor.constraint(equalTo: emailInputView.safeLeftAnchor, constant: 10).isActive = true
        errorMessage.rightAnchor.constraint(equalTo: emailInputView.safeRightAnchor).isActive = true
        
        addSubview(emailInputStatusInformationCard)
        
        emailInputStatusInformationCard.leftAnchor.constraint(equalTo: leftAnchor, constant: 32).isActive = true
        emailInputStatusInformationCard.rightAnchor.constraint(equalTo: rightAnchor, constant: -32).isActive = true
        emailInputStatusInformationCard.topAnchor.constraint(equalTo: emailInputView.bottomAnchor, constant: 24).isActive = true
        
        emailInputStatusInformationCard.addSubview(emailInputStatusInformationIcon)
        emailInputStatusInformationIcon.leftAnchor.constraint(equalTo: emailInputStatusInformationCard.leftAnchor, constant: 16).isActive = true
        emailInputStatusInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        emailInputStatusInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        emailInputStatusInformationIcon.centerYAnchor.constraint(equalTo: emailInputStatusInformationCard.centerYAnchor).isActive = true
        
        emailInputStatusInformationCard.addSubview(emailInputStatusInformationTitle)
        emailInputStatusInformationTitle.leftAnchor.constraint(equalTo: emailInputStatusInformationIcon.rightAnchor, constant: 8).isActive = true
        emailInputStatusInformationTitle.topAnchor.constraint(equalTo: emailInputStatusInformationCard.topAnchor, constant: 12).isActive = true
        emailInputStatusInformationTitle.bottomAnchor.constraint(equalTo: emailInputStatusInformationCard.bottomAnchor, constant: -12).isActive = true
        emailInputStatusInformationTitle.rightAnchor.constraint(equalTo: emailInputStatusInformationCard.rightAnchor, constant: -16).isActive = true
    }
    
    open func setupEmailCodeInputView() {
        addSubview(emailCodeInputTextField)
        emailCodeInputTextField.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        emailCodeInputTextField.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        emailCodeInputTextField.topAnchor.constraint(equalTo: emailVerificationDescription.bottomAnchor, constant: 24).isActive = true
        emailCodeInputTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        let spacerView = UIView()
        spacerView.translatesAutoresizingMaskIntoConstraints = false
        spacerView.setContentHuggingPriority(.defaultLow, for: .vertical)
        
        let labelsContainer = UIView()
        labelsContainer.translatesAutoresizingMaskIntoConstraints = false
        labelsContainer.addSubview(resendEmailCodeInformationTitle)
        resendEmailCodeInformationTitle.leftAnchor.constraint(equalTo: labelsContainer.leftAnchor).isActive = true
        resendEmailCodeInformationTitle.rightAnchor.constraint(equalTo: labelsContainer.rightAnchor).isActive = true
        resendEmailCodeInformationTitle.topAnchor.constraint(equalTo: labelsContainer.topAnchor, constant: 24).isActive = true
        
        labelsContainer.addSubview(changeEmailAddressInformationTitle)
        changeEmailAddressInformationTitle.leftAnchor.constraint(equalTo: labelsContainer.leftAnchor).isActive = true
        changeEmailAddressInformationTitle.rightAnchor.constraint(equalTo: labelsContainer.rightAnchor).isActive = true
        changeEmailAddressInformationTitle.topAnchor.constraint(equalTo: resendEmailCodeInformationTitle.bottomAnchor, constant: 12).isActive = true
        changeEmailAddressInformationTitle.bottomAnchor.constraint(equalTo: labelsContainer.bottomAnchor).isActive = true
        
        emailCodeInputStackView.addArrangedSubview(emailCodeInputInformationCard)
        emailCodeInputStackView.addArrangedSubview(labelsContainer)
        emailCodeInputStackView.addArrangedSubview(spacerView)
        
        addSubview(emailCodeInputStackView)
        
        emailCodeInputStackView.leftAnchor.constraint(equalTo: leftAnchor, constant: 32).isActive = true
        emailCodeInputStackView.rightAnchor.constraint(equalTo: rightAnchor, constant: -32).isActive = true
        emailCodeInputStackView.topAnchor.constraint(equalTo: emailCodeInputTextField.bottomAnchor, constant: 24).isActive = true
        
        emailCodeInputInformationCard.addSubview(emailCodeInputInformationIcon)
        emailCodeInputInformationIcon.leftAnchor.constraint(equalTo: emailCodeInputInformationCard.leftAnchor, constant: 16).isActive = true
        emailCodeInputInformationIcon.heightAnchor.constraint(equalToConstant: 20).isActive = true
        emailCodeInputInformationIcon.widthAnchor.constraint(equalToConstant: 20).isActive = true
        emailCodeInputInformationIcon.centerYAnchor.constraint(equalTo: emailCodeInputInformationCard.centerYAnchor).isActive = true
        
        emailCodeInputInformationCard.addSubview(emailCodeInputInformationTitle)
        emailCodeInputInformationTitle.leftAnchor.constraint(equalTo: emailCodeInputInformationIcon.rightAnchor, constant: 8).isActive = true
        emailCodeInputInformationTitle.topAnchor.constraint(equalTo: emailCodeInputInformationCard.topAnchor, constant: 12).isActive = true
        emailCodeInputInformationTitle.bottomAnchor.constraint(equalTo: emailCodeInputInformationCard.bottomAnchor, constant: -12).isActive = true
        emailCodeInputInformationTitle.rightAnchor.constraint(equalTo: emailCodeInputInformationCard.rightAnchor, constant: -16).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(continueEnabledButton)
        continueEnabledButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueEnabledButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueEnabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueEnabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueDisabledButton)
        continueDisabledButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueDisabledButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueDisabledButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueDisabledButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: continueEnabledButton.centerYAnchor).isActive = true
        continueButtonSpinner.leftAnchor.constraint(equalTo: continueEnabledButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        continueEnabledButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

