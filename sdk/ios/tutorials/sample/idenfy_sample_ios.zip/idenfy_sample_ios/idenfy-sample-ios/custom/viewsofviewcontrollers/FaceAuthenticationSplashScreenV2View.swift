//
//  FaceAuthenticationSplashScreenV2View.swift
//  testing
//
//  Created by Viktas Juskys on 2021-11-03.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit

@objc open class FaceAuthenticationSplashScreenV2View: UIView, FaceAuthenticationSplashScreenV2Viewable {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public var idenfyLogo: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_splash_screen_logo", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var backgroundGradient: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_gradient_splash_screen_background", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        return imageView
    }()
    
    public var splashScreenTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionTextColor
        label.numberOfLines = 0
        label.font = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionFont
        label.textAlignment = .center
        return label
    }()
    
    var splashIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_face_authentication_slash_icon", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        return imageView
    }()

    open func setupConstraints() {
        setupViews()
    }

    @objc open func setupViews() {
        addSubview(backgroundGradient)
        backgroundGradient.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: -5).isActive = true
        backgroundGradient.rightAnchor.constraint(equalTo: safeRightAnchor, constant: 5).isActive = true
        addSubview(idenfyLogo)
        //let spinnerSize = bounds.height / 1.62
        let logoY = -(bounds.height / 7)
        //let spinnerY = -(bounds.height / 6)
        let titleY = bounds.height / 5
        idenfyLogo.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyLogo.centerYAnchor.constraint(equalTo: centerYAnchor, constant: logoY).isActive = true
        idenfyLogo.heightAnchor.constraint(equalToConstant: 32).isActive = true
        addSubview(splashScreenTitle)
        splashScreenTitle.topAnchor.constraint(equalTo: idenfyLogo.bottomAnchor, constant: titleY).isActive = true
        splashScreenTitle.widthAnchor.constraint(equalToConstant: frame.width * 0.8).isActive = true
        splashScreenTitle.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        
        addSubview(splashIcon)
        splashIcon.bottomAnchor.constraint(equalTo: idenfyLogo.topAnchor, constant: -16).isActive = true
        splashIcon.centerXAnchor.constraint(equalTo: centerXAnchor, constant: 10).isActive = true
        splashIcon.widthAnchor.constraint(equalToConstant: 60).isActive = true
        splashIcon.heightAnchor.constraint(equalTo: splashIcon.widthAnchor).isActive = true
    }
}

