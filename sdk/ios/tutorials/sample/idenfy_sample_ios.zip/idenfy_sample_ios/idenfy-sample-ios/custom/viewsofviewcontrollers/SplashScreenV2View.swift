//
//  SplashScreenV2View.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class SplashScreenV2View: UIView, SplashScreenV2Viewable {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
        backgroundColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewBackgroundColor
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyLogo: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_splash_screen_logo", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_file_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.applyColorTint(IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewSpinnerTintColor)
        return lottieView
    }()

    public var splashScreenTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewTitleTextColor
        label.numberOfLines = 0
        label.font = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewTitleFont
        label.textAlignment = .center
        return label
    }()
    
    public var splashScreenDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionTextColor
        label.numberOfLines = 0
        label.font = IdenfySplashScreenViewUISettingsV2.idenfySplashScreenViewDescriptionFont
        label.textAlignment = .center
        return label
    }()
    
    public var idenfyImageViewPowered: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_powered_by_idenfy_v2", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var bottomStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .horizontal
        stackView.distribution = .fill
        stackView.alignment = .center
        stackView.spacing = 4
        return stackView
    }()

    open func setupConstraints() {
        setupViews()
    }

    @objc open func setupViews() {
        addSubview(splashScreenTitle)
        splashScreenTitle.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        splashScreenTitle.widthAnchor.constraint(equalToConstant: frame.width * 0.8).isActive = true
        splashScreenTitle.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        
        addSubview(idenfyLogo)
        idenfyLogo.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyLogo.bottomAnchor.constraint(equalTo: splashScreenTitle.topAnchor, constant: -12).isActive = true
        idenfyLogo.heightAnchor.constraint(equalToConstant: IdenfySplashScreenViewUISettingsV2.idenfySplashScreenLogoSize).isActive = true
        
        addSubview(loadingSpinner)
        loadingSpinner.topAnchor.constraint(equalTo: splashScreenTitle.bottomAnchor, constant: 40).isActive = true
        loadingSpinner.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 53).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 53).isActive = true

        bottomStackView.addArrangedSubview(splashScreenDescription)
        bottomStackView.addArrangedSubview(idenfyImageViewPowered)

        addSubview(bottomStackView)
        bottomStackView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16).isActive = true
        bottomStackView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true

        idenfyImageViewPowered.widthAnchor.constraint(equalToConstant: 35).isActive = true
        idenfyImageViewPowered.heightAnchor.constraint(equalToConstant: 120).isActive = true
        idenfyImageViewPowered.transform = CGAffineTransform(translationX: 0, y: 2)
    }
}
