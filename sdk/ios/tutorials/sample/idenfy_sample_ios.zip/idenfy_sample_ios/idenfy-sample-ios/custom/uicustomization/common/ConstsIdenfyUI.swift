//
//  ConstsIdenfyUI.swift
//  iDenfySDK
//
//  Created by Viktor Vostrikov on 2020-01-03.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit

// swiftlint:disable all

public struct ConstsIdenfyUI {
    public static let IDENFY_TOP_DRAWER_INSTRUCTIONS_HEIGHT = CGFloat(150)
}
