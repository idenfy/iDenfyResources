//
//  DrawerContentViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import AVFoundation
import Lottie

@objc open class DrawerContentViewV2: UIView, DrawerContentViewableV2 {
    open weak var delegate: CameraSessionDrawerDelegate?

    public var toolbar: IdenfyToolbarV2CameraSession = {
        let toolbar = IdenfyToolbarV2CameraSession(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()
    
    public var descriptionScrollView: UIScrollView = {
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.isUserInteractionEnabled = true
        scroll.bounces = false
        scroll.showsVerticalScrollIndicator = false
        scroll.showsHorizontalScrollIndicator = false
        return scroll
    }()

    public var descriptionLabelV2: UILabel = {
        let label = UILabel()
        label.textColor = IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionTextColor
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionFont
        label.numberOfLines = 3
        return label
    }()

    public var infoLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = IdenfyDrawerUISettingsV2.idenfyDrawerTitleFont
        label.textColor = IdenfyDrawerUISettingsV2.idenfyDrawerTitleTextColor
        label.numberOfLines = 0
        return label
    }()
    
    public var descriptionSpace: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var faceDetectionAlertImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isHidden = true
        imageView.image = UIImage(named: "idenfy_ic_info_alert", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyCommonColors.idenfyFaceNotDetectedColor
        return imageView
    }()
    
    public var faceDetectionProgressView: UIProgressView = {
        let progressView = UIProgressView(frame: .zero)
        progressView.translatesAutoresizingMaskIntoConstraints = false
        progressView.progressTintColor = IdenfyInstructionAlertUISettigsV2.idenfyInstructionAlertProgressBarFillColor
        progressView.trackTintColor = UIColor.clear
        progressView.isHidden = true
        return progressView
    }()
    
    public var faceDetectionProgressViewV2: UIProgressView? = {
        let progressView = UIProgressView(frame: .zero)
        progressView.translatesAutoresizingMaskIntoConstraints = false
        progressView.progressTintColor = IdenfyInstructionAlertUISettigsV2.idenfyInstructionAlertProgressBarFillColor
        progressView.trackTintColor = UIColor.clear
        progressView.isHidden = true
        return progressView
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = IdenfyCommonColors.idenfyDrawerBackgroundColor
        setupToolbar()
        setupLabel()
        setupDescription()
        setupFaceCameraProgressView()
        setupButtonActions()
    }

    public convenience init() {
        self.init(frame: CGRect.zero)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }
    
    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
        
        toolbar.backButton.imageView?.tintColor = IdenfyDrawerUISettingsV2.idenfyDrawerBackButtonTintColor
        
        toolbar.addSubview(faceDetectionAlertImage)
        faceDetectionAlertImage.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor, constant: -4).isActive = true
        faceDetectionAlertImage.centerXAnchor.constraint(equalTo: toolbar.centerXAnchor).isActive = true
        faceDetectionAlertImage.widthAnchor.constraint(equalToConstant: 32).isActive = true
        faceDetectionAlertImage.heightAnchor.constraint(equalToConstant: 32).isActive = true
        
        if let device = AVCaptureDevice.default(for: AVMediaType.video) {
            if device.hasTorch {
                toolbar.idenfyToggleFlashButton.widthAnchor.constraint(equalToConstant: 24).isActive = true
                toolbar.idenfyToggleFlashButton.setNeedsLayout()
                toolbar.idenfyToggleFlashButton.isHidden = false
            } else {
                toolbar.idenfyToggleFlashButton.widthAnchor.constraint(equalToConstant: 0).isActive = true
                toolbar.idenfyToggleFlashButton.setNeedsLayout()
                toolbar.idenfyToggleFlashButton.isHidden = true
            }
        }
    }
    
    open func setupLabel() {
        addSubview(infoLabel)
        infoLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        infoLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        infoLabel.topAnchor.constraint(equalTo: toolbar.topAnchor, constant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight - 16).isActive = true
    }

    open func setupDescription() {
        addSubview(descriptionSpace)
        descriptionSpace.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8).isActive = true
        descriptionSpace.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8).isActive = true
        descriptionSpace.topAnchor.constraint(equalTo: infoLabel.bottomAnchor, constant: 8).isActive = true
        descriptionSpace.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -4).isActive = true
        
        descriptionSpace.addSubview(descriptionScrollView)
        descriptionScrollView.topAnchor.constraint(equalTo: descriptionSpace.topAnchor).isActive = true
        descriptionScrollView.leftAnchor.constraint(equalTo: descriptionSpace.leftAnchor).isActive = true
        descriptionScrollView.rightAnchor.constraint(equalTo: descriptionSpace.rightAnchor).isActive = true
        descriptionScrollView.bottomAnchor.constraint(equalTo: descriptionSpace.bottomAnchor).isActive = true
        
        descriptionScrollView.addSubview(descriptionLabelV2)
        descriptionLabelV2.leadingAnchor.constraint(equalTo: descriptionScrollView.leadingAnchor).isActive = true
        descriptionLabelV2.trailingAnchor.constraint(equalTo: descriptionScrollView.trailingAnchor).isActive = true
        descriptionLabelV2.topAnchor.constraint(equalTo: descriptionScrollView.topAnchor).isActive = true
        descriptionLabelV2.bottomAnchor.constraint(equalTo: descriptionScrollView.bottomAnchor).isActive = true
        descriptionLabelV2.heightAnchor.constraint(greaterThanOrEqualTo: descriptionSpace.heightAnchor).isActive = true
        descriptionLabelV2.widthAnchor.constraint(equalTo: descriptionSpace.widthAnchor).isActive = true
    }
    
    private func setupFaceCameraProgressView() {
        guard let unwrappedFaceDetectionProgressViewV2 = faceDetectionProgressViewV2 else { return }
        addSubview(unwrappedFaceDetectionProgressViewV2)
        unwrappedFaceDetectionProgressViewV2.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        unwrappedFaceDetectionProgressViewV2.topAnchor.constraint(equalTo: toolbar.topAnchor).isActive = true
        unwrappedFaceDetectionProgressViewV2.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        unwrappedFaceDetectionProgressViewV2.heightAnchor.constraint(equalToConstant: 3).isActive = true
    }

    private func setupButtonActions() {
        toolbar.backButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        toolbar.idenfyToggleFlashButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(toggleFlashButtonPressed)))
        toolbar.instructionDialogButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(instructionDialogButtonPressed)))
    }

    @objc func backButtonPressed() {
        delegate?.backButtonPressedAction()
    }
    
    @objc func toggleFlashButtonPressed() {
        delegate?.toggleFlashButtonPressedAction()
    }
    
    @objc func instructionDialogButtonPressed() {
        delegate?.instructionDialogButtonPressedAction()
    }
}
