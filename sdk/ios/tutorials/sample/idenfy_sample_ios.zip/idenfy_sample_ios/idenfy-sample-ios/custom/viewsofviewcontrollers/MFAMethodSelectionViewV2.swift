//
//  MFAMethodSelectionViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2022-04-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit
import AVFoundation
import Lottie

@objc open class MFAMethodSelectionViewV2: UIView, MFAMethodSelectionViewableV2 {
    open weak var delegate: MFAMethodSelectionViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var mfaMethodSelectionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewTitleTextColor
        return label
    }()

    public var mfaMethodSelectionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewDescriptionTextColor
        return label
    }()
    
    public var mfaMethodSelectionHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewHintFont
        label.textAlignment = .left
        label.isHidden = true
        label.textColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewHintTextColor
        return label
    }()
    
    public var mfaMethodSelectionInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.textContentType = .givenName
        textField.font = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewInputViewFont
        textField.textAlignment = .left
        textField.textColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewInputViewTextColor
        textField.backgroundColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewInputViewBackgroundColor
        textField.returnKeyType = .next
        textField.layer.cornerRadius = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewInputViewCorderRadius
        textField.layer.borderWidth = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewInputViewBorderWidth
        textField.layer.borderColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewInputBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        return textField
    }()

    public var mfaContinueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()
    
    public var continueButtonSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyMFAMethodSelectionViewUISettingsV2.idenfyMFAMethodSelectionViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupTopTitle()
        setupCenterTextFields()
        setupButtonActions()
    }

    private func setupButtonActions() {
        mfaContinueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupTopTitle() {
        addSubview(mfaMethodSelectionTitle)
        mfaMethodSelectionTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        mfaMethodSelectionTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        mfaMethodSelectionTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true

        addSubview(mfaMethodSelectionDescription)
        mfaMethodSelectionDescription.widthAnchor.constraint(equalTo: mfaMethodSelectionTitle.widthAnchor, multiplier: 0.8).isActive = true
        mfaMethodSelectionDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        mfaMethodSelectionDescription.topAnchor.constraint(equalTo: mfaMethodSelectionTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupContinueButton() {
        addSubview(mfaContinueButton)
        mfaContinueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        mfaContinueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        mfaContinueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        mfaContinueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(continueButtonSpinner)
        continueButtonSpinner.centerYAnchor.constraint(equalTo: mfaContinueButton.centerYAnchor).isActive = true
        continueButtonSpinner.leftAnchor.constraint(equalTo: mfaContinueButton.safeLeftAnchor, constant: 16).isActive = true
        continueButtonSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        continueButtonSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func setupCenterTextFields() {
        addSubview(mfaMethodSelectionInputView)
        mfaMethodSelectionInputView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        mfaMethodSelectionInputView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        mfaMethodSelectionInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        mfaMethodSelectionInputView.leftAnchor.constraint(equalTo: mfaContinueButton.leftAnchor, constant: 24).isActive = true
        mfaMethodSelectionInputView.rightAnchor.constraint(equalTo: mfaContinueButton.rightAnchor, constant: -24).isActive = true
        
        addSubview(mfaMethodSelectionHintLabel)
        mfaMethodSelectionHintLabel.topAnchor.constraint(equalTo: mfaMethodSelectionInputView.topAnchor, constant: 2).isActive = true
        mfaMethodSelectionHintLabel.leftAnchor.constraint(equalTo: mfaMethodSelectionInputView.safeLeftAnchor, constant: 10).isActive = true
        mfaMethodSelectionHintLabel.rightAnchor.constraint(equalTo: mfaMethodSelectionInputView.safeRightAnchor).isActive = true
    }
    
    open func applyGradients() {
        mfaContinueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

