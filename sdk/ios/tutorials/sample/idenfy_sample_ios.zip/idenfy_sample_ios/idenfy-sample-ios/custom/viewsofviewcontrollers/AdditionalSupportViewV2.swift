//
//  AdditionalSupportViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2022-02-09.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import UIKit

@objc open class AdditionalSupportViewV2: UIView, AdditionalSupportViewableV2 {
    public weak var delegate: AdditionalSupportViewButtonActionsDelegate?

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyUILabelAdditionalSupportCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelAdditionalSupportCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isUserInteractionEnabled = true
        label.font = IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewAdditionalSupportCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_session_expired", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyUIButtonAdditionalSupportContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyAdditionalSupportViewUISettingsV2.idenfyAdditionalSupportViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupCenterImageView()
        setupContinueButton()
        setupButtonActions()
    }

    private func setupButtonActions() {
        idenfyUIButtonAdditionalSupportContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelAdditionalSupportCommonInformationTitle)
        idenfyUILabelAdditionalSupportCommonInformationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelAdditionalSupportCommonInformationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelAdditionalSupportCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelAdditionalSupportCommonInformationDescription)
        idenfyUILabelAdditionalSupportCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelAdditionalSupportCommonInformationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUILabelAdditionalSupportCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelAdditionalSupportCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIImageViewAdditionalSupportCommonInformationIcon)

        idenfyUIImageViewAdditionalSupportCommonInformationIcon.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUIImageViewAdditionalSupportCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUILabelAdditionalSupportCommonInformationDescription.bottomAnchor, constant: 60).isActive = true
        idenfyUIImageViewAdditionalSupportCommonInformationIcon.widthAnchor.constraint(equalToConstant: 150).isActive = true
        idenfyUIImageViewAdditionalSupportCommonInformationIcon.heightAnchor.constraint(equalTo: idenfyUIImageViewAdditionalSupportCommonInformationIcon.widthAnchor, multiplier: 1).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIButtonAdditionalSupportContinue)
        idenfyUIButtonAdditionalSupportContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIButtonAdditionalSupportContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIButtonAdditionalSupportContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIButtonAdditionalSupportContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIButtonAdditionalSupportContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}

