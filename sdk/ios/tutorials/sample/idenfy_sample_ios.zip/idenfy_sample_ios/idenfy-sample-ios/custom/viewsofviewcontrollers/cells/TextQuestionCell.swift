//
//  TextQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2022-09-26.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class TextQuestionCell: UITableViewCell, TextQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UITextView = {
        let label = UITextView(frame: .zero)
        label.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        label.isScrollEnabled = false
        label.dataDetectorTypes = UIDataDetectorTypes.link
        label.isEditable = false
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var textInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellTextFieldFont
        textField.textAlignment = .left
        textField.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldTextColor
        textField.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBackgroundColor
        textField.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldCornerRadius
        textField.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderWidth
        textField.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        return textField
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(textInputView)
        textInputView.leftAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        textInputView.rightAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        textInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        textInputView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        textInputView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
    }
}
