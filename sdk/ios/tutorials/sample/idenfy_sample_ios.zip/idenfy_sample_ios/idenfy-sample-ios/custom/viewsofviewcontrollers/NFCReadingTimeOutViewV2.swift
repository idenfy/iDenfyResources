//
//  NFCReadingTimeOutViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2021-04-06.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class NFCReadingTimeOutViewV2: UIView, NFCReadingTimeOutViewableV2 {
    open weak var delegate: NFCReadingTimeOutViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.backButton.isHidden = true
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var idenfyUILabelNFCReadingTimeOutCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyNFCReadingTimeOutViewUISettingsV2.idenfyNFCReadingTimeOutCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyNFCReadingTimeOutViewUISettingsV2.idenfyNFCReadingTimeOutCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelNFCReadingTimeOutCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyNFCReadingTimeOutViewUISettingsV2.idenfyNFCRReadingTimeOutCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyNFCReadingTimeOutViewUISettingsV2.idenfyNFCReadingTimeOutCommonInformationDescriptionTextColor
        return label
    }()
    
    public var idenfyUIViewCenterSpace: UIView = {
        let uiview = UIView()
        uiview.translatesAutoresizingMaskIntoConstraints = false
        return uiview
    }()

    public var idenfyUIImageViewNFCReadingTimeOutCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_nfc_reading_failure", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyUIButtonNFCReadingTimeOutContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textColor = IdenfyNFCReadingTimeOutViewUISettingsV2.idenfyNFCReadingTimeOutContinueButtonTextColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyNFCReadingTimeOutViewUISettingsV2.idenfyNFCReadingTimeOutViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupCenterImageView()
        setupButtonActions()
    }

    private func setupButtonActions() {
        idenfyUIButtonNFCReadingTimeOutContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelNFCReadingTimeOutCommonInformationTitle)
        idenfyUILabelNFCReadingTimeOutCommonInformationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelNFCReadingTimeOutCommonInformationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelNFCReadingTimeOutCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelNFCReadingTimeOutCommonInformationDescription)
        idenfyUILabelNFCReadingTimeOutCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelNFCReadingTimeOutCommonInformationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUILabelNFCReadingTimeOutCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelNFCReadingTimeOutCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIViewCenterSpace)
        idenfyUIViewCenterSpace.topAnchor.constraint(equalTo: idenfyUILabelNFCReadingTimeOutCommonInformationDescription.bottomAnchor, constant: 32).isActive = true
        idenfyUIViewCenterSpace.bottomAnchor.constraint(equalTo: idenfyUIButtonNFCReadingTimeOutContinue.topAnchor, constant: -50).isActive = true
        idenfyUIViewCenterSpace.leftAnchor.constraint(equalTo: leftAnchor, constant: 30).isActive = true
        idenfyUIViewCenterSpace.rightAnchor.constraint(equalTo: rightAnchor, constant: -50).isActive = true
        
        idenfyUIViewCenterSpace.addSubview(idenfyUIImageViewNFCReadingTimeOutCommonInformationIcon)
        idenfyUIImageViewNFCReadingTimeOutCommonInformationIcon.topAnchor.constraint(equalTo: idenfyUIViewCenterSpace.topAnchor).isActive = true
        idenfyUIImageViewNFCReadingTimeOutCommonInformationIcon.leftAnchor.constraint(equalTo: idenfyUIViewCenterSpace.leftAnchor).isActive = true
        idenfyUIImageViewNFCReadingTimeOutCommonInformationIcon.rightAnchor.constraint(equalTo: idenfyUIViewCenterSpace.rightAnchor).isActive = true
        idenfyUIImageViewNFCReadingTimeOutCommonInformationIcon.bottomAnchor.constraint(equalTo: idenfyUIViewCenterSpace.bottomAnchor).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIButtonNFCReadingTimeOutContinue)
        idenfyUIButtonNFCReadingTimeOutContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIButtonNFCReadingTimeOutContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIButtonNFCReadingTimeOutContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIButtonNFCReadingTimeOutContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIButtonNFCReadingTimeOutContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
