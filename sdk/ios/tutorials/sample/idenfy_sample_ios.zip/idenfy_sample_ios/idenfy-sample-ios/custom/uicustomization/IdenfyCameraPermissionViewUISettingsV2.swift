//
//  IdenfyCameraPermissionViewUISettingsV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-08-19.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import UIKit
@objc open class IdenfyCameraPermissionViewUISettingsV2: NSObject {
    // Idenfy Identification Success Results View Colors

    @objc public static var idenfyCameraPermissionViewBackgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
    @objc public static var idenfyCameraPermissionViewTitleTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCameraPermissionViewDescriptionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCameraPermissionViewGuidancePermissionTextColor = IdenfyCommonColors.idenfySecondColorV2
    @objc public static var idenfyCameraPermissionViewGoToSettingsButtonTextColor = IdenfyCommonColors.idenfyWhite

    // Idenfy Identification Success Results Fonts

    @objc public static var idenfyCameraPermissionViewTitleFont = UIFont(name: ConstsIdenfyFonts.idenfyFontBoldV2, size: 22)
    @objc public static var idenfyCameraPermissionViewDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 13)
    @objc public static var idenfyCameraPermissionViewGuidanceDescriptionFont = UIFont(name: ConstsIdenfyFonts.idenfyFontRegularV2, size: 14)
}
