//
//  DocumentCameraViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2020-12-04.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class DocumentCameraViewV2: UIView, DocumentCameraViewableV2 {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public convenience init() {
        self.init(frame: CGRect.zero)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public lazy var cameraView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        view.backgroundColor = .clear
        return view
    }()

    public var photoImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.backgroundColor = .clear
        return imageView
    }()
    
    public var rectanglePathView: IdenfyRectanglePathViewV2 = {
        let imageView = IdenfyRectanglePathViewV2(frame: .zero)
        imageView.isOpaque = true
        imageView.contentMode = .scaleToFill
        return imageView
    }()

    public var rectangleView: IdenfyRectangleViewV2 = {
        let view = IdenfyRectangleViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.clear
        view.tintColor = UIColor.clear
        view.isOpaque = true
        return view
    }()

    public var cameraSessionsButtons: CameraSessionsButtonsViewableV2 = {
        let view = CameraSessionsButtonsViewV2(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        return view
    }()

    @objc private func setupConstraints() {
        setupCameraView()
        setupPhotoView()
        setupRectangleView()
        setupCameraSessionsButtons()
    }

    func setupCameraSessionsButtons() {
        addSubview(cameraSessionsButtons)
        cameraSessionsButtons.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        cameraSessionsButtons.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        cameraSessionsButtons.topAnchor.constraint(equalTo: topAnchor).isActive = true
        cameraSessionsButtons.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    func setupCameraView() {
        addSubview(cameraView)
        cameraView.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        cameraView.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        cameraView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        cameraView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    func setupPhotoView() {
        cameraView.addSubview(photoImageView)
        photoImageView.topAnchor.constraint(equalTo: cameraView.topAnchor).isActive = true
        photoImageView.bottomAnchor.constraint(equalTo: cameraView.bottomAnchor).isActive = true
        photoImageView.leadingAnchor.constraint(equalTo: cameraView.leadingAnchor).isActive = true
        photoImageView.trailingAnchor.constraint(equalTo: cameraView.trailingAnchor).isActive = true
    }

    func setupRectangleView() {
        cameraView.addSubview(rectangleView)
        cameraView.addSubview(rectanglePathView)
        rectangleView.topAnchor.constraint(equalTo: cameraView.topAnchor).isActive = true
        rectangleView.bottomAnchor.constraint(equalTo: cameraView.bottomAnchor).isActive = true
        rectangleView.leadingAnchor.constraint(equalTo: cameraView.leadingAnchor).isActive = true
        rectangleView.trailingAnchor.constraint(equalTo: cameraView.trailingAnchor).isActive = true
    }
}
