//
//  PrivacyPolicyViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 2022-11-11.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie
import WebKit

@objc open class PrivacyPolicyViewV2: UIView, PrivacyPolicyViewableV2 {
    open weak var delegate: PrivacyPolicyViewButtonActionsDelegate?

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var privacyPolicyTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCommonInformationTitleTextColor
        return label
    }()
    
    public var privacyPolicyWebViewLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_animation_nfc_screen_loading_indicator", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.loopMode = .loop
        lottieView.alpha = 0.4
        return lottieView
    }()
    
    public var privacyPolicyWebView: WKWebView = {
        let webview = WKWebView(frame: .zero)
        webview.translatesAutoresizingMaskIntoConstraints = false
        webview.backgroundColor = .clear
        webview.configuration.allowsInlineMediaPlayback = true
        webview.configuration.mediaTypesRequiringUserActionForPlayback = []
        webview.isOpaque = false
        webview.isHidden = true
        return webview
    }()

    public var privacyPolicyAgreeButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var privacyPolicyDisagreeButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.backgroundColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyDisagreeButtonBackgroundColor
        button.titleLabel?.textAlignment = .center
        button.layer.masksToBounds = true
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.borderWidth = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyViewDisagreeButtonBorderWidth
        button.layer.borderColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyDisagreeButtonBorderColor.cgColor
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.loopMode = .loop
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.isHidden = true
        return lottieView
    }()

    open func setupConstraints() {
        backgroundColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupCenterView()
        setupButtonActions()
    }

    private func setupButtonActions() {
        privacyPolicyAgreeButton.addTarget(self, action: #selector(agreeButtonPressed), for: .touchUpInside)
        privacyPolicyDisagreeButton.addTarget(self, action: #selector(disagreeButtonPressed), for: .touchUpInside)
    }

    @objc func agreeButtonPressed() {
        delegate?.agreeButtonPressed()
    }
    
    @objc func disagreeButtonPressed() {
        delegate?.disagreeButtonPressed()
    }

    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }

    open func setupCenterView() {
        addSubview(privacyPolicyTitle)
        privacyPolicyTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        privacyPolicyTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        privacyPolicyTitle.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 24).isActive = true
        
        addSubview(privacyPolicyWebView)
        privacyPolicyWebView.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 24).isActive = true
        privacyPolicyWebView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        privacyPolicyWebView.topAnchor.constraint(equalTo: privacyPolicyTitle.bottomAnchor, constant: 16).isActive = true
        let bottom = privacyPolicyWebView.bottomAnchor.constraint(equalTo: privacyPolicyAgreeButton.topAnchor, constant: -32)
        bottom.priority = .fittingSizeLevel
        bottom.isActive = true
        
        addSubview(privacyPolicyWebViewLoadingSpinner)
        privacyPolicyWebViewLoadingSpinner.centerXAnchor.constraint(equalTo: privacyPolicyWebView.centerXAnchor).isActive = true
        privacyPolicyWebViewLoadingSpinner.centerYAnchor.constraint(equalTo: privacyPolicyWebView.centerYAnchor).isActive = true
        privacyPolicyWebViewLoadingSpinner.widthAnchor.constraint(equalToConstant: 200).isActive = true
        privacyPolicyWebViewLoadingSpinner.heightAnchor.constraint(equalToConstant: 200).isActive = true
    }

    open func setupContinueButton() {
        addSubview(privacyPolicyDisagreeButton)
        privacyPolicyDisagreeButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        privacyPolicyDisagreeButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        privacyPolicyDisagreeButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        privacyPolicyDisagreeButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(privacyPolicyAgreeButton)
        privacyPolicyAgreeButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        privacyPolicyAgreeButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        privacyPolicyAgreeButton.bottomAnchor.constraint(equalTo: privacyPolicyDisagreeButton.topAnchor, constant: -16).isActive = true
        privacyPolicyAgreeButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(loadingSpinner)
        loadingSpinner.centerYAnchor.constraint(equalTo: privacyPolicyAgreeButton.centerYAnchor).isActive = true
        loadingSpinner.leftAnchor.constraint(equalTo: privacyPolicyAgreeButton.safeLeftAnchor, constant: 16).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    open func applyGradients() {
        privacyPolicyAgreeButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}


