//
//  PrivacyPolicyViewV2.swift
//  testing
//
//  Created by Viktas Juškys on 2022-11-11.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie

@objc open class PrivacyPolicyViewV2: UIView, PrivacyPolicyViewableV2 {
    open weak var delegate: PrivacyPolicyViewButtonActionsDelegate?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }
    
    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }
    
    public var toolbar: IdenfyToolbarV2WithLanguageSelection = {
        let toolbar = IdenfyToolbarV2WithLanguageSelection(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()
    
    public var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    
    public var contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var privacyPolicyTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCommonInformationTitleTextColor
        return label
    }()
    
    public var privacyPolicyDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCommonInformationDescriptionTextColor
        return label
    }()
    
    public var processStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.backgroundColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardBackgroundColor
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.clipsToBounds = true
        stack.layer.cornerRadius = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardBorderRadius
        return stack
    }()
    
    public var processHeaderView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var processTitleLabel: UILabel = {
        let label = UILabel()
        label.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardTitleFont
        label.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardTitleTextColor
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    public var processArrowImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        return imageView
    }()
    
    public var processContentView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 16
        stack.isLayoutMarginsRelativeArrangement = true
        stack.layoutMargins = UIEdgeInsets(top: 0, left: 16, bottom: 16, right: 16)
        stack.isHidden = false
        return stack
    }()
    
    public var photoIdentityStepIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_photo_identity_step", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var photoIdentityStepTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var selfieStepIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_selfie_check_step", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var selfieStepTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var automatedVerificationStepIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_automated_verification_step", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var automatedVerificationStepTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var dataProtectionStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.backgroundColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardBackgroundColor
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.clipsToBounds = true
        stack.layer.cornerRadius = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardBorderRadius
        return stack
    }()
    
    public var dataProtectionHeaderView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var dataProtectionTitleLabel: UILabel = {
        let label = UILabel()
        label.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardTitleFont
        label.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardTitleTextColor
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    public var dataProtectionArrowImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    public var dataProtectionContentView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 16
        stack.isLayoutMarginsRelativeArrangement = true
        stack.layoutMargins = UIEdgeInsets(top: 0, left: 16, bottom: 16, right: 16)
        stack.isHidden = false
        return stack
    }()
    
    public var secureEncryptionIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_lock", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var secureEncryptionTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var limitedAccessIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_access", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var limitedAccessTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var neverSoldIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_block_share", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var neverSoldTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var usedForVerificationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "idenfy_ic_privacy_security", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemIconColor
        return imageView
    }()
    
    public var usedForVerificationTitle: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var complianceStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.backgroundColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardBackgroundColor
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.clipsToBounds = true
        stack.layer.cornerRadius = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardBorderRadius
        return stack
    }()
    
    public var complianceHeaderView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public var complianceTitleLabel: UILabel = {
        let label = UILabel()
        label.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardTitleFont
        label.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardTitleTextColor
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    public var complianceArrowImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "idenfy_ic_arrow_down", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    public var complianceContentView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 16
        stack.isLayoutMarginsRelativeArrangement = true
        stack.layoutMargins = UIEdgeInsets(top: 0, left: 16, bottom: 16, right: 16)
        stack.isHidden = false
        return stack
    }()
    
    public var complianceDescription: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        return uilabel
    }()
    
    public var privacyPolicyText: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        uilabel.textAlignment = .center
        uilabel.isUserInteractionEnabled = true
        return uilabel
    }()
    
    public var partnerPrivacyPolicyText: UILabel = {
        let uilabel = UILabel()
        uilabel.font = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemFont
        uilabel.textColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyCardItemTextColor
        uilabel.translatesAutoresizingMaskIntoConstraints = false
        uilabel.numberOfLines = 0
        uilabel.textAlignment = .center
        uilabel.isUserInteractionEnabled = true
        return uilabel
    }()
    
    public var privacyPolicyAgreeButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.contentHorizontalAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var loadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        if let path = Bundle(identifier: "com.idenfy.idenfyviews")?.path(forResource: "idenfy_custom_country_loader", ofType: "json") {
            lottieView.animation = LottieAnimation.filepath(path)
        }
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.backgroundBehavior = .pauseAndRestore
        lottieView.loopMode = .loop
        lottieView.isHidden = true
        return lottieView
    }()
    
    open func setupConstraints() {
        backgroundColor = IdenfyPrivacyPolicyViewUISettingsV2.idenfyPrivacyPolicyViewBackgroundColor
        setupToolbar()
        setupContinueButton()
        setupScrollView()
        setupCenterView()
        setupDataProtectionCard()
        setupProcessCard()
        setupComplianceCard()
        setupPrivacyPolicyTexts()
        setupButtonActions()
    }
    
    private func setupButtonActions() {
        privacyPolicyAgreeButton.addTarget(self, action: #selector(agreeButtonPressed), for: .touchUpInside)
        dataProtectionHeaderView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dataProtectionHeaderViewPressed)))
        processHeaderView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(processHeaderViewPressed)))
        complianceHeaderView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(complianceHeaderViewPressed)))
        privacyPolicyText.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(privacyPolicyTextViewPressed)))
        partnerPrivacyPolicyText.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(partnerPrivacyPolicyTextViewPressed)))
    }
    
    @objc func processHeaderViewPressed() {
        delegate?.processHeaderViewPressed()
    }
    
    @objc func dataProtectionHeaderViewPressed() {
        delegate?.dataProtectionHeaderViewPressed()
    }
    
    @objc func complianceHeaderViewPressed() {
        delegate?.complianceHeaderViewPressed()
    }
    
    @objc func privacyPolicyTextViewPressed() {
        delegate?.privacyPolicyTextViewPressed()
    }
    
    @objc func partnerPrivacyPolicyTextViewPressed() {
        delegate?.partnerPrivacyPolicyTextViewPressed()
    }
    
    @objc func agreeButtonPressed() {
        delegate?.agreeButtonPressed()
    }
    
    open func setupToolbar() {
        addSubview(toolbar)
        toolbar.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        toolbar.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        toolbar.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        toolbar.heightAnchor.constraint(equalToConstant: IdenfyToolbarUISettingsV2.idenfyToolbarHeight).isActive = true
    }
    
    open func setupScrollView() {
        addSubview(scrollView)
        scrollView.topAnchor.constraint(equalTo: toolbar.bottomAnchor).isActive = true
        scrollView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        scrollView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: privacyPolicyAgreeButton.topAnchor, constant: -8).isActive = true
        
        scrollView.addSubview(contentView)
        contentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentView.leftAnchor.constraint(equalTo: scrollView.leftAnchor).isActive = true
        contentView.rightAnchor.constraint(equalTo: scrollView.rightAnchor).isActive = true
        contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }
    
    open func setupCenterView() {
        contentView.addSubview(privacyPolicyTitle)
        privacyPolicyTitle.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        privacyPolicyTitle.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        privacyPolicyTitle.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 24).isActive = true
        
        contentView.addSubview(privacyPolicyDescription)
        privacyPolicyDescription.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        privacyPolicyDescription.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        privacyPolicyDescription.topAnchor.constraint(equalTo: privacyPolicyTitle.bottomAnchor, constant: 24).isActive = true
    }
    
    open func setupProcessCard() {
        contentView.addSubview(processStackView)
        processStackView.topAnchor.constraint(equalTo: dataProtectionStackView.bottomAnchor, constant: 12).isActive = true
        processStackView.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        processStackView.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        
        processStackView.addArrangedSubview(processHeaderView)
        processStackView.addArrangedSubview(processContentView)
        
        processHeaderView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        processHeaderView.addSubview(processTitleLabel)
        processHeaderView.addSubview(processArrowImageView)
        
        processArrowImageView.centerYAnchor.constraint(equalTo: processHeaderView.centerYAnchor).isActive = true
        processArrowImageView.trailingAnchor.constraint(equalTo: processHeaderView.trailingAnchor, constant: -16).isActive = true
        processArrowImageView.widthAnchor.constraint(equalToConstant: 20).isActive = true
        processTitleLabel.centerYAnchor.constraint(equalTo: processArrowImageView.centerYAnchor).isActive = true
        processTitleLabel.leadingAnchor.constraint(equalTo: processHeaderView.leadingAnchor, constant: 16).isActive = true
        processTitleLabel.trailingAnchor.constraint(equalTo: processArrowImageView.leadingAnchor, constant: -16).isActive = true
        
        processContentView.addArrangedSubview(createRow(icon: photoIdentityStepIcon, label: photoIdentityStepTitle))
        processContentView.addArrangedSubview(createRow(icon: selfieStepIcon, label: selfieStepTitle))
        processContentView.addArrangedSubview(createRow(icon: automatedVerificationStepIcon, label: automatedVerificationStepTitle))
    }
    
    open func setupDataProtectionCard() {
        contentView.addSubview(dataProtectionStackView)
        dataProtectionStackView.topAnchor.constraint(equalTo: privacyPolicyDescription.bottomAnchor, constant: 24).isActive = true
        dataProtectionStackView.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        dataProtectionStackView.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        
        dataProtectionStackView.addArrangedSubview(dataProtectionHeaderView)
        dataProtectionStackView.addArrangedSubview(dataProtectionContentView)
        
        dataProtectionHeaderView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        dataProtectionHeaderView.addSubview(dataProtectionTitleLabel)
        dataProtectionHeaderView.addSubview(dataProtectionArrowImageView)
        
        dataProtectionArrowImageView.centerYAnchor.constraint(equalTo: dataProtectionHeaderView.centerYAnchor).isActive = true
        dataProtectionArrowImageView.trailingAnchor.constraint(equalTo: dataProtectionHeaderView.trailingAnchor, constant: -16).isActive = true
        dataProtectionArrowImageView.widthAnchor.constraint(equalToConstant: 20).isActive = true
        dataProtectionTitleLabel.centerYAnchor.constraint(equalTo: dataProtectionArrowImageView.centerYAnchor).isActive = true
        dataProtectionTitleLabel.leadingAnchor.constraint(equalTo: dataProtectionHeaderView.leadingAnchor, constant: 16).isActive = true
        dataProtectionTitleLabel.trailingAnchor.constraint(equalTo: dataProtectionArrowImageView.leadingAnchor, constant: -16).isActive = true
        
        dataProtectionContentView.addArrangedSubview(createRow(icon: secureEncryptionIcon, label: secureEncryptionTitle))
        dataProtectionContentView.addArrangedSubview(createRow(icon: limitedAccessIcon, label: limitedAccessTitle))
        dataProtectionContentView.addArrangedSubview(createRow(icon: neverSoldIcon, label: neverSoldTitle))
        dataProtectionContentView.addArrangedSubview(createRow(icon: usedForVerificationIcon, label: usedForVerificationTitle))
    }
    
    open func setupComplianceCard() {
        contentView.addSubview(complianceStackView)
        complianceStackView.topAnchor.constraint(equalTo: processStackView.bottomAnchor, constant: 12).isActive = true
        complianceStackView.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        complianceStackView.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        
        complianceStackView.addArrangedSubview(complianceHeaderView)
        complianceStackView.addArrangedSubview(complianceContentView)
        
        complianceHeaderView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        complianceHeaderView.addSubview(complianceTitleLabel)
        complianceHeaderView.addSubview(complianceArrowImageView)
        
        complianceArrowImageView.centerYAnchor.constraint(equalTo: complianceHeaderView.centerYAnchor).isActive = true
        complianceArrowImageView.trailingAnchor.constraint(equalTo: complianceHeaderView.trailingAnchor, constant: -16).isActive = true
        complianceArrowImageView.widthAnchor.constraint(equalToConstant: 20).isActive = true
        complianceTitleLabel.centerYAnchor.constraint(equalTo: complianceArrowImageView.centerYAnchor).isActive = true
        complianceTitleLabel.leadingAnchor.constraint(equalTo: processHeaderView.leadingAnchor, constant: 16).isActive = true
        complianceTitleLabel.trailingAnchor.constraint(equalTo: complianceArrowImageView.leadingAnchor, constant: -16).isActive = true
        
        complianceContentView.addArrangedSubview(complianceDescription)
    }
    
    private func setupPrivacyPolicyTexts() {
        contentView.addSubview(privacyPolicyText)
        privacyPolicyText.topAnchor.constraint(equalTo: complianceStackView.bottomAnchor, constant: 24).isActive = true
        privacyPolicyText.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        privacyPolicyText.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        
        contentView.addSubview(partnerPrivacyPolicyText)
        partnerPrivacyPolicyText.topAnchor.constraint(equalTo: privacyPolicyText.bottomAnchor, constant: 24).isActive = true
        partnerPrivacyPolicyText.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 16).isActive = true
        partnerPrivacyPolicyText.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: -16).isActive = true
        partnerPrivacyPolicyText.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -24).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(privacyPolicyAgreeButton)
        privacyPolicyAgreeButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        privacyPolicyAgreeButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        privacyPolicyAgreeButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -16).isActive = true
        privacyPolicyAgreeButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(loadingSpinner)
        loadingSpinner.centerYAnchor.constraint(equalTo: privacyPolicyAgreeButton.centerYAnchor).isActive = true
        loadingSpinner.leftAnchor.constraint(equalTo: privacyPolicyAgreeButton.safeLeftAnchor, constant: 16).isActive = true
        loadingSpinner.widthAnchor.constraint(equalToConstant: 25).isActive = true
        loadingSpinner.heightAnchor.constraint(equalToConstant: 25).isActive = true
    }
    
    private func createRow(icon: UIImageView, label: UILabel) -> UIStackView {
        let row = UIStackView(arrangedSubviews: [icon, label])
        row.axis = .horizontal
        row.spacing = 8
        row.alignment = .center
        icon.widthAnchor.constraint(equalToConstant: 22).isActive = true
        icon.heightAnchor.constraint(equalToConstant: 22).isActive = true
        return row
    }
    
    open func applyGradients() {
        privacyPolicyAgreeButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
