//
//  CameraOnBoardingViewV2.swift
//  testing
//
//  Created by Viktas Juskys on 2021-12-01.
//  Copyright © 2021 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews
import Lottie
import UIKit
import AVFoundation

@objc open class DynamicCameraOnBoardingViewV2: UIView, DynamicCameraOnBoardingViewableV2 {
    open weak var delegate: DynamicCameraOnBoardingViewButtonActionsDelegate?
    
    public var documentTypeData: DocumentTypeData!
    public var shouldInstructionsBePlayed: Bool! {
        didSet {
            setupConstraints()
        }
    }
    public var currentStep: Step!
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: .zero)
    }

    public var idenfyToolbarV2Common: IdenfyCameraOnBoardingToolbarV2 = {
        let toolbar = IdenfyCameraOnBoardingToolbarV2(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    public var idenfyUILabelCameraOnBoardingCommonInformationTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationTitleTextColor
        return label
    }()

    public var idenfyUILabelCameraOnBoardingCommonInformationDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingCommonInformationDescriptionTextColor
        return label
    }()

    public var idenfyUIImageViewCameraOnBoardingCommonInformationIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.image = UIImage(named: "idenfy_ic_camera_onboarding_other_document_image", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var idenfyUIEnabledButtonCameraOnBoardingContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingEnabledContinueButtonTextColor, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.isHidden = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var idenfyUIDisabledButtonCameraOnBoardingContinue: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.isUserInteractionEnabled = true
        button.setTitleColor(IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonTextColor, for: .normal)
        button.backgroundColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDisabledContinueButtonBackgroundColor
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.titleLabel?.font = IdenfyButtonsUISettingsV2.idenfyButtonFont
        return button
    }()
    
    public var instrutionCameraOnBoardingVideoContainer: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        return view
    }()
    
    public var instructionCameraOnBoardingProgressView: UIProgressView = {
        let progressView = UIProgressView(frame: .zero)
        progressView.translatesAutoresizingMaskIntoConstraints = false
        progressView.progressTintColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewProgressBarFillColor
        progressView.trackTintColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewProgressBackgroundColor
        return progressView
    }()
    
    public var instructionsDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDetailsCardTitleFont
        label.textAlignment = .left
        label.textColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDetailsCardTitleColor
        return label
    }()
    
    public var instructionsDetailsCard: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDetailsCardBackgroundColor
        view.layer.cornerRadius = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingDetailsCardCornerRadius
        return view
    }()

    public var instructionsDetailsCardQuestionMark: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.masksToBounds = true
        imageView.image = UIImage(named: "idenfy_ic_photo_result_view_details_card_questionmark", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var idenfyLoadingSpinner: LottieAnimationView = {
        let lottieView = LottieAnimationView(frame: .zero)
        lottieView.translatesAutoresizingMaskIntoConstraints = false
        lottieView.contentMode = .scaleAspectFit
        lottieView.play()
        lottieView.loopMode = .loop
        lottieView.backgroundBehavior = .pauseAndRestore
        return lottieView
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyDynamicCameraOnBoardingViewUISettingsV2.idenfyCameraOnBoardingViewBackgroundColor
        setupToolbar()
        setupTopTitle()
        setupContinueButton()
        setupButtonActions()
        if shouldInstructionsBePlayed {
            setupCenterVideoView()
        } else {
            setupCenterImageView()
        }
    }

    private func setupButtonActions() {
        idenfyUIEnabledButtonCameraOnBoardingContinue.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
    }

    @objc func continueButtonPressed() {
        delegate?.continueButtonPressedAction()
    }
    
    public func playInstructions(_ trustedPartner: Bool) -> InstructionVideo {
        let instructionVideo = InstructionVideo(frame: instrutionCameraOnBoardingVideoContainer.bounds)
        switch currentStep! {
        case Step.FACE:
            instructionVideo.configure("idenfy_instructions_face_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
        case Step.LIVENESS:
            instructionVideo.configure("idenfy_instructions_liveness_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
        default:
            switch trustedPartner {
            case true:
                instructionVideo.configure("idenfy_instructions_document_trusted_partner", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
            case false:
                instructionVideo.configure("idenfy_instructions_document_generic", instrutionCameraOnBoardingVideoContainer.bounds, AVLayerVideoGravity.resizeAspect)
            }
        }
        instructionVideo.isLoop = true
        instructionVideo.play()
        instrutionCameraOnBoardingVideoContainer.addSubview(instructionVideo)
        return instructionVideo
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupTopTitle() {
        addSubview(idenfyUILabelCameraOnBoardingCommonInformationTitle)
        idenfyUILabelCameraOnBoardingCommonInformationTitle.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationTitle.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 24).isActive = true

        addSubview(idenfyUILabelCameraOnBoardingCommonInformationDescription)
        idenfyUILabelCameraOnBoardingCommonInformationDescription.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationDescription.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUILabelCameraOnBoardingCommonInformationDescription.topAnchor.constraint(equalTo: idenfyUILabelCameraOnBoardingCommonInformationTitle.bottomAnchor, constant: 16).isActive = true
    }
    
    open func setupCenterVideoView() {
        addSubview(idenfyLoadingSpinner)
        idenfyLoadingSpinner.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyLoadingSpinner.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        idenfyLoadingSpinner.heightAnchor.constraint(equalToConstant: 130).isActive = true
        idenfyLoadingSpinner.widthAnchor.constraint(equalToConstant: 130).isActive = true
        
        addSubview(instrutionCameraOnBoardingVideoContainer)
        instrutionCameraOnBoardingVideoContainer.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        instrutionCameraOnBoardingVideoContainer.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -16).isActive = true
        instrutionCameraOnBoardingVideoContainer.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16).isActive = true
        instrutionCameraOnBoardingVideoContainer.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16).isActive = true
        instrutionCameraOnBoardingVideoContainer.heightAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.widthAnchor, multiplier: 0.6).isActive = true
        
        addSubview(instructionCameraOnBoardingProgressView)
        instructionCameraOnBoardingProgressView.topAnchor.constraint(equalTo: instrutionCameraOnBoardingVideoContainer.bottomAnchor, constant: 16).isActive = true
        instructionCameraOnBoardingProgressView.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 16).isActive = true
        instructionCameraOnBoardingProgressView.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -16).isActive = true
        instructionCameraOnBoardingProgressView.heightAnchor.constraint(equalToConstant: 5).isActive = true
        
        addSubview(instructionsDetailsCard)
        instructionsDetailsCard.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        instructionsDetailsCard.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        instructionsDetailsCard.topAnchor.constraint(equalTo: instructionCameraOnBoardingProgressView.bottomAnchor, constant: 16).isActive = true
        instructionsDetailsCard.heightAnchor.constraint(equalToConstant: 50).isActive = true

        instructionsDetailsCard.addSubview(instructionsDetailsCardQuestionMark)
        instructionsDetailsCardQuestionMark.leftAnchor.constraint(equalTo: instructionsDetailsCard.safeLeftAnchor, constant: 16).isActive = true
        instructionsDetailsCardQuestionMark.topAnchor.constraint(equalTo: instructionsDetailsCard.safeTopAnchor).isActive = true
        instructionsDetailsCardQuestionMark.bottomAnchor.constraint(equalTo: instructionsDetailsCard.safeBottomAnchor).isActive = true

        instructionsDetailsCard.addSubview(instructionsDescription)
        instructionsDescription.leftAnchor.constraint(equalTo: instructionsDetailsCard.safeLeftAnchor, constant: 50).isActive = true
        instructionsDescription.rightAnchor.constraint(equalTo: instructionsDetailsCard.safeRightAnchor, constant: -24).isActive = true
        instructionsDescription.topAnchor.constraint(equalTo: instructionsDetailsCard.safeTopAnchor).isActive = true
        instructionsDescription.bottomAnchor.constraint(equalTo: instructionsDetailsCard.safeBottomAnchor).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(idenfyUIImageViewCameraOnBoardingCommonInformationIcon)
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -16).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.widthAnchor.constraint(equalToConstant: 170).isActive = true
        idenfyUIImageViewCameraOnBoardingCommonInformationIcon.heightAnchor.constraint(equalTo: idenfyUIImageViewCameraOnBoardingCommonInformationIcon.heightAnchor).isActive = true
    }

    open func setupContinueButton() {
        addSubview(idenfyUIEnabledButtonCameraOnBoardingContinue)
        idenfyUIEnabledButtonCameraOnBoardingContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIEnabledButtonCameraOnBoardingContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
        
        addSubview(idenfyUIDisabledButtonCameraOnBoardingContinue)
        idenfyUIDisabledButtonCameraOnBoardingContinue.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        idenfyUIDisabledButtonCameraOnBoardingContinue.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
    
    open func applyGradients() {
        idenfyUIEnabledButtonCameraOnBoardingContinue.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
}
