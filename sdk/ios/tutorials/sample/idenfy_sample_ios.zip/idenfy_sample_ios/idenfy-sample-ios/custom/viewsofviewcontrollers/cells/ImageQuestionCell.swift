//
//  ImageQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2022-09-26.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class ImageQuestionCell: UITableViewCell, ImageQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var imageUploadContainerView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerBackgroundColor
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerBorderColor
        view.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerBorderWidth
        view.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewContainerCornerRadius
        return view
    }()
    
    public var imageUploadButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "idenfy_ic_confirmation_upload_photo", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.isUserInteractionEnabled = true
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewUploadIconTintColor
        return button
    }()
    
    public var cancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.isUserInteractionEnabled = true
        button.isHidden = true
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewCancelIconTintColor
        button.imageEdgeInsets = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 4)
        return button
    }()
    
    public var imagePlaceHolder: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewFileDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyFileQuestionCellViewFileDescriptionTextColor
        return label
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(imageUploadContainerView)
        imageUploadContainerView.leftAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        imageUploadContainerView.rightAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        imageUploadContainerView.heightAnchor.constraint(equalToConstant: 80).isActive = true
        imageUploadContainerView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        imageUploadContainerView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        
        cellView.addSubview(imageUploadButton)
        imageUploadButton.centerXAnchor.constraint(equalTo: imageUploadContainerView.centerXAnchor).isActive = true
        imageUploadButton.centerYAnchor.constraint(equalTo: imageUploadContainerView.centerYAnchor, constant: -16).isActive = true
        imageUploadButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        imageUploadButton.heightAnchor.constraint(equalToConstant: 35).isActive = true
        
        cellView.addSubview(cancelButton)
        cancelButton.rightAnchor.constraint(equalTo: imageUploadContainerView.rightAnchor, constant: -4).isActive = true
        cancelButton.topAnchor.constraint(equalTo: imageUploadContainerView.topAnchor, constant: 4).isActive = true
        cancelButton.widthAnchor.constraint(equalToConstant: 26).isActive = true
        cancelButton.heightAnchor.constraint(equalToConstant: 26).isActive = true
        
        cellView.addSubview(imagePlaceHolder)
        imagePlaceHolder.topAnchor.constraint(equalTo: imageUploadButton.bottomAnchor).isActive = true
        imagePlaceHolder.bottomAnchor.constraint(equalTo: imageUploadContainerView.bottomAnchor, constant: -8).isActive = true
        imagePlaceHolder.leftAnchor.constraint(equalTo: imageUploadContainerView.leftAnchor, constant: 16).isActive = true
        imagePlaceHolder.rightAnchor.constraint(equalTo: imageUploadContainerView.rightAnchor, constant: -16).isActive = true
    }
}


