//
//  DateTimeQuestionCell.swift
//  testing
//
//  Created by Viktas Juškys on 2022-09-26.
//  Copyright © 2022 iDenfy. All rights reserved.
//

import Foundation
import idenfycore
import iDenfySDK
import idenfyviews

@objc open class DateTimeQuestionCell: UITableViewCell, DateTimeQuestionCellViewable {

    public let cellView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public var questionTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTitleTextColor
        return label
    }()

    public var questionDescription: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewDescriptionTextColor
        return label
    }()
    
    public var dateTimeInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellTextFieldFont
        textField.textAlignment = .left
        textField.textColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldTextColor
        textField.backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBackgroundColor
        textField.layer.cornerRadius = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldCornerRadius
        textField.layer.borderWidth = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderWidth
        textField.layer.borderColor = IdenfyQuestionnaireViewUISettingsV2.idenfyTextQuestionCellViewTextFieldBorderColor.cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        return textField
    }()
    
    public var cancelButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isOpaque = true
        button.isHidden = true
        button.isUserInteractionEnabled = true
        button.imageEdgeInsets = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 0)
        button.setImage(UIImage(named: "idenfy_ic_language_selection_close_button", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyDateQuestionCellViewCancelButtonTintColor
        return button
    }()
    
    public var calendarIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.tintColor = IdenfyQuestionnaireViewUISettingsV2.idenfyDateQuestionCellViewCalendarIconTintColor
        imageView.image = UIImage(named: "idenfy_ic_calendar", in: Bundle(identifier: "com.idenfy.idenfyviews"), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        return imageView
    }()

    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: .zero)
    }

    private func setupView() {
        backgroundColor = IdenfyQuestionnaireViewUISettingsV2.idenfyQuestionnaireViewBackgroundColor
        addSubview(cellView)
        cellView.topAnchor.constraint(equalTo: safeTopAnchor).isActive = true
        cellView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true
        cellView.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        cellView.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true

        cellView.addSubview(questionTitle)
        questionTitle.leftAnchor.constraint(equalTo: cellView.safeLeftAnchor, constant: 16).isActive = true
        questionTitle.rightAnchor.constraint(equalTo: cellView.safeRightAnchor, constant: -16).isActive = true
        questionTitle.topAnchor.constraint(equalTo: cellView.safeTopAnchor, constant: 24).isActive = true
        
        cellView.addSubview(questionDescription)
        questionDescription.widthAnchor.constraint(equalTo: questionTitle.widthAnchor, multiplier: 0.9).isActive = true
        questionDescription.centerXAnchor.constraint(equalTo: cellView.centerXAnchor).isActive = true
        questionDescription.topAnchor.constraint(equalTo: questionTitle.safeBottomAnchor, constant: 16).isActive = true
        
        cellView.addSubview(dateTimeInputView)
        dateTimeInputView.leftAnchor.constraint(equalTo: questionDescription.safeLeftAnchor).isActive = true
        dateTimeInputView.rightAnchor.constraint(equalTo: questionDescription.safeRightAnchor).isActive = true
        dateTimeInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        dateTimeInputView.topAnchor.constraint(equalTo: questionDescription.safeBottomAnchor, constant: 16).isActive = true
        dateTimeInputView.bottomAnchor.constraint(equalTo: cellView.safeBottomAnchor).isActive = true
        
        cellView.addSubview(cancelButton)
        cancelButton.heightAnchor.constraint(equalToConstant: 25).isActive = true
        cancelButton.widthAnchor.constraint(equalToConstant: 25).isActive = true
        cancelButton.rightAnchor.constraint(equalTo: dateTimeInputView.rightAnchor, constant: -16).isActive = true
        cancelButton.centerYAnchor.constraint(equalTo: dateTimeInputView.centerYAnchor).isActive = true
        
        cellView.addSubview(calendarIcon)
        calendarIcon.heightAnchor.constraint(equalToConstant: 25).isActive = true
        calendarIcon.widthAnchor.constraint(equalToConstant: 25).isActive = true
        calendarIcon.rightAnchor.constraint(equalTo: dateTimeInputView.rightAnchor, constant: -16).isActive = true
        calendarIcon.centerYAnchor.constraint(equalTo: dateTimeInputView.centerYAnchor).isActive = true
    }
}


