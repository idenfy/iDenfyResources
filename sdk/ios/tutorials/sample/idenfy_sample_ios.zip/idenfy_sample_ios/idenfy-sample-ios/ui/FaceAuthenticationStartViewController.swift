//
//  FaceAuthenticationStartViewController.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 2022-07-05.
//  Copyright © 2022 Viktor Vostrikov. All rights reserved.
//

import Foundation
import UIKit
import idenfycore
import idenfyviews
import iDenfySDK

extension FaceAuthenticationStartViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
          nextField.becomeFirstResponder()
       } else {
          textField.resignFirstResponder()
       }
       return false
    }
    
    func textField(_ textFieldToChange: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let characterCountLimit = 50
        let startingLength = textFieldToChange.text?.count ?? 0
        let lengthToAdd = string.count
        let lengthToReplace = range.length
        
        let newLength = startingLength + lengthToAdd - lengthToReplace
        
        return newLength <= characterCountLimit
    }
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        switch textField {
        case scanrefInputView:
            if scanrefInputView.text?.isEmpty == true {
                scanRefHintLabel.isHidden = true
            } else {
                scanRefHintLabel.isHidden = false
            }
            scanrefInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        default:
            break
        }
        
        if scanrefInputView.text?.isEmpty == true {
            continueButton.isUserInteractionEnabled = false
            continueButton.alpha = 0.4
        } else {
            continueButton.isUserInteractionEnabled = true
            continueButton.alpha = 1
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case scanrefInputView:
            scanrefInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        default:
            break
        }
    }
}

class FaceAuthenticationStartViewController: UIViewController {
    
    private var session: URLSession!
    
    private var continueButton: UIButton!
    var scanrefInputView: UITextField!
    private var scanRefHintLabel: UILabel!
    
    @objc func startFaceAuthentication(_ sender:AnyObject) {
        //Possibility to input scanref here and test from code
        var scanRef = ""
        if scanRef.isEmpty {
            scanRef = scanrefInputView.text!
        }
        scanrefInputView.text = ""
        scanRefHintLabel.isHidden = true
        continueButton.isUserInteractionEnabled = false
        continueButton.alpha = 0.4
        
        checkFaceAuthenticationType(scanRef: scanRef)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let swipeGestureRecognizerDown = UISwipeGestureRecognizer(target: self, action: #selector(backButtonPressed(_:)))
        swipeGestureRecognizerDown.direction = .right
        view.addGestureRecognizer(swipeGestureRecognizerDown)
    }
    
    @objc func backButtonPressed(_ sender:AnyObject){
        dismiss(animated: false)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }
    
    override func loadView() {
        let startView = FaceAuthenticationStartView(frame: .zero)
        continueButton = startView.continueButton
        scanRefHintLabel = startView.scanRefHintLabel
        scanrefInputView = startView.scanrefInputView
        view = startView
        scanrefInputView.delegate = self
        continueButton?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(startFaceAuthentication(_:))))
        startView.idenfyToolbarV2Common.backButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(backButtonPressed(_:))))
    }
    
    private func startFaceAuhtentication(_ authenticationToken: String) {
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)

        print("Idenfy SDK version - ", idenfyController.getIdenfySDKVersion())
        
        idenfyController.handleIdenfyCallbacksForFaceAuthentication(faceAuthenticationResult: { faceAuthenticationResult in
            print("FaceAuthenticationStatus: ", faceAuthenticationResult.faceAuthenticationStatus.rawValue)
            switch faceAuthenticationResult.faceAuthenticationStatus {
            case .SUCCESS:
                // The user completed authentication flow, was successfully authenticated
                break
            case .FAILED:
                // The user completed authentication flow, was not successfully authenticated
                break
            case .EXIT:
                // The user did not complete authentication flow
                break
            @unknown default:
                break
            }
        })
    }
    
    private func startFaceAuhtenticationWithCustomViews(_ authenticationToken: String) {
        let idenfyController = IdenfyController.shared
        
        let idenfyFaceAuthUISettings = IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(false)
            .build()
        
        let faceAuthenticationInitialization = FaceAuthenticationInitialization(authenticationToken: authenticationToken, withImmediateRedirect: false, idenfyFaceAuthUISettings: idenfyFaceAuthUISettings)
        
        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withFaceAuthenticationSplashScreenV2View(FaceAuthenticationSplashScreenV2View())
            .build()
        
        idenfyController.initializeFaceAuthentication(faceAuthenticationInitialization: faceAuthenticationInitialization, idenfyViewsV2: idenfyViewsV2)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)

        print("Idenfy SDK version - ", idenfyController.getIdenfySDKVersion())
        
        idenfyController.handleIdenfyCallbacksForFaceAuthentication(faceAuthenticationResult: { faceAuthenticationResult in
            print("FaceAuthenticationStatus: ", faceAuthenticationResult.faceAuthenticationStatus.rawValue)
            switch faceAuthenticationResult.faceAuthenticationStatus {
            case .SUCCESS:
                // The user completed authentication flow, was successfully authenticated
                break
            case .FAILED:
                // The user completed authentication flow, was not successfully authenticated
                break
            case .EXIT:
                // The user did not complete authentication flow
                break
            @unknown default:
                break
            }
        })
    }
    
    private func checkFaceAuthenticationType(scanRef: String) {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret

        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let config = URLSessionConfiguration.default
        config.isDiscretionary = true
        config.shouldUseExtendedBackgroundIdleMode = true
        session = URLSession(configuration: config)

        let success: (FaceAuthenticationTypeResponse) -> Void = { [weak self] response in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch response.type {
                case .authentication:
                    //The user can authenticate by face
                    self.fetchFaceAuthenticationToken(scanRef, response.type!)
                default:
                    //The user must perform an identification
                    break
                }
            }
        }
        let failure: () -> Void = {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: nil, message: "Failed to fetch token type!", preferredStyle: .actionSheet)
                self.present(alert, animated: true)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
                    alert.dismiss(animated: true)
                }
            }
        }
        
        let urlString = Consts.baseURL
        
        let endpoint = "identification/facial-auth/\(scanRef)/check-status/?method=FACE_MATCHING"
        let url = URL(string: urlString + endpoint)!
        var request = APIhelper().getRequestBody(type: "GET", url: url)
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        
        let task = session.dataTask(with: request, completionHandler: { data, response, _ in

            guard let data = data else {
                failure()
                return
            }

            let outputStr = String(data: data, encoding: String.Encoding.utf8) as String?
            debugPrint(outputStr ?? "")
            print(data.debugDescription)

            if let httpResponse = response as? HTTPURLResponse {
                debugPrint(httpResponse)

                if httpResponse.statusCode == 200 {
                    do {
                        let idenfyErrror = try JSONDecoder().decode(Throwable<FaceAuthenticationTypeResponse>.self, from: data)
                        success(idenfyErrror.value!)
                    } catch {
                        failure()
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    failure()
                } else {
                    failure()
                }
            }
        })
        task.resume()
    }
    
    func fetchFaceAuthenticationToken(_ scanRef: String, _ type: FaceAuthenticationType) {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret

        let loginString = "\(apiKey):\(apiSecret)"

        guard let loginData = loginString.data(using: String.Encoding.utf8) else {
            return
        }
        let base64LoginString = loginData.base64EncodedString()

        let config = URLSessionConfiguration.default
        config.isDiscretionary = true
        config.shouldUseExtendedBackgroundIdleMode = true
        session = URLSession(configuration: config)

        let success: (PartnerAuthenticationInfoResponse) -> Void = { [weak self] response in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch Consts.sdkInitFlow {
                case .Default:
                    self.startFaceAuhtentication(response.token)
                case .CustomWithImplementedViews:
                    self.startFaceAuhtenticationWithCustomViews(response.token)
                }
            }
        }
        let failure: () -> Void = {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: nil, message: "Failed to fetch token!", preferredStyle: .actionSheet)
                self.present(alert, animated: true)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
                    alert.dismiss(animated: true)
                }
            }
        }
        
        let urlString = Consts.baseURL
        
        let url = URL(string: urlString)!
        let uploadingRequest = url.appendingPathComponent("partner/authentication-info")
        var request = APIhelper().getRequestBody(type: "POST", url: uploadingRequest)

        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        var json: [String: Any] = [:]
        json.updateValue(scanRef, forKey: "scanRef")
        json.updateValue(type.rawValue, forKey: "type")
        json.updateValue("FACE_MATCHING", forKey: "method")
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        request.httpBody = jsonData

        let task = session.dataTask(with: request, completionHandler: { data, response, _ in

            guard let data = data else {
                failure()
                return
            }

            let outputStr = String(data: data, encoding: String.Encoding.utf8) as String?
            debugPrint(outputStr ?? "")
            print(data.debugDescription)

            if let httpResponse = response as? HTTPURLResponse {
                debugPrint(httpResponse)

                if httpResponse.statusCode == 200 {
                    do {
                        let idenfyErrror = try JSONDecoder().decode(Throwable<PartnerAuthenticationInfoResponse>.self, from: data)
                        success(idenfyErrror.value!)
                    } catch {
                        failure()
                    }
                } else if httpResponse.statusCode >= 400, httpResponse.statusCode < 500 {
                    failure()
                } else {
                    failure()
                }
            }
        })
        task.resume()
    }
}

