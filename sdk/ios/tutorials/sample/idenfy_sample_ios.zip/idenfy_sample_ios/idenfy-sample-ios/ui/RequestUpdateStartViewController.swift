//
//  RequestUpdateStartViewController.swift
//  idenfy-sample-ios
//

import Foundation
import UIKit
import idenfycore
import idenfyviews
import iDenfySDK

extension RequestUpdateStartViewController: UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return false
    }

    func textField(_ textFieldToChange: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let startingLength = textFieldToChange.text?.count ?? 0
        let lengthToAdd = string.count
        let lengthToReplace = range.length
        return (startingLength + lengthToAdd - lengthToReplace) <= 200
    }

    func textFieldDidChangeSelection(_ textField: UITextField) {
        scanRefHintLabel.isHidden = scanRefInputView.text?.isEmpty == true
        questionnaireIdHintLabel.isHidden = questionnaireIdInputView.text?.isEmpty == true

        switch textField {
        case scanRefInputView:
            scanRefInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        case questionnaireIdInputView:
            questionnaireIdInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        default:
            break
        }

        if scanRefInputView.text?.isEmpty == true {
            continueButton.isUserInteractionEnabled = false
            continueButton.alpha = 0.4
        } else {
            continueButton.isUserInteractionEnabled = true
            continueButton.alpha = 1
        }
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case scanRefInputView:
            scanRefInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        case questionnaireIdInputView:
            questionnaireIdInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        default:
            break
        }
    }
}

struct RequestInformationUpdateResponse: Codable {
    let tokenString: String?
}

class RequestUpdateStartViewController: UIViewController {

    private var session: URLSession!

    private var continueButton: UIButton!
    private var scanRefInputView: UITextField!
    private var questionnaireIdInputView: UITextField!
    private var scanRefHintLabel: UILabel!
    private var questionnaireIdHintLabel: UILabel!
    private var additionalStepSwitch: UISwitch!

    override func loadView() {
        let startView = RequestUpdateStartView(frame: .zero)
        continueButton = startView.continueButton
        scanRefInputView = startView.scanRefInputView
        questionnaireIdInputView = startView.questionnaireIdInputView
        scanRefHintLabel = startView.scanRefHintLabel
        questionnaireIdHintLabel = startView.questionnaireIdHintLabel
        additionalStepSwitch = startView.additionalStepSwitch
        view = startView
        scanRefInputView.delegate = self
        questionnaireIdInputView.delegate = self
        continueButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(continueButtonPressed(_:))))
        startView.idenfyToolbarV2Common.backButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(backButtonPressed(_:))))
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(backButtonPressed(_:)))
        swipeGesture.direction = .right
        view.addGestureRecognizer(swipeGesture)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }

    @objc func backButtonPressed(_ sender: AnyObject) {
        dismiss(animated: false)
    }

    @objc func continueButtonPressed(_ sender: AnyObject) {
        callRequestUpdate()
    }

    private func callRequestUpdate() {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret
        let scanRef = scanRefInputView.text ?? ""
        let questionnaireId = questionnaireIdInputView.text?.isEmpty == true ? nil : questionnaireIdInputView.text
        let additionalStepRequired = additionalStepSwitch.isOn

        let loginString = "\(apiKey):\(apiSecret)"
        guard let loginData = loginString.data(using: .utf8) else { return }
        let base64LoginString = loginData.base64EncodedString()

        let config = URLSessionConfiguration.default
        session = URLSession(configuration: config)

        let url = URL(string: Consts.baseURL)!
        let endpoint = url.appendingPathComponent("kyc/identifications/\(scanRef)/request-information/")
        var request = APIhelper().getRequestBody(type: "POST", url: endpoint)
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")

        var json: [String: Any] = [:]
        if let questionnaireId = questionnaireId {
            json["questionnaire"] = questionnaireId
        }
        json["additionalStepUploadRequired"] = additionalStepRequired
        request.httpBody = try? JSONSerialization.data(withJSONObject: json)

        continueButton.isUserInteractionEnabled = false
        continueButton.alpha = 0.4

        let task = session.dataTask(with: request) { [weak self] data, response, _ in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.continueButton.isUserInteractionEnabled = true
                self.continueButton.alpha = 1

                guard let data = data,
                      let httpResponse = response as? HTTPURLResponse else {
                    self.showAlert("Failed to request update!")
                    return
                }

                guard httpResponse.statusCode >= 200, httpResponse.statusCode < 300 else {
                    self.showAlert("Failed to request update! \(httpResponse.statusCode)")
                    return
                }

                do {
                    let decoded = try JSONDecoder().decode(Throwable<RequestInformationUpdateResponse>.self, from: data)
                    if let token = decoded.value?.tokenString {
                        switch Consts.sdkInitFlow {
                        case .Default:
                            self.initializeIdenfySDKDefault(authToken: token)
                        case .WithCustomColors:
                            self.initializeIdenfySDKWithCustomColors(authToken: token)
                        case .WithCustomImplementedViews:
                            self.initializeIdenfySDKCustom(authToken: token)
                        }
                    } else {
                        self.showAlert("Failed to get token from response!")
                    }
                } catch {
                    self.showAlert("Failed to decode response!")
                }
            }
        }
        task.resume()
    }

    private func showAlert(_ message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .actionSheet)
        present(alert, animated: true)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
            alert.dismiss(animated: true)
        }
    }

    private func initializeIdenfySDKDefault(authToken: String) {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .withOnBoadringViewType(.multipleStatic)
            .build()

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)
        handleSDKResults(idenfyController)
    }

    private func initializeIdenfySDKWithCustomColors(authToken: String) {
        let mainColor = Color.init(hexString: "9DB3B1")
        let secondaryColor = Color.init(hexString: "0C0C0B")
        let backgroundColor = Color.init(hexString: "F1F1F1")

        CustomUISettings.apply(mainColor: mainColor, secondaryColor: secondaryColor, backgroundColor: backgroundColor)

        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .withOnBoadringViewType(.multipleStatic)
            .build()

        idenfyUISettingsV2.idenfyLivenessUISettingsV2.livenessOverlayBrandingImageTintColor = mainColor

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)
        handleSDKResults(idenfyController)
    }

    private func initializeIdenfySDKCustom(authToken: String) {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()

        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()

        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withSplashScreenV2View(SplashScreenV2View())
            .withQuestionnaireView(QuestionnaireViewV2())
            .withTextQuestionCellView(TextQuestionCell.self)
            .withEmailQuestionCellView(EmailQuestionCell.self)
            .withFloatQuestionCellView(FloatQuestionCell.self)
            .withIntegerQuestionCellView(IntegerQuestionCell.self)
            .withPasswordQuestionCellView(PasswordQuestionCell.self)
            .withTelQuestionCellView(TelQuestionCell.self)
            .withUrlQuestionCellView(UrlQuestionCell.self)
            .withTextAreaQuestionCellView(TextAreaQuestionCell.self)
            .withSelectQuestionCellView(SelectQuestionCell.self)
            .withSelectMultiQuestionCellView(SelectMultiQuestionCell.self)
            .withCheckBoxQuestionCellView(CheckBoxQuestionCell.self)
            .withFileQuestionCellView(FileQuestionCell.self)
            .withMultiFileQuestionCellView(MultiFileQuestionCell.self)
            .withRadioQuestionCellView(RadioQuestionCell.self)
            .withDateQuestionCellView(DateQuestionCell.self)
            .withTimeQuestionCellView(TimeQuestionCell.self)
            .withDateTimeQuestionCellView(DateTimeQuestionCell.self)
            .withCountryQuestionCellView(CountryQuestionCell.self)
            .withMultiCountryQuestionCellView(MultiCountryQuestionCell.self)
            .withLanguageSelectionView(LanguageSelectionViewV2())
            .withLanguageCellView(LanguageCell.self)
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withCameraOnBoardingInstructionDescriptionsCellView(InstructionDescriptionsCellV2.self)
            .withCameraPermissionView(CameraPermissionViewV2())
            .withUploadPhotoView(UploadPhotoViewV2())
            .withDocumentCameraView(DocumentCameraViewV2())
            .withCameraWithRectangleResultViewV2(DocumentCameraResultViewV2())
            .withPdfResultView(PdfResultViewV2())
            .withFaceCameraView(FaceCameraViewV2())
            .withCameraWithoutRectangleResultViewV2(FaceCameraResultViewV2())
            .withIdentificationSuspectedResultsView(IdentificationSuspectedResultsViewV2())
            .withAdditionalSupportView(AdditionalSupportViewV2())
            .build()

        let idenfyController = IdenfyController.shared
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2, idenfyViewsV2: idenfyViewsV2)
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)
        handleSDKResults(idenfyController)
    }

    private func handleSDKResults(_ idenfyController: IdenfyController) {
        idenfyController.handleIdenfyCallbacksForRequestUpdate(requestUpdateResult: { result in
            print("Request update result: \(result.rawValue)")
        })
    }
}
