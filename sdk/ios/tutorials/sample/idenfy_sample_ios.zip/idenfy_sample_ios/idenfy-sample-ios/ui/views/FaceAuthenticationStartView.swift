//
//  FaceAuthenticationStartView.swift
//  idenfy-sample-ios
//
//  Created by Viktas Juškys on 2022-07-05.
//  Copyright © 2022 Viktor Vostrikov. All rights reserved.
//

import Foundation
import UIKit
import idenfyviews

open class FaceAuthenticationStartView: UIView {

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: .zero)
    }
    
    public var scanrefLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "Enter verification Scan-Ref"
        return label
    }()
    
    public var scanRefHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 10)
        label.textAlignment = .left
        label.text = "Scan-ref"
        label.isHidden = true
        label.textColor = IdenfyCommonColors.idenfyMainColorV2
        return label
    }()
    
    public var scanrefInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.textAlignment = .left
        textField.textColor = IdenfyCommonColors.idenfySecondColorV2
        textField.backgroundColor = UIColor.white
        textField.returnKeyType = .done
        textField.layer.cornerRadius = CGFloat(3)
        textField.layer.borderWidth = CGFloat(1)
        textField.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5).cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        textField.attributedPlaceholder = NSAttributedString(string: "Scan-ref", attributes: [NSAttributedString.Key.foregroundColor: IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)])
        return textField
    }()
    
    public var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.titleLabel?.textColor = IdenfyCommonColors.idenfyWhite
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.setTitle("CONTINUE", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
        setupToolbar()
        setupContinueButton()
        setupCenterImageView()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        if #available(iOS 11.0, *) {
            idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        } else {
            idenfyToolbarV2Common.topAnchor.constraint(equalTo: safeTopAnchor, constant: 20).isActive = true
        }
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(scanrefLabel)
        scanrefLabel.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 80).isActive = true
        scanrefLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        
        addSubview(scanrefInputView)
        scanrefInputView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        scanrefInputView.topAnchor.constraint(equalTo: scanrefLabel.bottomAnchor, constant: 32).isActive = true
        scanrefInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        scanrefInputView.leftAnchor.constraint(equalTo: continueButton.leftAnchor, constant: 24).isActive = true
        scanrefInputView.rightAnchor.constraint(equalTo: continueButton.rightAnchor, constant: -24).isActive = true
        
        addSubview(scanRefHintLabel)
        scanRefHintLabel.topAnchor.constraint(equalTo: scanrefInputView.topAnchor, constant: 2).isActive = true
        scanRefHintLabel.leftAnchor.constraint(equalTo: scanrefInputView.safeLeftAnchor, constant: 10).isActive = true
        scanRefHintLabel.rightAnchor.constraint(equalTo: scanrefInputView.safeRightAnchor).isActive = true
    }
    
    open func setupContinueButton() {
        addSubview(continueButton)
        continueButton.rightAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueButton.leftAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
}


