//
//  RequestUpdateStartView.swift
//  idenfy-sample-ios
//

import Foundation
import UIKit
import idenfyviews

open class RequestUpdateStartView: UIView {

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var titleLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "Request Update"
        return label
    }()

    public var scanRefInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.textAlignment = .left
        textField.textColor = IdenfyCommonColors.idenfySecondColorV2
        textField.backgroundColor = UIColor.white
        textField.returnKeyType = .next
        textField.layer.cornerRadius = CGFloat(3)
        textField.layer.borderWidth = CGFloat(1)
        textField.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5).cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        textField.attributedPlaceholder = NSAttributedString(string: "Enter scan ref", attributes: [NSAttributedString.Key.foregroundColor: IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)])
        return textField
    }()

    public var scanRefHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 10)
        label.textAlignment = .left
        label.text = "Scan ref"
        label.isHidden = true
        label.textColor = IdenfyCommonColors.idenfyMainColorV2
        return label
    }()

    public var questionnaireIdInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.textAlignment = .left
        textField.textColor = IdenfyCommonColors.idenfySecondColorV2
        textField.backgroundColor = UIColor.white
        textField.returnKeyType = .done
        textField.layer.cornerRadius = CGFloat(3)
        textField.layer.borderWidth = CGFloat(1)
        textField.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5).cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 1
        textField.attributedPlaceholder = NSAttributedString(string: "Questionnaire ID (optional)", attributes: [NSAttributedString.Key.foregroundColor: IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)])
        return textField
    }()

    public var questionnaireIdHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 10)
        label.textAlignment = .left
        label.text = "Questionnaire ID (optional)"
        label.isHidden = true
        label.textColor = IdenfyCommonColors.idenfyMainColorV2
        return label
    }()

    public var additionalStepLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "Additional step (POA)"
        return label
    }()

    public var additionalStepSwitch: UISwitch = {
        let toggle = UISwitch(frame: .zero)
        toggle.translatesAutoresizingMaskIntoConstraints = false
        toggle.isOn = true
        toggle.onTintColor = IdenfyCommonColors.idenfyMainColorV2
        return toggle
    }()

    public var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.titleLabel?.textColor = IdenfyCommonColors.idenfyWhite
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.setTitle("CONTINUE", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
        setupToolbar()
        setupContinueButton()
        setupCenterUI()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupCenterUI() {
        addSubview(titleLabel)
        titleLabel.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 40).isActive = true
        titleLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true

        addSubview(scanRefInputView)
        scanRefInputView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        scanRefInputView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 24).isActive = true
        scanRefInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        scanRefInputView.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 24).isActive = true
        scanRefInputView.trailingAnchor.constraint(equalTo: continueButton.trailingAnchor, constant: -24).isActive = true

        addSubview(scanRefHintLabel)
        scanRefHintLabel.topAnchor.constraint(equalTo: scanRefInputView.topAnchor, constant: 2).isActive = true
        scanRefHintLabel.leadingAnchor.constraint(equalTo: scanRefInputView.safeLeftAnchor, constant: 10).isActive = true
        scanRefHintLabel.trailingAnchor.constraint(equalTo: scanRefInputView.safeRightAnchor).isActive = true

        addSubview(questionnaireIdInputView)
        questionnaireIdInputView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        questionnaireIdInputView.topAnchor.constraint(equalTo: scanRefInputView.bottomAnchor, constant: 16).isActive = true
        questionnaireIdInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        questionnaireIdInputView.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 24).isActive = true
        questionnaireIdInputView.trailingAnchor.constraint(equalTo: continueButton.trailingAnchor, constant: -24).isActive = true

        addSubview(questionnaireIdHintLabel)
        questionnaireIdHintLabel.topAnchor.constraint(equalTo: questionnaireIdInputView.topAnchor, constant: 2).isActive = true
        questionnaireIdHintLabel.leadingAnchor.constraint(equalTo: questionnaireIdInputView.safeLeftAnchor, constant: 10).isActive = true
        questionnaireIdHintLabel.trailingAnchor.constraint(equalTo: questionnaireIdInputView.safeRightAnchor).isActive = true

        addSubview(additionalStepLabel)
        additionalStepLabel.topAnchor.constraint(equalTo: questionnaireIdInputView.bottomAnchor, constant: 24).isActive = true
        additionalStepLabel.leadingAnchor.constraint(equalTo: questionnaireIdInputView.leadingAnchor).isActive = true

        addSubview(additionalStepSwitch)
        additionalStepSwitch.centerYAnchor.constraint(equalTo: additionalStepLabel.centerYAnchor).isActive = true
        additionalStepSwitch.trailingAnchor.constraint(equalTo: questionnaireIdInputView.trailingAnchor).isActive = true
    }

    open func setupContinueButton() {
        addSubview(continueButton)
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
}
