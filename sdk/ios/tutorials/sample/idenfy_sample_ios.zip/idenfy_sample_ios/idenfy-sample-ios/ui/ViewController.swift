//
//  ViewController.swift
//  idenfy-sample-ios
//
//  Created by Viktor Vostrikov on 2020-06-22.
//  Copyright © 2020 Viktor Vostrikov. All rights reserved.
//

import iDenfySDK
import idenfyviews
import UIKit

class ViewController: UIViewController {
    // Usecases
    lazy var getIdenfyAuthTokenUseCase = GetIdenfyAuthTokenUseCase(apiHelper: APIHelper())
    
    // Alerts
    private let errorAlert = CustomAlert(title: NSLocalizedString("idenfy_sample_app_loading_view_title", tableName: nil, bundle: Bundle.main, value: "", comment: ""), canCancel: true)
    private let loadingAlert = CustomAlert(title: NSLocalizedString("idenfy_sample_app_loading_view_title", tableName: nil, bundle: Bundle.main, value: "", comment: ""), canCancel: false)
    
    // UI
    var appLanguage: AppLanguage!
    var identificationUIImage: UIImageView!
    var faceAuthenticationUIImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setIdenfyAuthTokenState(IdenfyAuthTokenState.NotStarted)
        appLanguage = AppLanguage(Locale.preferredLanguages[0])
        appLanguage.languageEnum = "en"
        let sampleAppView = SampleAppView()
        sampleAppView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sampleAppView)
        sampleAppView.anchor(top: view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor)
        identificationUIImage = sampleAppView.identificationUIImage
        faceAuthenticationUIImage = sampleAppView.faceAuthenticationImage
        identificationUIImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(beginIdentificationPressed)))
        faceAuthenticationUIImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(navigateToFaceAuthentication)))
        
        sampleAppView.sampleAppDesciption.text = "idenfy_sample_app_description".localized(appLanguage.languageEnum)
        sampleAppView.sampleAppTitle.text = "idenfy_sample_app_title".localized(appLanguage.languageEnum)
    }
    
    @objc private func beginIdentificationPressed() {
        getIdenfyAuthToken()
    }
    
    @objc private func navigateToFaceAuthentication() {
        let vc = FaceAuthenticationStartViewController()
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: false)
    }
    
    private func getIdenfyAuthToken() {
        setIdenfyAuthTokenState(IdenfyAuthTokenState.Loading)
        let authTokenBody = AuthTokenBody(clientId: Consts.clientId)
        getIdenfyAuthTokenUseCase.execute(authTokenBody: authTokenBody, appLanguage: appLanguage, success: { [weak self] authToken in
            guard let self = self else { return }
            self.setIdenfyAuthTokenState(IdenfyAuthTokenState.Success(authToken: authToken))
        }) { [weak self] errorResponse in
            guard let self = self else { return }
            self.setIdenfyAuthTokenState(IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(error: errorResponse.message))
        }
    }
    
    private func setIdenfyAuthTokenState(_ idenfyAuthTokenState: IdenfyAuthTokenState) {
        switch idenfyAuthTokenState {
        case .Loading:
            presentLoadingAlert()
            
        case .NotStarted: break
            
        case let .AuthTokenCouldNotBeReceived(error: error):
            print("Error receiving token: \(error)")
            presentErrorAlert(error)
            
        case let .Success(authToken: authToken):
            dismissLoadingAlert()
            switch Consts.sdkInitFlow {
            case .Default:
                initializeIdenfySDKDefault(authToken: authToken.authToken)
            case .CustomWithImplementedViews:
                initializeIdenfySDKCustom(authToken: authToken.authToken)
            }
        }
    }
    
    private func presentErrorAlert(_ error: String) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            guard let self = self else { return }
            self.errorAlert.alertTitle.text = error
            self.dismissLoadingAlert()
            self.errorAlert.show(animated: false)
        }
    }
    
    private func presentLoadingAlert() {
        loadingAlert.loadingImage.play()
        loadingAlert.show(animated: false)
    }
    
    private func dismissLoadingAlert() {
        loadingAlert.dismiss(animated: false)
    }
    
    private func handleSDKResults(_ idenfyController: IdenfyController) {
        idenfyController.getIdenfyResultWithDismiss(idenfyIdentificationResult: {
            idenfyIdentificationResult
            in
            print("autoStatus:\(idenfyIdentificationResult.autoIdentificationStatus.rawValue) ,manualStatus:\(idenfyIdentificationResult.manualIdentificationStatus.rawValue)")
            switch idenfyIdentificationResult.autoIdentificationStatus {
            case .APPROVED:
                // The user completed an identification flow and the identification status, provided by an automated platform, is APPROVED.
                break
            case .FAILED:
                // The user completed an identification flow and the identification status, provided by an automated platform, is FAILED.
                break
            case .UNVERIFIED:
                // The user did not complete an identification flow and the identification status, provided by an automated platform, is UNVERIFIED.
                break
            @unknown default:
                break
            }
            
            switch idenfyIdentificationResult.manualIdentificationStatus {
            case .APPROVED:
                // The user completed an identification flow and was verified manually while waiting for the manual verification results in the iDenfy SDK. The identification status, provided by a manual review, is APPROVED.
                break
            case .FAILED:
                // The user completed an identification flow and was verified manually while waiting for the manual verification results in the iDenfy SDK. The identification status, provided by a manual review, is FAILED.
                break
                
            case .WAITING:
                // The user completed an identification flow and started waiting for the manual verification results in the iDenfy SDK. Then he/she decided to stop waiting and pressed a "BACK TO ACCOUNT" button. The manual identification review is still ongoing.
                break
                
            case .INACTIVE:
                // The user was only verified by an automated platform, not by a manual reviewer. The identification performed by the user can still be verified by the manual review if your system uses the manual verification service.
                break
            @unknown default:
                break
            }
            
        })
    }
    
    private func initializeIdenfySDKDefault(authToken: String) {
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .withOnBoadringViewType(.multipleStatic)
            .build()
        
        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()
        
        let idenfyController = IdenfyController.shared
        let consoleLogging = ConsoleLoggingImpl()
        idenfyController.setIdenfyLoggingHandler(idenfyLoggingHandler: IdenfyLoggingHandlerUseCaseImpl(consoleLogging))
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2)
        let idenfyVC = idenfyController.instantiateNavigationController()
        
        present(idenfyVC, animated: true, completion: nil)
        handleSDKResults(idenfyController)
    }
    
    private func initializeIdenfySDKCustom(authToken: String) {
        //Changing UI with main colors
        IdenfyCommonColors.idenfyMainColorV2 = Color.init(hexString: "A50000")
        IdenfyCommonColors.idenfyMainDarkerColorV2 = Color.init(hexString: "820000")
        IdenfyCommonColors.idenfyBackgroundColorV2 = Color.init(hexString: "1A1A1A")
        IdenfyCommonColors.idenfyGradientColor1V2 = Color.init(hexString: "A50000")
        IdenfyCommonColors.idenfyGradientColor2V2 = Color.init(hexString: "820000")
        IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart = Color.init(hexString: "A50000")
        IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd = Color.init(hexString: "820000")
        IdenfyCommonColors.idenfyPhotoResultDetailsCardBackgroundColorV2 = IdenfyCommonColors.idenfyErrorLightRedColorV2
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarBackIconTintColor = Color.init(hexString: "A50000")
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarLogoIconTintColor = Color.init(hexString: "A50000")
        IdenfyDrawerUISettingsV2.idenfyDrawerBackButtonTintColor = .white
        IdenfyCommonColors.idenfySecondColorV2 = .white
        IdenfyCommonColors.idenfyWhite = .black
        IdenfyToolbarUISettingsV2.idenfyDefaultToolbarBackgroundColor = Color.init(hexString: "1A1A1A")
        IdenfyDrawerUISettingsV2.idenfyDrawerDescriptionTextColor = .white
        IdenfyDrawerUISettingsV2.idenfyDrawerTitleTextColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = .white.withAlphaComponent(0.6)
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionSwitchLensButtonTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionUploadPhotoButtonTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionFaceOvalColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionTakePhotoButtonFocusedTintColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedTintColor = .white
        IdenfyFaceCameraSessionUISettingsV2.idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedBackgroundColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessionToggleFlashButtonTintColor = .white
        IdenfyDocumentCameraSessionUISettingsV2.idenfyDocumentCameraPreviewSessioninstructionDialogButtonTintColor = .white
        IdenfyLoadingHUDUISettingsV2.idenfyLoadingHUDTitleColor = .white
        IdenfyLoadingHUDUISettingsV2.idenfyLoadingHUDDescriptionColor = .white
        
        let idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .build()
        
        idenfyUISettingsV2.idenfyLivenessUISettingsV2.livenessOverlayBrandingImageTintColor = Color.init(hexString: "A50000")
        
        let idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withUISettingsV2(idenfyUISettingsV2)
            .build()
        
        //Using custom views for additional customization
        let idenfyViewsV2: IdenfyViewsV2 = IdenfyViewsBuilderV2()
            .withSplashScreenV2View(SplashScreenV2View())
            .withPrivacyPolicyView(PrivacyPolicyViewV2())
            .withQuestionnaireView(QuestionnaireViewV2())
            .withTextQuestionCellView(TextQuestionCell.self)
            .withEmailQuestionCellView(EmailQuestionCell.self)
            .withFloatQuestionCellView(FloatQuestionCell.self)
            .withIntegerQuestionCellView(IntegerQuestionCell.self)
            .withPasswordQuestionCellView(PasswordQuestionCell.self)
            .withTelQuestionCellView(TelQuestionCell.self)
            .withUrlQuestionCellView(UrlQuestionCell.self)
            .withTextAreaQuestionCellView(TextAreaQuestionCell.self)
            .withSelectQuestionCellView(SelectQuestionCell.self)
            .withSelectMultiQuestionCellView(SelectMultiQuestionCell.self)
            .withCheckBoxQuestionCellView(CheckBoxQuestionCell.self)
            .withFileQuestionCellView(FileQuestionCell.self)
            .withMultiFileQuestionCellView(MultiFileQuestionCell.self)
            .withRadioQuestionCellView(RadioQuestionCell.self)
            .withDateQuestionCellView(DateQuestionCell.self)
            .withTimeQuestionCellView(TimeQuestionCell.self)
            .withDateTimeQuestionCellView(DateTimeQuestionCell.self)
            .withCountryQuestionCellView(CountryQuestionCell.self)
            .withMultiCountryQuestionCellView(MultiCountryQuestionCell.self)
            .withProviderSelectionView(ProviderSelectionViewV2())
            .withProviderCellView(ProviderCell.self)
            .withProviderLoginView(ProviderLoginViewV2())
            .withMFAMethodSelectionView(MFAMethodSelectionViewV2())
            .withMFAGeneralView(MFAGeneralViewV2())
            .withMFACaptchaView(MFACaptchaViewV2())
            .withNFCRequiredView(NFCRequiredViewV2())
            .withIssuedCountryView(IssuedCountryViewV2())
            .withCountrySelectionView(CountrySelectionViewV2())
            .withCountryCellView(CountryCell.self)
            .withLanguageSelectionView(LanguageSelectionViewV2())
            .withLanguageCellView(LanguageCell.self)
            .withDocumentSelectionView(DocumentSelectionViewV2())
            .withDocumentCellView(DocumentCell.self)
            .withConfirmationView(ConfirmationViewV2())
            .withStaticCameraOnBoardingView(StaticCameraOnBoardingViewV2())
            .withCameraOnBoardingInstructionDescriptionsCellView(InstructionDescriptionsCellV2.self)
            .withConfirmationViewDocumentStepCellView(DocumentStepCell.self)
            .withCameraPermissionView(CameraPermissionViewV2())
            .withUploadPhotoView(UploadPhotoViewV2())
            .withDocumentCameraView(DocumentCameraViewV2())
            .withCameraWithRectangleResultViewV2(DocumentCameraResultViewV2())
            .withPdfResultView(PdfResultViewV2())
            .withFaceCameraView(FaceCameraViewV2())
            .withCameraWithoutRectangleResultViewV2(FaceCameraResultViewV2())
            .withNFCReadingView(NFCReadingViewV2())
            .withNFCReadingTimeOutView(NFCReadingTimeOutViewV2())
            .withIdentificationResultsView(IdentificationResultsViewV2())
            .withIdentificationResultsStepCellView(ResultsStepCell.self)
            .withIdentificationSuccessResultsView(IdentificationSuccessResultsViewV2())
            .withIdentificationSuspectedResultsView(IdentificationSuspectedResultsViewV2())
            .withManualReviewingStatusWaitingView(ManualReviewingStatusWaitingViewV2())
            .withManualReviewingStatusFailedView(ManualReviewingStatusFailedViewV2())
            .withManualReviewingStatusApprovedView(ManualReviewingStatusApprovedViewV2())
            .withAdditionalSupportView(AdditionalSupportViewV2())
            .withFaceAuthenticationSplashScreenV2View(FaceAuthenticationSplashScreenV2View())
            .withFaceAuthenticationResultsViewV2(FaceAuthenticationResultsViewV2())
            .withBankVerificationViewV2(BankVerificationViewV2())
            .withBankSelectionCellViewV2(BankCell.self)
            .withEmailVerificationViewV2(EmailVerificationViewV2())
            .withSMSVerificationViewV2(SMSVerificationViewV2())
            .withEIDSessionViewV2(EIDSessionViewV2())
            .withEIDSessionCodeVerificationViewV2(EIDSessionCodeVerificationViewV2())
            .build()
        
        let idenfyController = IdenfyController.shared
        let consoleLogging = ConsoleLoggingImpl()
        idenfyController.setIdenfyLoggingHandler(idenfyLoggingHandler: IdenfyLoggingHandlerUseCaseImpl(consoleLogging))
        idenfyController.initializeIdenfySDKV2WithManual(idenfySettingsV2: idenfySettingsV2, idenfyViewsV2: idenfyViewsV2)
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())
        let idenfyVC = idenfyController.instantiateNavigationController()
        
        present(idenfyVC, animated: true, completion: nil)
        handleSDKResults(idenfyController)
    }
}
