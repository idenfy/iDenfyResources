//
//  BankCardVerificationStartViewController.swift
//  idenfy-sample-ios
//

import Foundation
import UIKit
import idenfycore
import idenfyviews
import iDenfySDK

extension BankCardVerificationStartViewController: UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return false
    }

    func textField(_ textFieldToChange: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let startingLength = textFieldToChange.text?.count ?? 0
        let lengthToAdd = string.count
        let lengthToReplace = range.length
        return (startingLength + lengthToAdd - lengthToReplace) <= 50
    }

    func textFieldDidChangeSelection(_ textField: UITextField) {
        expectedNameHintLabel.isHidden = expectedNameInputView.text?.isEmpty == true
        expectedLastFourHintLabel.isHidden = expectedLastFourInputView.text?.isEmpty == true

        switch textField {
        case expectedNameInputView:
            expectedNameInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        case expectedLastFourInputView:
            expectedLastFourInputView.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
        default:
            break
        }

        if expectedNameInputView.text?.isEmpty == true {
            continueButton.isUserInteractionEnabled = false
            continueButton.alpha = 0.4
        } else {
            continueButton.isUserInteractionEnabled = true
            continueButton.alpha = 1
        }
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputFocusedBorderColor.cgColor
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.layer.borderColor = IdenfyProviderLoginViewUISettingsV2.idenfyProviderLoginViewUsernameInputBorderColor.cgColor
    }
}

struct BankCardVerificationTokenResponse: Decodable {
    let tokenString: String?
}

class BankCardVerificationStartViewController: UIViewController {

    private var session: URLSession!

    private var continueButton: UIButton!
    private var expectedNameInputView: UITextField!
    private var expectedNameHintLabel: UILabel!
    private var expectedLastFourInputView: UITextField!
    private var expectedLastFourHintLabel: UILabel!

    override func loadView() {
        let startView = BankCardVerificationStartView(frame: .zero)
        continueButton = startView.continueButton
        expectedNameInputView = startView.expectedNameInputView
        expectedNameHintLabel = startView.expectedNameHintLabel
        expectedLastFourInputView = startView.expectedLastFourInputView
        expectedLastFourHintLabel = startView.expectedLastFourHintLabel
        view = startView
        expectedNameInputView.delegate = self
        expectedLastFourInputView.delegate = self
        continueButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(continueButtonPressed(_:))))
        startView.idenfyToolbarV2Common.backButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(backButtonPressed(_:))))
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(backButtonPressed(_:)))
        swipeGesture.direction = .right
        view.addGestureRecognizer(swipeGesture)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        continueButton.applyButtonGradient(colors: [IdenfyButtonsUISettingsV2.idenfyGradientButtonColorStart.cgColor, IdenfyButtonsUISettingsV2.idenfyGradientButtonColorEnd.cgColor])
    }

    @objc func backButtonPressed(_ sender: AnyObject) {
        dismiss(animated: false)
    }

    @objc func continueButtonPressed(_ sender: AnyObject) {
        createBankCardVerificationToken()
    }

    private func createBankCardVerificationToken() {
        let apiKey = Consts.apiKey
        let apiSecret = Consts.apiSecret
        let expectedName = expectedNameInputView.text ?? ""
        let expectedLastFour = expectedLastFourInputView.text?.isEmpty == true ? nil : expectedLastFourInputView.text

        let loginString = "\(apiKey):\(apiSecret)"
        guard let loginData = loginString.data(using: .utf8) else { return }
        let base64LoginString = loginData.base64EncodedString()

        let config = URLSessionConfiguration.default
        session = URLSession(configuration: config)

        let url = URL(string: Consts.baseURL)!
        let endpoint = url.appendingPathComponent("bank-card/tokens/")
        var request = APIHelper().getRequestBody(_type: "POST", _url: endpoint)
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")

        var json: [String: Any] = [:]
        json["expectedName"] = expectedName
        json["sessionLength"] = 600
        if let lastFour = expectedLastFour {
            json["expectedLastFour"] = lastFour
        }
        request.httpBody = try? JSONSerialization.data(withJSONObject: json)

        continueButton.isUserInteractionEnabled = false
        continueButton.alpha = 0.4

        let task = session.dataTask(with: request) { [weak self] data, response, _ in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.continueButton.isUserInteractionEnabled = true
                self.continueButton.alpha = 1

                guard let data = data,
                      let httpResponse = response as? HTTPURLResponse else {
                    self.showAlert("Failed to create BCV token!")
                    return
                }

                guard httpResponse.statusCode >= 200, httpResponse.statusCode < 300 else {
                    self.showAlert("Failed: HTTP \(httpResponse.statusCode)")
                    return
                }

                do {
                    let decoded = try JSONDecoder().decode(Throwable<BankCardVerificationTokenResponse>.self, from: data)
                    if let token = decoded.value?.tokenString {
                        switch Consts.sdkInitFlow {
                        case .Default:
                            self.initializeBankCardVerificationDefault(authToken: token)
                        case .WithCustomColors:
                            self.initializeBankCardVerificationWithCustomColors(authToken: token)
                        case .WithCustomImplementedViews:
                            self.initializeBankCardVerificationDefault(authToken: token)
                        }
                    } else {
                        self.showAlert("Failed to get token from response!")
                    }
                } catch {
                    self.showAlert("Failed to decode response!")
                }
            }
        }
        task.resume()
    }

    private func showAlert(_ message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .actionSheet)
        present(alert, animated: true)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
            alert.dismiss(animated: true)
        }
    }

    private func initializeBankCardVerificationDefault(authToken: String) {
        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())

        let bankCardVerificationInitialization = BankCardVerificationInitialization(bankCardVerificationToken: authToken)
        idenfyController.initializeBankCardVerification(bankCardVerificationInitialization: bankCardVerificationInitialization)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)
        handleBankCardVerificationResults(idenfyController)
    }

    private func initializeBankCardVerificationWithCustomColors(authToken: String) {
        let mainColor = Color.init(hexString: "6AA82F")
        let secondaryColor = Color.init(hexString: "000000")
        let backgroundColor = Color.init(hexString: "FFFFFF")

        CustomUISettings.apply(mainColor: mainColor, secondaryColor: secondaryColor, backgroundColor: backgroundColor)

        let idenfyController = IdenfyController.shared
        idenfyController.setIdenfyUserFlowCallbacksHandler(idenfyUserFlowHandler: IdenfyUserFlowCallbacksHandler())

        let bankCardVerificationInitialization = BankCardVerificationInitialization(bankCardVerificationToken: authToken)
        idenfyController.initializeBankCardVerification(bankCardVerificationInitialization: bankCardVerificationInitialization)
        let idenfyVC = idenfyController.instantiateNavigationController()

        present(idenfyVC, animated: true, completion: nil)
        handleBankCardVerificationResults(idenfyController)
    }

    private func handleBankCardVerificationResults(_ idenfyController: IdenfyController) {
        idenfyController.handleIdenfyCallbacksForBankCardVerification(bankCardVerificationResult: { result in
            print("BCV Status: \(result.bankCardVerificationStatus.rawValue)")
        })
    }
}
