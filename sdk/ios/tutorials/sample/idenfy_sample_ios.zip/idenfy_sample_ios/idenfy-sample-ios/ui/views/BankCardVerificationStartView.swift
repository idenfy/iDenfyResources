//
//  BankCardVerificationStartView.swift
//  idenfy-sample-ios
//

import Foundation
import UIKit
import idenfyviews

open class BankCardVerificationStartView: UIView {

    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }

    public var titleLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "Bank Card Verification"
        return label
    }()

    public var expectedNameInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.textAlignment = .left
        textField.textColor = IdenfyCommonColors.idenfySecondColorV2
        textField.backgroundColor = UIColor.white
        textField.returnKeyType = .next
        textField.layer.cornerRadius = CGFloat(3)
        textField.layer.borderWidth = CGFloat(1)
        textField.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5).cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 0
        textField.attributedPlaceholder = NSAttributedString(string: "Expected name", attributes: [NSAttributedString.Key.foregroundColor: IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)])
        return textField
    }()

    public var expectedNameHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 10)
        label.textAlignment = .left
        label.text = "Expected name"
        label.isHidden = true
        label.textColor = IdenfyCommonColors.idenfyMainColorV2
        return label
    }()

    public var expectedLastFourInputView: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.textAlignment = .left
        textField.textColor = IdenfyCommonColors.idenfySecondColorV2
        textField.backgroundColor = UIColor.white
        textField.returnKeyType = .done
        textField.layer.cornerRadius = CGFloat(3)
        textField.layer.borderWidth = CGFloat(1)
        textField.layer.borderColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.5).cgColor
        textField.layer.masksToBounds = true
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.isUserInteractionEnabled = true
        textField.tag = 1
        textField.attributedPlaceholder = NSAttributedString(string: "Expected last four digits (optional)", attributes: [NSAttributedString.Key.foregroundColor: IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.4)])
        return textField
    }()

    public var expectedLastFourHintLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 10)
        label.textAlignment = .left
        label.text = "Expected last four (optional)"
        label.isHidden = true
        label.textColor = IdenfyCommonColors.idenfyMainColorV2
        return label
    }()

    public var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleToFill
        button.titleLabel?.textColor = IdenfyCommonColors.idenfyWhite
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = IdenfyButtonsUISettingsV2.idenfyButtonCorderRadius
        button.layer.masksToBounds = true
        button.setTitle("CONTINUE", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.isUserInteractionEnabled = false
        button.alpha = 0.4
        return button
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
        setupToolbar()
        setupContinueButton()
        setupCenterUI()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupCenterUI() {
        addSubview(titleLabel)
        titleLabel.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 40).isActive = true
        titleLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true

        addSubview(expectedNameInputView)
        expectedNameInputView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        expectedNameInputView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 24).isActive = true
        expectedNameInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        expectedNameInputView.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 24).isActive = true
        expectedNameInputView.trailingAnchor.constraint(equalTo: continueButton.trailingAnchor, constant: -24).isActive = true

        addSubview(expectedNameHintLabel)
        expectedNameHintLabel.topAnchor.constraint(equalTo: expectedNameInputView.topAnchor, constant: 2).isActive = true
        expectedNameHintLabel.leadingAnchor.constraint(equalTo: expectedNameInputView.safeLeftAnchor, constant: 10).isActive = true
        expectedNameHintLabel.trailingAnchor.constraint(equalTo: expectedNameInputView.safeRightAnchor).isActive = true

        addSubview(expectedLastFourInputView)
        expectedLastFourInputView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        expectedLastFourInputView.topAnchor.constraint(equalTo: expectedNameInputView.bottomAnchor, constant: 16).isActive = true
        expectedLastFourInputView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        expectedLastFourInputView.leadingAnchor.constraint(equalTo: continueButton.leadingAnchor, constant: 24).isActive = true
        expectedLastFourInputView.trailingAnchor.constraint(equalTo: continueButton.trailingAnchor, constant: -24).isActive = true

        addSubview(expectedLastFourHintLabel)
        expectedLastFourHintLabel.topAnchor.constraint(equalTo: expectedLastFourInputView.topAnchor, constant: 2).isActive = true
        expectedLastFourHintLabel.leadingAnchor.constraint(equalTo: expectedLastFourInputView.safeLeftAnchor, constant: 10).isActive = true
        expectedLastFourHintLabel.trailingAnchor.constraint(equalTo: expectedLastFourInputView.safeRightAnchor).isActive = true
    }

    open func setupContinueButton() {
        addSubview(continueButton)
        continueButton.trailingAnchor.constraint(equalTo: safeRightAnchor, constant: -32).isActive = true
        continueButton.leadingAnchor.constraint(equalTo: safeLeftAnchor, constant: 32).isActive = true
        continueButton.bottomAnchor.constraint(equalTo: safeBottomAnchor, constant: -24).isActive = true
        continueButton.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }
}
