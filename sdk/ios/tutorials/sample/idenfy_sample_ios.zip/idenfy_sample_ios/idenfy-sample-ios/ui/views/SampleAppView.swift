//
//  IssuedCountryViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-03-09.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfyviews
import UIKit
import iDenfySDK
@objc open class SampleAppView: UIView {
    
    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        toolbar.backButton.isHidden = true
        toolbar.logo.isHidden = true
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: CGRect.zero)
    }
    
    public var sampleAppTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewTitleTextColor
        return label
    }()

    public var sampleAppDesciption: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewDescriptionTextColor
        return label
    }()
    
    public var horizontalDivider1: UIView = {
        let uiView = UIView(frame: .zero)
        uiView.translatesAutoresizingMaskIntoConstraints = false
        uiView.backgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        return uiView
    }()

    public var horizontalDivider2: UIView = {
        let uiView = UIView(frame: .zero)
        uiView.translatesAutoresizingMaskIntoConstraints = false
        uiView.backgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        return uiView
    }()

    public var identificationUIImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "idenfy_ic_identification", in: Bundle.main, compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var faceAuthenticationImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "idenfy_ic_face_authentication_start_image", in: Bundle.main, compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var identificationUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "IDENTIFICATION UI"
        return label
    }()
    
    public var faceAuthenticationLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "FACE AUTHENTICATION"
        return label
    }()

    public var requestUpdateImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "idenfy_ic_identification", in: Bundle.main, compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    public var requestUpdateLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "REQUEST UPDATE"
        return label
    }()

    public var scrollView: UIScrollView = {
        let scrollView = UIScrollView(frame: .zero)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()

    public var contentView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
        setupToolbar()
        setupScrollView()
        setupContent()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leadingAnchor.constraint(equalTo: safeLeadingAnchor).isActive = true
        idenfyToolbarV2Common.trailingAnchor.constraint(equalTo: safeTrailingAnchor).isActive = true
        if #available(iOS 11.0, *) {
            idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        } else {
            idenfyToolbarV2Common.topAnchor.constraint(equalTo: safeTopAnchor, constant: 20).isActive = true
        }
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }

    open func setupScrollView() {
        addSubview(scrollView)
        scrollView.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 16).isActive = true
        scrollView.leadingAnchor.constraint(equalTo: safeLeadingAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: safeTrailingAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: safeBottomAnchor).isActive = true

        scrollView.addSubview(contentView)
        contentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }

    open func setupContent() {
        contentView.addSubview(sampleAppTitle)
        sampleAppTitle.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16).isActive = true
        sampleAppTitle.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        sampleAppTitle.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true

        contentView.addSubview(sampleAppDesciption)
        sampleAppDesciption.topAnchor.constraint(equalTo: sampleAppTitle.bottomAnchor, constant: 16).isActive = true
        sampleAppDesciption.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        sampleAppDesciption.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true

        contentView.addSubview(identificationUIImage)
        identificationUIImage.topAnchor.constraint(equalTo: sampleAppDesciption.bottomAnchor, constant: 24).isActive = true
        identificationUIImage.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        identificationUIImage.widthAnchor.constraint(equalToConstant: 80).isActive = true
        identificationUIImage.heightAnchor.constraint(equalToConstant: 80).isActive = true

        contentView.addSubview(identificationUILabel)
        identificationUILabel.topAnchor.constraint(equalTo: identificationUIImage.bottomAnchor, constant: 8).isActive = true
        identificationUILabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true

        contentView.addSubview(horizontalDivider1)
        horizontalDivider1.topAnchor.constraint(equalTo: identificationUILabel.bottomAnchor, constant: 32).isActive = true
        horizontalDivider1.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        horizontalDivider1.widthAnchor.constraint(equalToConstant: 200).isActive = true
        horizontalDivider1.heightAnchor.constraint(equalToConstant: 1).isActive = true

        contentView.addSubview(faceAuthenticationImage)
        faceAuthenticationImage.topAnchor.constraint(equalTo: horizontalDivider1.bottomAnchor, constant: 32).isActive = true
        faceAuthenticationImage.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        faceAuthenticationImage.widthAnchor.constraint(equalToConstant: 80).isActive = true
        faceAuthenticationImage.heightAnchor.constraint(equalToConstant: 80).isActive = true

        contentView.addSubview(faceAuthenticationLabel)
        faceAuthenticationLabel.topAnchor.constraint(equalTo: faceAuthenticationImage.bottomAnchor, constant: 8).isActive = true
        faceAuthenticationLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true

        contentView.addSubview(horizontalDivider2)
        horizontalDivider2.topAnchor.constraint(equalTo: faceAuthenticationLabel.bottomAnchor, constant: 32).isActive = true
        horizontalDivider2.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        horizontalDivider2.widthAnchor.constraint(equalToConstant: 200).isActive = true
        horizontalDivider2.heightAnchor.constraint(equalToConstant: 1).isActive = true

        contentView.addSubview(requestUpdateImage)
        requestUpdateImage.topAnchor.constraint(equalTo: horizontalDivider2.bottomAnchor, constant: 32).isActive = true
        requestUpdateImage.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        requestUpdateImage.widthAnchor.constraint(equalToConstant: 80).isActive = true
        requestUpdateImage.heightAnchor.constraint(equalToConstant: 80).isActive = true

        contentView.addSubview(requestUpdateLabel)
        requestUpdateLabel.topAnchor.constraint(equalTo: requestUpdateImage.bottomAnchor, constant: 8).isActive = true
        requestUpdateLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        requestUpdateLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -32).isActive = true
    }
}
