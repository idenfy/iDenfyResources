//
//  IssuedCountryViewV2.swift
//  idenfyviews
//
//  Created by Viktas Juskys on 2020-03-09.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
import idenfyviews
import UIKit
import iDenfySDK
@objc open class SampleAppView: UIView {
    
    public var idenfyToolbarV2Common: IdenfyToolbarV2Default = {
        let toolbar = IdenfyToolbarV2Default(frame: .zero)
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        toolbar.backButton.isHidden = true
        return toolbar
    }()

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupConstraints()
    }

    public required convenience init?(coder _: NSCoder) {
        self.init(frame: .zero)
    }
    
    public var sampleAppTitle: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewTitleFont
        label.textAlignment = .center
        label.textColor = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewTitleTextColor
        return label
    }()

    public var sampleAppDesciption: UILabel = {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewDescriptionFont
        label.textAlignment = .center
        label.textColor = IdenfyIssuedCountryViewUISettingsV2.idenfyIssuedCountryViewDescriptionTextColor
        return label
    }()
    
    public var verticalDivider: UIView = {
        let uiView = UIView(frame: .zero)
        uiView.translatesAutoresizingMaskIntoConstraints = false
        uiView.backgroundColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        return uiView
    }()

    public var identificationUIImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "idenfy_ic_identification", in: Bundle.main, compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var faceAuthenticationImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isOpaque = true
        imageView.isUserInteractionEnabled = true
        imageView.image = UIImage(named: "idenfy_ic_face_authentication_start_image", in: Bundle.main, compatibleWith: nil)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var identificationUILabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "IDENTIFICATION UI"
        return label
    }()
    
    public var faceAuthenticationLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .center
        label.textColor = IdenfyCommonColors.idenfySecondColorV2.withAlphaComponent(0.8)
        label.text = "FACE AUTHENTICATION"
        return label
    }()

    @objc open func setupConstraints() {
        backgroundColor = IdenfyCommonColors.idenfyBackgroundColorV2
        setupToolbar()
        setupCenterImageView()
    }

    open func setupToolbar() {
        addSubview(idenfyToolbarV2Common)
        idenfyToolbarV2Common.leftAnchor.constraint(equalTo: safeLeftAnchor).isActive = true
        idenfyToolbarV2Common.rightAnchor.constraint(equalTo: safeRightAnchor).isActive = true
        if #available(iOS 11.0, *) {
            idenfyToolbarV2Common.topAnchor.constraint(equalTo: self.safeTopAnchor).isActive = true
        } else {
            idenfyToolbarV2Common.topAnchor.constraint(equalTo: safeTopAnchor, constant: 20).isActive = true
        }
        idenfyToolbarV2Common.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        
        addSubview(sampleAppTitle)
        sampleAppTitle.topAnchor.constraint(equalTo: idenfyToolbarV2Common.bottomAnchor, constant: 16).isActive = true
        sampleAppTitle.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
        sampleAppTitle.rightAnchor.constraint(equalTo: rightAnchor, constant: -16).isActive = true
        
        addSubview(sampleAppDesciption)
        sampleAppDesciption.topAnchor.constraint(equalTo: sampleAppTitle.bottomAnchor, constant: 16).isActive = true
        sampleAppDesciption.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
        sampleAppDesciption.rightAnchor.constraint(equalTo: rightAnchor, constant: -16).isActive = true
    }

    open func setupCenterImageView() {
        addSubview(verticalDivider)
        verticalDivider.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -16).isActive = true
        verticalDivider.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        verticalDivider.widthAnchor.constraint(equalToConstant: 2).isActive = true
        verticalDivider.heightAnchor.constraint(equalToConstant: 200).isActive = true
        
        addSubview(identificationUIImage)
        identificationUIImage.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        identificationUIImage.rightAnchor.constraint(equalTo: verticalDivider.leftAnchor).isActive = true
        identificationUIImage.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -16).isActive = true
        
        addSubview(faceAuthenticationImage)
        faceAuthenticationImage.leftAnchor.constraint(equalTo: verticalDivider.rightAnchor, constant: 16).isActive = true
        faceAuthenticationImage.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        faceAuthenticationImage.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -16).isActive = true
        
        addSubview(identificationUILabel)
        identificationUILabel.topAnchor.constraint(equalTo: identificationUIImage.bottomAnchor, constant: 24).isActive = true
        identificationUILabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 8).isActive = true
        identificationUILabel.rightAnchor.constraint(equalTo: verticalDivider.leftAnchor, constant: -8).isActive = true

        addSubview(faceAuthenticationLabel)
        faceAuthenticationLabel.topAnchor.constraint(equalTo: faceAuthenticationImage.bottomAnchor, constant: 16).isActive = true
        faceAuthenticationLabel.leftAnchor.constraint(equalTo: verticalDivider.rightAnchor, constant: 8).isActive = true
        faceAuthenticationLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: -8).isActive = true
    }
}
