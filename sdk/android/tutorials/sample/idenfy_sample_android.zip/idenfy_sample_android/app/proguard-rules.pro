# ==============================
# Preserve Kotlin metadata
# ==============================
-keepclassmembers class kotlin.Metadata { *; }

# Keep generic type information for Retrofit + RxJava
-keepattributes Signature

# Keep line numbers for stack traces
-keepattributes SourceFile,LineNumberTable

# ==============================
# Retrofit Interfaces
# ==============================
# Keep APIService interface and its methods
-keep,allowobfuscation,allowshrinking interface com.idenfy.idenfy_sample_android.networking.APIService {
    <methods>;
}

# Keep Retrofit HTTP method annotations
-keepclassmembers,allowobfuscation,allowshrinking interface * {
    @retrofit2.http.* <methods>;
}

# Keep Retrofit runtime classes
-keep class retrofit2.** { *; }
-dontwarn retrofit2.**

# ==============================
# RxJava2
# ==============================
# Keep generic type info for RxJava return types
-keepclassmembers class io.reactivex.Single { *; }
-keepclassmembers class io.reactivex.Observable { *; }
-keepclassmembers class io.reactivex.Flowable { *; }
-dontwarn io.reactivex.**

# ==============================
# Moshi
# ==============================
# Keep Moshi annotations for JSON parsing
-keepclassmembers class ** {
    @com.squareup.moshi.FromJson *;
    @com.squareup.moshi.ToJson *;
}

# Keep model classes used in Retrofit/Moshi
-keep class com.idenfy.idenfy_sample_android.data.models.** { *; }
-keepclassmembers class com.idenfy.idenfy_sample_android.data.models.** { *; }

# ==============================
# AndroidX Annotations
# ==============================
-keep class androidx.annotation.Keep {*;}
-dontwarn androidx.**

# ==============================
# Optional: WebView (if needed)
# ==============================
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}
