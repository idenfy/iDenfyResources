package com.idenfy.idenfy_sample_android.ui.presentation

import com.idenfy.idenfy_sample_android.data.models.AuthToken
import com.idenfy.idenfy_sample_android.data.models.PartnerAuthenticationInfoResponse

sealed class IdenfyAuthTokenState {
    object NotStarted : IdenfyAuthTokenState()
    object Loading : IdenfyAuthTokenState()
    data class AuthTokenCouldNotBeReceived(val throwable: Throwable) : IdenfyAuthTokenState()
    data class Success(val authToken: AuthToken) : IdenfyAuthTokenState()
    data class FaceAuthSuccess(val partnerAuthenticationInfoResponse: PartnerAuthenticationInfoResponse) : IdenfyAuthTokenState()
}