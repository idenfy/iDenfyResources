package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.idenfy.idenfySdk.faceauthentication.domain.models.FaceAuthenticationType

@Keep
class FaceAuthenticationTypeResponse(
    @Expose
    @SerializedName("type")
    var type: FaceAuthenticationType
)