package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.idenfy.idenfySdk.faceauthentication.domain.models.FaceAuthenticationType
import com.squareup.moshi.Json

@Keep
class FaceAuthenticationTypeResponse(
    @field:Json(name = "type")
    var type: FaceAuthenticationType
)