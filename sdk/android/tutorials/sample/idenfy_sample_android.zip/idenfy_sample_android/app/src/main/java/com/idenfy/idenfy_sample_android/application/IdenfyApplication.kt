package com.idenfy.idenfy_sample_android.application

import androidx.compose.ui.unit.ExperimentalUnitApi
import androidx.multidex.MultiDexApplication
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyController
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyUserFlowController
import com.idenfy.idenfySdk.api.ui.IdenfyComposeViewBuilder
import com.idenfy.idenfy_sample_android.domain.utils.IdenfyUserFlowCallbacksHandler
import com.idenfy.idenfy_sample_android.ui.composables.IdentificationSuspectedResultsTestComposable
import com.idenfy.idenfy_sample_android.ui.composables.ManualReviewingIdentificationResultsWaitingTestComposable

class IdenfyApplication : MultiDexApplication() {
    @ExperimentalUnitApi
    override fun onCreate() {
        super.onCreate()
        IdenfyUserFlowController.setIdenfyUserFlowHandler(IdenfyUserFlowCallbacksHandler())
        val idenfyComposeViews = IdenfyComposeViewBuilder()
            .withManualReviewingIdentificationResultsStatusWaitingComposable { data -> ManualReviewingIdentificationResultsWaitingTestComposable.composeManualView(data) }
            .withIdentificationSuspectedResultsComposable { data -> IdentificationSuspectedResultsTestComposable.compose(data) }
            .build()
        IdenfyController.getInstance().idenfyComposableViews = idenfyComposeViews
    }
}