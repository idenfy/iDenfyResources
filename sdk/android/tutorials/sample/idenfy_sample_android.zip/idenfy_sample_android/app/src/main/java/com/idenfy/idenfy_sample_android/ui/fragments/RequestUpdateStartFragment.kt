package com.idenfy.idenfy_sample_android.ui.fragments

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyController
import com.idenfy.idenfySdk.api.initialization.IdenfySettingsV2.IdenfyBuilderV2
import com.idenfy.idenfySdk.api.logging.IdenfySDKLoggingSettings.IdenfySDKLoggingEnum
import com.idenfy.idenfySdk.api.ui.IdenfyUISettingsV2.IdenfyUIBuilderV2
import com.idenfy.idenfy_sample_android.domain.utils.CustomUISettings
import com.idenfy.idenfySdk.camerasession.commoncamerasession.presentation.model.IdenfyInstructionsType
import com.idenfy.idenfy_sample_android.R
import com.idenfy.idenfy_sample_android.data.models.RequestInformationUpdateRequest
import com.idenfy.idenfy_sample_android.domain.utils.Consts
import com.idenfy.idenfy_sample_android.domain.utils.SDKInitFlow
import com.idenfy.idenfy_sample_android.data.models.RequestInformationUpdateResponse
import com.idenfy.idenfy_sample_android.networking.RetrofitFactory
import com.idenfy.idenfy_sample_android.ui.MainActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class RequestUpdateStartFragment : Fragment() {

    private lateinit var scanRefEditText: EditText
    private lateinit var questionnaireIdEditText: EditText
    private lateinit var additionalStepSwitch: SwitchCompat
    private lateinit var continueButton: Button
    private lateinit var backButton: ImageView

    companion object {
        private const val PREFS_NAME = "RequestUpdatePrefs"
        private const val PREF_SCAN_REF = "scanRef"
        private const val PREF_QUESTIONNAIRE_ID = "questionnaireId"
        private const val PREF_ADDITIONAL_STEP = "additionalStep"
    }

    private val requiredFieldsWatcher = object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun afterTextChanged(p0: Editable?) {
            updateContinueButtonState()
        }
    }

    private fun updateContinueButtonState() {
        val enabled = scanRefEditText.text.isNotEmpty()
        continueButton.isEnabled = enabled
        continueButton.alpha = if (enabled) 1f else 0.4f
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_request_update_start, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        backButton = view.findViewById(com.idenfySdk.R.id.idenfy_imageview_common_back_button)
        scanRefEditText = view.findViewById(R.id.idenfy_et_scan_ref)
        questionnaireIdEditText = view.findViewById(R.id.idenfy_et_questionnaire_id)
        additionalStepSwitch = view.findViewById(R.id.idenfy_switch_additional_step)
        continueButton = view.findViewById(R.id.idenfy_continue_button)

        scanRefEditText.addTextChangedListener(requiredFieldsWatcher)

        setupFocusListener(scanRefEditText)
        setupFocusListener(questionnaireIdEditText)

        restorePreferences()

        continueButton.setOnClickListener {
            callRequestUpdate()
        }

        backButton.setOnClickListener {
            activity?.onBackPressedDispatcher?.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        savePreferences()
    }

    private fun setupFocusListener(editText: EditText) {
        editText.setOnFocusChangeListener { _, hasFocus ->
            editText.background = ContextCompat.getDrawable(
                requireContext(),
                if (hasFocus) R.drawable.idenfy_custom_edit_text_highlighted_item_background
                else R.drawable.idenfy_custom_edit_text_item_background
            )
        }
    }

    private fun savePreferences() {
        val prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(PREF_SCAN_REF, scanRefEditText.text.toString())
            .putString(PREF_QUESTIONNAIRE_ID, questionnaireIdEditText.text.toString())
            .putBoolean(PREF_ADDITIONAL_STEP, additionalStepSwitch.isChecked)
            .apply()
    }

    private fun restorePreferences() {
        val prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        scanRefEditText.setText(prefs.getString(PREF_SCAN_REF, ""))
        questionnaireIdEditText.setText(prefs.getString(PREF_QUESTIONNAIRE_ID, ""))
        additionalStepSwitch.isChecked = prefs.getBoolean(PREF_ADDITIONAL_STEP, true)
    }

    private fun callRequestUpdate() {
        val scanRef = scanRefEditText.text.toString()
        val questionnaireId = questionnaireIdEditText.text.toString().ifEmpty { null }

        val request = RequestInformationUpdateRequest(
            questionnaire = questionnaireId,
            additionalStepUploadRequired = additionalStepSwitch.isChecked
        )

        continueButton.isEnabled = false
        continueButton.alpha = 0.4f

        RetrofitFactory.makeRetrofitService()
            .requestInformationUpdate(scanRef, request)
            .enqueue(object : Callback<RequestInformationUpdateResponse> {
                override fun onResponse(
                    call: Call<RequestInformationUpdateResponse>,
                    response: Response<RequestInformationUpdateResponse>
                ) {
                    if (!isAdded) return
                    updateContinueButtonState()
                    if (response.isSuccessful && response.body()?.tokenString != null) {
                        initializeDefaultFlow(response.body()!!.tokenString!!)
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Request update failed: ${response.code()} ${response.message()}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onFailure(call: Call<RequestInformationUpdateResponse>, t: Throwable) {
                    if (!isAdded) return
                    updateContinueButtonState()
                    Toast.makeText(
                        requireContext(),
                        "Request update failed: ${t.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
    }

    private fun initializeDefaultFlow(token: String) {
        val idenfyUISettingsV2 = when (Consts.sdkInitFlow) {
            SDKInitFlow.Default -> IdenfyUIBuilderV2()
                .withInstructions(IdenfyInstructionsType.DIALOG)
                .build()
            SDKInitFlow.WithCustomColors -> IdenfyUIBuilderV2()
                .withInstructions(IdenfyInstructionsType.DIALOG)
                .withColorScheme(CustomUISettings.createCustomColorScheme())
                .build()
        }

        val idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(token)
            .withIdenfyUISettingsV2(idenfyUISettingsV2)
            .withLogging(IdenfySDKLoggingEnum.FULL)
            .build()

        IdenfyController.getInstance().initializeIdenfySDKV2WithManual(
            requireActivity(),
            (requireActivity() as MainActivity).identificationResultsCallback,
            idenfySettingsV2
        )
    }
}
