package com.idenfy.idenfy_sample_android.networking

import com.idenfy.idenfy_sample_android.data.models.*
import io.reactivex.Single
import retrofit2.http.*

interface APIService {
    @Headers("Content-Type: application/json")
    @POST("api/v2/token")
    fun getAppToken(
        @Body authTokenBody: AuthTokenBody
    ): Single<AuthToken>

    @Headers("Content-Type: application/json")
    @POST("/partner/authentication-info")
    fun getAuthenticationToken(
        @Body partnerAuthenticationInfoRequest: PartnerAuthenticationInfoRequest
    ): Single<PartnerAuthenticationInfoResponse>

    @Headers("Content-Type: application/json")
    @GET("/identification/facial-auth/{scanRef}/check-status/")
    fun getFaceAuthenticationType(
        @Path("scanRef") scanRef: String,
        @Query("method") method: String
    ): Single<FaceAuthenticationTypeResponse>
}