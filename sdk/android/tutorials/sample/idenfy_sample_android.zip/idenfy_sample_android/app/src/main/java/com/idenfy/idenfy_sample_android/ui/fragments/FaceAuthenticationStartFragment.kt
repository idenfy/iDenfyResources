package com.idenfy.idenfy_sample_android.ui.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyController
import com.idenfy.idenfySdk.api.ui.IdenfyFaceAuthUISettings
import com.idenfy.idenfySdk.faceauthentication.api.FaceAuthenticationInitialization
import com.idenfy.idenfy_sample_android.R
import com.idenfy.idenfy_sample_android.ui.MainActivity
import com.idenfy.idenfy_sample_android.ui.presentation.IdenfyAuthTokenState
import com.idenfy.idenfy_sample_android.ui.viewmodel.MainViewModel

class FaceAuthenticationStartFragment : Fragment() {

    private lateinit var scanRefEditText: EditText
    private lateinit var scanRefHint: TextView
    private lateinit var continueButton: Button
    private lateinit var backButton: ImageView

    private lateinit var mainViewModel: MainViewModel

    private val scanrefWatcher = object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        }

        override fun afterTextChanged(p0: Editable?) {
            if (scanRefEditText.text.toString().isEmpty()) {
                scanRefHint.visibility = View.INVISIBLE
                continueButton.isEnabled = false
                continueButton.alpha = 0.4f
            } else {
                scanRefHint.visibility = View.VISIBLE
                continueButton.isEnabled = true
                continueButton.alpha = 1f
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(
            R.layout.fragment_face_authentication_start, container,
            false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        mainViewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]
        observeIdenfyAuthTokenState()
        backButton = view.findViewById(com.idenfySdk.R.id.idenfy_imageview_common_back_button)
        scanRefEditText = view.findViewById(R.id.idenfy_et_search_view_code)
        scanRefHint = view.findViewById(R.id.idenfy_textview_code_hint)
        continueButton =
            view.findViewById(R.id.idenfy_continue_button)
        scanRefEditText.addTextChangedListener(scanrefWatcher)
        scanRefEditText.setOnFocusChangeListener { _, b ->
            if (b) {
                scanRefEditText.background = ContextCompat.getDrawable(
                    requireContext(),
                    R.drawable.idenfy_custom_edit_text_highlighted_item_background
                )
            } else {
                scanRefEditText.background = ContextCompat.getDrawable(
                    requireContext(),
                    R.drawable.idenfy_custom_edit_text_item_background
                )
            }
        }

        continueButton.setOnClickListener {
            //Possibility to copy here and test from code
            var scanRef = ""
            if (scanRef.isEmpty()){
                scanRef = scanRefEditText.text.toString()
            }
            scanRefEditText.text.clear()
            mainViewModel.checkFaceAuthenticationType(scanRef, "FACE_MATCHING")
        }

        backButton.setOnClickListener {
            activity?.onBackPressedDispatcher?.onBackPressed()
        }
    }

    private fun observeIdenfyAuthTokenState() {
        mainViewModel.idenfyAuthTokenStateLiveData.observe(viewLifecycleOwner) {
            when (it) {
                is IdenfyAuthTokenState.FaceAuthSuccess -> {
                    (activity as MainActivity).resetState()
                    if (it.partnerAuthenticationInfoResponse.token != null) {
                        initializeFaceAuthentication(it.partnerAuthenticationInfoResponse.token!!)
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Failed to fetch token!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                is IdenfyAuthTokenState.AuthTokenCouldNotBeReceived -> {
                    Toast.makeText(requireContext(), "Failed to fetch token!", Toast.LENGTH_SHORT)
                        .show()
                }

                else -> {}
            }
        }

    }

    private fun initializeFaceAuthentication(token: String) {
        val idenfyFaceAuthUISettings = IdenfyFaceAuthUISettings.IdenfyFaceAuthUIBuilder()
            .withLanguageSelection(true)
            .withOnBoardingView(true)
            .build()

        val faceAuthenticationInitialization = FaceAuthenticationInitialization(token,
            withImmediateRedirect = false,
            idenfyFaceAuthUISettings = idenfyFaceAuthUISettings
        )
        IdenfyController.getInstance().initializeFaceAuthenticationSDKV2(requireActivity(), (requireActivity() as MainActivity).identificationResultsCallback, faceAuthenticationInitialization)
    }
}