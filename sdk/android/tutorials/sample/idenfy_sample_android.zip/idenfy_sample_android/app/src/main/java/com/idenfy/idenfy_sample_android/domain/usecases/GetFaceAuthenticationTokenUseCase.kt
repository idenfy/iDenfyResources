package com.idenfy.idenfy_sample_android.domain.usecases

import com.idenfy.idenfy_sample_android.data.models.PartnerAuthenticationInfoRequest
import com.idenfy.idenfy_sample_android.data.models.PartnerAuthenticationInfoResponse
import com.idenfy.idenfy_sample_android.networking.APIService
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtils
import io.reactivex.Single

class GetFaceAuthenticationTokenUseCase(
    private val apiService: APIService,
    private val rxJavaUtils: RxJavaUtils
) {

    fun execute(authTokenBody: PartnerAuthenticationInfoRequest): Single<PartnerAuthenticationInfoResponse> {
        return apiService.getAuthenticationToken(authTokenBody)
            .subscribeOn(rxJavaUtils.getSchedulersIO())
    }

}