package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.squareup.moshi.Json

@Keep
class PartnerAuthenticationInfoResponse(
    @field:Json(name = "token")
    var token: String? = null
)