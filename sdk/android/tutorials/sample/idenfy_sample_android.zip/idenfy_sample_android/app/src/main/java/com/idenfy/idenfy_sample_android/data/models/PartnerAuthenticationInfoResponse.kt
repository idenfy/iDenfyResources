package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Keep
class PartnerAuthenticationInfoResponse(
    @Expose
    @SerializedName("token")
    var token: String? = null
)