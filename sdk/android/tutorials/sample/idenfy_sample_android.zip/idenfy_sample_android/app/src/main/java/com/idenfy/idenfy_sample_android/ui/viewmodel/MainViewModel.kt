package com.idenfy.idenfy_sample_android.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.idenfy.idenfySdk.faceauthentication.domain.models.FaceAuthenticationType
import com.idenfy.idenfy_sample_android.data.models.AuthTokenBody
import com.idenfy.idenfy_sample_android.data.models.PartnerAuthenticationInfoRequest
import com.idenfy.idenfy_sample_android.di.ServiceLocator
import com.idenfy.idenfy_sample_android.domain.usecases.GetFaceAuthenticationTokenUseCase
import com.idenfy.idenfy_sample_android.domain.usecases.GetFaceAuthenticationTypeUseCase
import com.idenfy.idenfy_sample_android.domain.usecases.GetIdenfyAuthTokenUseCase
import com.idenfy.idenfy_sample_android.domain.utils.Consts
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtils
import com.idenfy.idenfy_sample_android.ui.presentation.IdenfyAuthTokenState
import io.reactivex.disposables.CompositeDisposable

class MainViewModel : ViewModel() {

    private var serviceLocator = ServiceLocator()
    private var getIdenfyAuthTokenUseCase: GetIdenfyAuthTokenUseCase
    private var getFaceAuthenticationTokenUseCase: GetFaceAuthenticationTokenUseCase
    private var getFaceAuthenticationTypeUseCase: GetFaceAuthenticationTypeUseCase
    private var rxJavaUtils: RxJavaUtils = serviceLocator.rxJavaUtils
    private var compositeDisposable = CompositeDisposable()
    private var _idenfyAuthTokenStateLiveData = MutableLiveData<IdenfyAuthTokenState>()
    val idenfyAuthTokenStateLiveData: LiveData<IdenfyAuthTokenState>
        get() = _idenfyAuthTokenStateLiveData

    init {
        getIdenfyAuthTokenUseCase =
            GetIdenfyAuthTokenUseCase(serviceLocator.apiService, rxJavaUtils)
        getFaceAuthenticationTokenUseCase = GetFaceAuthenticationTokenUseCase(serviceLocator.apiService, rxJavaUtils)
        getFaceAuthenticationTypeUseCase = GetFaceAuthenticationTypeUseCase(serviceLocator.apiService, rxJavaUtils)
        resetAuthTokenState()
    }

    override fun onCleared() {
        compositeDisposable.dispose()
        super.onCleared()
    }

    fun resetAuthTokenState() {
        _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.NotStarted
    }

    fun getIdenfyAuthToken() {
        _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.Loading
        val authTokenBody =
            AuthTokenBody(Consts.clientId)
        val disposable = getIdenfyAuthTokenUseCase.execute(authTokenBody)
            .observeOn(rxJavaUtils.getAndroidSchedulersMainThread())
            .subscribe({ authToken ->
                _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.Success(authToken)

            }, {
                _idenfyAuthTokenStateLiveData.value =
                    IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(it)
            })
        compositeDisposable.add(disposable)
    }

    fun checkFaceAuthenticationType(scanRef: String, authenticationMethod: String) {
        _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.Loading
        val disposable = getFaceAuthenticationTypeUseCase.execute(scanRef, authenticationMethod)
            .observeOn(rxJavaUtils.getAndroidSchedulersMainThread())
            .subscribe({ response ->
                when(val type = response.type) {
                    FaceAuthenticationType.AUTHENTICATION -> {
                        //The user can authenticate by face
                        getFaceAuthenticationToken(PartnerAuthenticationInfoRequest(scanRef = scanRef, type = type.name, method = authenticationMethod))
                    }
                    else -> {
                        //The user must perform an identification
                    }
                }

            }, {
                _idenfyAuthTokenStateLiveData.value =
                    IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(it)
            })
        compositeDisposable.add(disposable)
    }

    private fun getFaceAuthenticationToken(partnerAuthenticationInfoRequest: PartnerAuthenticationInfoRequest) {
        val disposable = getFaceAuthenticationTokenUseCase.execute(partnerAuthenticationInfoRequest)
            .observeOn(rxJavaUtils.getAndroidSchedulersMainThread())
            .subscribe({ authToken ->
                _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.FaceAuthSuccess(authToken)

            }, {
                _idenfyAuthTokenStateLiveData.value =
                    IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(it)
            })
        compositeDisposable.add(disposable)
    }
}