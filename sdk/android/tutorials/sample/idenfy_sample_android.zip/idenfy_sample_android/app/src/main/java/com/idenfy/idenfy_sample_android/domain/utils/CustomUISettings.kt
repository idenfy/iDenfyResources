package com.idenfy.idenfy_sample_android.domain.utils

import androidx.core.graphics.toColorInt
import com.idenfy.idenfySdk.api.ui.colors.IdenfyColorScheme

object CustomUISettings {

    fun createCustomColorScheme(): IdenfyColorScheme {
        val mainColor = "#6AA82F".toColorInt()
        val secondaryColor = "#000000".toColorInt()
        val backgroundColor = "#FFFFFF".toColorInt()

        return IdenfyColorScheme().apply {
            idenfyMainColorV2 = mainColor
            idenfyMainDarkerColorV2 = mainColor
            idenfyBackgroundColorV2 = backgroundColor
            idenfySecondColorV2 = secondaryColor
            idenfyGradientAccentV2 = mainColor
            idenfyGradientButtonColorStart = mainColor
            idenfyGradientButtonColorEnd = mainColor
            // Alert dialog
            idenfyCustomAlertDialogBackgroundColor = backgroundColor
            // Country/doc selection
            idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedBorderColor = secondaryColor
            idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedBackgroundColor = mainColor
            idenfyCountryAndDocumentSelectionViewItemSelectionHighlightedTextColor = secondaryColor
            // Camera buttons
            idenfyDocumentCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = mainColor
            idenfyFaceCameraPreviewSessionTakePhotoButtonUnFocusedTintColor = mainColor
            idenfyDocumentCameraPreviewSessionTakePhotoButtonFocusedTintColor = secondaryColor
            idenfyFaceCameraPreviewSessionTakePhotoButtonFocusedTintColor = secondaryColor
            // Photo result card titles
            idenfyDocumentPhotoResultViewCardTitleColor = secondaryColor
            idenfyFacePhotoResultViewCardTitleColor = secondaryColor
            // Photo result buttons
            idenfyDocumentPhotoResultViewNextButtonTextColor = secondaryColor
            idenfyFacePhotoResultViewNextButtonTextColor = secondaryColor
            idenfyDocumentPhotoResultViewRetakePhotoButtonTextColor = secondaryColor
            idenfyFacePhotoResultViewRetakePhotoButtonTextColor = secondaryColor
            // Continue button text
            idenfyCountrySelectionViewPredefinedCountryContinueButtonTextColor = secondaryColor
            idenfyDocumentSelectionViewContinueButtonDisabledTextColor = secondaryColor
            idenfyDocumentSelectionViewContinueButtonEnabledTextColor = secondaryColor
            idenfyCameraStaticOnBoardingViewDisabledButtonTitleColor = secondaryColor
            idenfyCameraStaticOnBoardingViewEnabledButtonTitleColor = secondaryColor
            idenfyManualReviewingStatusApprovedContinueButtonTextColor = secondaryColor
            idenfyManualReviewingStatusFailedContinueButtonTextColor = secondaryColor
            idenfyManualReviewingStatusWaitingBackToAccountButtonTextColor = secondaryColor
            idenfyIdentificationSuspectedResultsViewContinueButtonTitleColor = secondaryColor
            idenfyIdentificationResultsViewRetakeButtonTextColor = secondaryColor
            idenfyAdditionalSupportContinueButtonTextColor = secondaryColor
            idenfyPrivacyPolicyContinueButtonTextColor = secondaryColor
            idenfyCountryAndDocumentSelectionViewContinueButtonEnabledTextColor = secondaryColor
            idenfyCountryAndDocumentSelectionViewContinueButtonDisabledTextColor = secondaryColor
            // EID continue button text
            idenfyEIDSessionViewButtonTextColor = secondaryColor
            idenfyEIDSessionViewContinueButtonDisabledTextColor = secondaryColor
            idenfyEIDSessionViewContinueButtonEnabledTextColor = secondaryColor
            // NFC continue button text
            idenfyNFCRequiredContinueButtonTextColor = secondaryColor
            idenfyNFCReadingTimeOutContinueButtonTextColor = secondaryColor
            // Identification results spinners
            idenfyIdentificationResultsViewDocumentStepLoadingSpinnerAccentColor = mainColor
            // Selected cells text
            idenfyDocumentSelectionViewRecyclerViewItemHighlightedTextColor = secondaryColor
            idenfyCountrySelectionViewCountryRecyclerViewItemHighlightedTextColor = secondaryColor
            idenfyManualReviewingStatusWaitingCommonReviewBoxFinishedTitleColor = secondaryColor
            idenfyManualReviewingStatusWaitingCommonReviewBoxFinishedTickImageTintColor = secondaryColor
            // Toolbar
            idenfyDefaultAppBarIconTintColor = secondaryColor
            idenfyCameraPreviewSessionAppBarBackButtonTintColor = backgroundColor
        }
    }
}
