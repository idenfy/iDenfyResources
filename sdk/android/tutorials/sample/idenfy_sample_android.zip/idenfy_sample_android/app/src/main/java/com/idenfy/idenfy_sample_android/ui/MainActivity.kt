package com.idenfy.idenfy_sample_android.ui

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyController
import com.idenfy.idenfySdk.api.initialization.IdenfySettingsV2.IdenfyBuilderV2
import com.idenfy.idenfySdk.api.logging.IdenfySDKLoggingSettings.IdenfySDKLoggingEnum
import com.idenfy.idenfySdk.api.models.IdenfyOnBoardingViewTypeEnum
import com.idenfy.idenfySdk.api.response.*
import com.idenfy.idenfySdk.api.ui.IdenfyUISettingsV2.IdenfyUIBuilderV2
import com.idenfy.idenfySdk.camerasession.commoncamerasession.presentation.model.IdenfyInstructionsType
import com.idenfy.idenfy_sample_android.R
import com.idenfy.idenfy_sample_android.data.models.AuthToken
import com.idenfy.idenfy_sample_android.ui.fragments.FaceAuthenticationStartFragment
import com.idenfy.idenfy_sample_android.ui.presentation.IdenfyAuthTokenState
import com.idenfy.idenfy_sample_android.ui.viewmodel.MainViewModel

class MainActivity: AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private lateinit var ivBeginIdentification: ImageView
    private lateinit var ivBeginFaceAuthentication: ImageView
    private var loadingDialog: AlertDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainViewModel = ViewModelProvider(this)[MainViewModel::class.java]
        setContentView(R.layout.idenfy_activity_sample_app_main)
        ivBeginIdentification = findViewById(R.id.idenfy_iv_identification)
        ivBeginFaceAuthentication = findViewById(R.id.idenfy_iv_face_authentication)
        ivBeginIdentification.setOnClickListener {
            mainViewModel.getIdenfyAuthToken()
        }
        ivBeginFaceAuthentication.setOnClickListener {
            supportFragmentManager.beginTransaction()
            .replace(R.id.root_container, FaceAuthenticationStartFragment())
            .commit()
        }
        observeIdenfyAuthTokenState()
    }

    private fun observeIdenfyAuthTokenState() {
        mainViewModel.idenfyAuthTokenStateLiveData.observe(this) {
            when (it) {
                IdenfyAuthTokenState.NotStarted -> {

                }
                IdenfyAuthTokenState.Loading -> {
                    handleLoadingAuthTokenState()
                }
                is IdenfyAuthTokenState.AuthTokenCouldNotBeReceived -> {
                    handleAuthTokenCouldNotBeReceived(it.throwable)
                }
                is IdenfyAuthTokenState.Success -> {
                    handleAuthTokenSuccess(it.authToken)

                }
                is IdenfyAuthTokenState.FaceAuthSuccess -> {}
            }
        }
    }

    fun resetState() {
        mainViewModel.resetAuthTokenState()
        loadingDialog?.cancel()
    }

    private fun handleAuthTokenSuccess(authToken: AuthToken) {
        resetState()
        initializeIdenfySDK(authToken.authToken)
    }

    private fun handleAuthTokenCouldNotBeReceived(throwable: Throwable) {
        resetState()
        Toast.makeText(this, "Error obtaining token $throwable", Toast.LENGTH_LONG).show()
    }

    private fun handleLoadingAuthTokenState() {
        val builder = AlertDialog.Builder(this, com.idenfySdk.R.style.IdenfyStyleAlertDialog)
        val inflater = this.layoutInflater
        val dialogView: View = inflater.inflate(
            R.layout.idenfy_dialog_sample_app,
            null
        )
        builder.setView(dialogView)
        loadingDialog = builder.create()
        loadingDialog!!.setCancelable(false)
        loadingDialog!!.show()
    }

    private fun initializeIdenfySDK(authToken: String) {
        val idenfyUISettingsV2 = IdenfyUIBuilderV2()
            .withInstructions(IdenfyInstructionsType.DIALOG)
            .build()

        val idenfySettingsV2 = IdenfyBuilderV2()
            .withAuthToken(authToken)
            .withIdenfyUISettingsV2(idenfyUISettingsV2)
            .withLogging(IdenfySDKLoggingEnum.FULL)
            .build()

        IdenfyController.getInstance().initializeIdenfySDKV2WithManual(
            this,
            identificationResultsCallback,
            idenfySettingsV2
        )
    }

    var identificationResultsCallback = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        val resultCode = result.resultCode
        val data = result.data

        if (resultCode == IdenfyController.IDENFY_IDENTIFICATION_RESULT_CODE) {
            val idenfyIdentificationResult: IdenfyIdentificationResult = data!!.getParcelableExtra(
                IdenfyController.IDENFY_IDENTIFICATION_RESULT
            )!!
            when (idenfyIdentificationResult.manualIdentificationStatus) {
                ManualIdentificationStatus.APPROVED -> {
                    //The user completed a verification flow, was verified manually and the verification status, provided by a manual reviewer, is APPROVED.
                }
                ManualIdentificationStatus.FAILED -> {
                    //The user completed a verification flow, was verified manually and the verification status, provided by a manual reviewer, is FAILED.
                }
                ManualIdentificationStatus.WAITING -> {
                    //The user was only verified by an automated platform, not by a manual reviewer.
                }
                ManualIdentificationStatus.INACTIVE -> {
                    //The user was only verified by an automated platform and still waiting for manual reviewing.
                }
            }
            when (idenfyIdentificationResult.autoIdentificationStatus) {
                AutoIdentificationStatus.APPROVED -> {
                    //The user completed a verification flow and the verification status, provided by an automated platform, is APPROVED.
                }
                AutoIdentificationStatus.FAILED -> {
                    //The user completed a verification flow and the verification status, provided by an automated platform, is FAILED.
                }
                AutoIdentificationStatus.UNVERIFIED -> {
                    //The user did not complete a verification flow and the verification status, provided by an automated platform, is UNVERIFIED.
                }
            }
            Toast.makeText(
                this@MainActivity,
                "Auto - ${idenfyIdentificationResult.autoIdentificationStatus} \n" +
                        "Manual - ${idenfyIdentificationResult.manualIdentificationStatus} \n",
                Toast.LENGTH_LONG
            ).show()
        } else if (resultCode == IdenfyController.IDENFY_FACE_AUTHENTICATION_RESULT_CODE) {
            val faceAuthenticationResult: FaceAuthenticationResult =
                data!!.getParcelableExtra(IdenfyController.IDENFY_FACE_AUTHENTICATION_RESULT)!!
            when (faceAuthenticationResult.faceAuthenticationStatus) {
                FaceAuthenticationStatus.SUCCESS -> {
                    // The user completed authentication flow, was successfully authenticated
                }
                FaceAuthenticationStatus.FAILED -> {
                    // The user completed authentication flow, was not successfully authenticated
                }
                FaceAuthenticationStatus.EXIT -> {
                    // The user did not complete authentication flow
                }
            }
            Toast.makeText(
                this@MainActivity,
                faceAuthenticationResult.faceAuthenticationStatus.toString(),
                Toast.LENGTH_LONG
            ).show()
        }
    }
}