package com.idenfy.idenfy_sample_android.data.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AuthTokenBody(
    @Expose
    @SerializedName("clientId")
    var clientId: String
) {
    @Expose
    @SerializedName("firstName")
    var firstName: String? = null

    @Expose
    @SerializedName("lastName")
    var lastName: String? = null

    @Expose
    @SerializedName("country")
    var country: String? = null
}