package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.squareup.moshi.Json

@Keep
class AuthTokenBody(
    @field:Json(name = "clientId")
    var clientId: String,

    @field:Json(name = "firstName")
    var firstName: String? = null,

    @field:Json(name = "lastName")
    var lastName: String? = null,

    @field:Json(name = "country")
    var country: String? = null
)