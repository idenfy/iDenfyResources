package com.idenfy.idenfy_sample_android.domain.utils

import android.util.Log
import com.idenfy.idenfySdk.CoreSdkInitialization.IdenfyUserFlowHandler

class IdenfyUserFlowCallbacksHandler : IdenfyUserFlowHandler {

    /**
     * @param photo base64 string of uploaded photo
     * @param step a step of uploaded photo
     */
    override fun onPhotoUploaded(photo: String, step: String) {
        Log.d("onPhotoUploaded", step)
    }

    /**
     * @param documentType Selected document type
     */
    override fun onDocumentSelected(documentType: String) {
        Log.d("userFlowCallbackdoc", documentType)
    }

    /**
     * @param issuingCountryCode Selected issuingCountryCode
     */
    override fun onCountrySelected(issuingCountryCode: String) {
        Log.d("userFlowCallbacksc", issuingCountryCode)
    }

    /**
     * @param photosUploaded indicated that photos have been uploaded
     */
    override fun onPhotosUploaded(photosUploaded: Boolean) {
        Log.d("userFlowCallbacksphoto", photosUploaded.toString())
    }

    /**
     * @param processingStarted indicates that processing has started
     */
    override fun onProcessingStarted(processingStarted: Boolean) {
        Log.d("userFlowCallbackspro", processingStarted.toString())
    }
}