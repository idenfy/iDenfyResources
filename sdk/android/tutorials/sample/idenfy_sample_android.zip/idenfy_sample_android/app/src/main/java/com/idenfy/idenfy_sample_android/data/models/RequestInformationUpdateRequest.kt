package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.squareup.moshi.Json

@Keep
class RequestInformationUpdateRequest(
    @field:Json(name = "questionnaire") var questionnaire: String? = null,
    @field:Json(name = "additionalStepUploadRequired") var additionalStepUploadRequired: Boolean = true
)
