package com.idenfy.idenfy_sample_android.networking

import com.idenfy.idenfy_sample_android.BuildConfig
import com.idenfy.idenfy_sample_android.domain.utils.Consts
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitFactory {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val interceptor: HttpLoggingInterceptor =
        HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    private fun makeOkhttpClient(): OkHttpClient {
        val client = OkHttpClient.Builder()
            .connectTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(300, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
        client.addInterceptor(
            BasicAuthInterceptor(
                Consts.apiKey,
                Consts.apiSecret
            )
        )
        client.addInterceptor(interceptor)
        client.retryOnConnectionFailure(true)
            .addNetworkInterceptor { chain ->
                val request = chain.request().newBuilder().addHeader("Connection", "close").build()
                chain.proceed(request)
            }


        return client.build()
    }

    fun makeRetrofitService(): APIService {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(makeOkhttpClient())
            .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
            .create(APIService::class.java)
    }
}