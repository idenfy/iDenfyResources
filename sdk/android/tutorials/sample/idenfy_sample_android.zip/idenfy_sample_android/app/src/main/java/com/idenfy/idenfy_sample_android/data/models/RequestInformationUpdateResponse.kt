package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.squareup.moshi.Json

@Keep
class RequestInformationUpdateResponse {
    @field:Json(name = "tokenString") var tokenString: String? = null
}
