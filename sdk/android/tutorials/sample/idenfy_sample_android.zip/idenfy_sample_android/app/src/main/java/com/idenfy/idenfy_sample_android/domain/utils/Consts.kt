package com.idenfy.idenfy_sample_android.domain.utils

/**
 * More about generating token: https://documentation.idenfy.com/KYC/GeneratingIdentificationToken
 */
object Consts {
    const val clientId = "idenfySampleClientID"
    const val apiKey = "PUT_YOUR_API_KEY_HERE"
    const val apiSecret = "PUT_YOUR_API_SECRET_HERE"
}