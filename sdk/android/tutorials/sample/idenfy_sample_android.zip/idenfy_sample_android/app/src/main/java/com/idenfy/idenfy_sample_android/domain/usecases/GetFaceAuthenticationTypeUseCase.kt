package com.idenfy.idenfy_sample_android.domain.usecases

import com.idenfy.idenfy_sample_android.data.models.FaceAuthenticationTypeResponse
import com.idenfy.idenfy_sample_android.networking.APIService
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtils
import io.reactivex.Single

class GetFaceAuthenticationTypeUseCase(
    private val apiService: APIService,
    private val rxJavaUtils: RxJavaUtils
) {

    fun execute(scanref: String, authenticationMethod: String): Single<FaceAuthenticationTypeResponse> {
        return apiService.getFaceAuthenticationType(scanref, authenticationMethod)
            .subscribeOn(rxJavaUtils.getSchedulersIO())
    }

}