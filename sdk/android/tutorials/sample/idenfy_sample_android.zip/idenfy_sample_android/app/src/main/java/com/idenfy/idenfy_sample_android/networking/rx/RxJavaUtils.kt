package com.idenfy.idenfy_sample_android.networking.rx

import io.reactivex.Scheduler

interface RxJavaUtils {
    fun getSchedulersIO(): Scheduler
    fun getAndroidSchedulersMainThread(): Scheduler
}