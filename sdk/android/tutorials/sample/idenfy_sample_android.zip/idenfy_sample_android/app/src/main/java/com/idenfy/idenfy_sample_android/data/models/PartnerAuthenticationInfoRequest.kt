package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Keep
class PartnerAuthenticationInfoRequest(
    @Expose
    @SerializedName("scanRef")
    var scanRef: String,
    @Expose
    @SerializedName("type")
    var type: String? = null,
    @Expose
    @SerializedName("method")
    var method: String? = null,
)