package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.squareup.moshi.Json

@Keep
class PartnerAuthenticationInfoRequest(
    @field:Json(name = "scanRef")
    var scanRef: String,
    @field:Json(name = "type")
    var type: String? = null,
    @field:Json(name = "method")
    var method: String? = null,
)