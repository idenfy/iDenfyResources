package com.idenfy.idenfy_sample_android.networking;

import com.idenfy.idenfy_sample_android.data.models.AuthToken;
import com.idenfy.idenfy_sample_android.data.models.AuthTokenBody;
import com.idenfy.idenfy_sample_android.data.models.FaceAuthenticationTypeResponse;
import com.idenfy.idenfy_sample_android.data.models.PartnerAuthenticationInfoRequest;
import com.idenfy.idenfy_sample_android.data.models.PartnerAuthenticationInfoResponse;

import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface APIService {

    @Headers("Content-Type: application/json")
    @POST("api/v2/token")
    Single<AuthToken> getAppToken(@Body AuthTokenBody authTokenBody);

    @Headers("Content-Type: application/json")
    @POST("/partner/authentication-info")
    Single<PartnerAuthenticationInfoResponse> getAuthenticationToken(
            @Body PartnerAuthenticationInfoRequest partnerAuthenticationInfoRequest
    );

    @Headers("Content-Type: application/json")
    @GET("/identification/facial-auth/{scanRef}/check-status/")
    Single<FaceAuthenticationTypeResponse> getFaceAuthenticationType(
            @Path("scanRef") String scanRef,
            @Query("method") String method
    );
}
