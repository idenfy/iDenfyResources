package com.idenfy.idenfy_sample_android.data.models

import androidx.annotation.Keep
import com.squareup.moshi.Json

@Keep
class AuthToken(
    @field:Json(name = "authToken")
    var authToken: String = ""
)