package com.idenfy.idenfy_sample_android.data.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AuthToken {
    @Expose
    @SerializedName("authToken")
    var authToken: String = ""
}